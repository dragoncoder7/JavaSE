create PROCEDURE CRM_ShareInfo_SbyRelateditemid (relateditemid1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * from CRM_ShareInfo where ( relateditemid = relateditemid1 and (isdefault is null or (isdefault=1 and sharelevel=3 and sharetype=1))) order by sharetype ; end;


/

