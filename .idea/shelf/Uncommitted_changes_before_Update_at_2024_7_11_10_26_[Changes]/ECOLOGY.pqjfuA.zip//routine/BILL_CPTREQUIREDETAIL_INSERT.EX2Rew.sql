create PROCEDURE bill_CptRequireDetail_Insert (cptrequireid1 	integer, cpttype1 	integer, cptid_1 	integer, number_2 	number, unitprice_3 	number, needdate_5 	varchar2, purpose_6 	varchar2, cptdesc_7 	varchar2, buynumber1 	number, adjustnumber1 	number, fetchnumber1 	number, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin INSERT INTO bill_CptRequireDetail ( cptrequireid, cpttype, cptid, number_n, unitprice, needdate, purpose, cptdesc, buynumber, adjustnumber, fetchnumber)  VALUES ( cptrequireid1, cpttype1, cptid_1, number_2, unitprice_3, needdate_5, purpose_6, cptdesc_7, buynumber1, adjustnumber1, fetchnumber1 ); end;


/

