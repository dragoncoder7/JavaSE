create PROCEDURE CptCapitalGroup_Delete (id_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS  count_1 integer; begin select count(*) INTO count_1 from  CptCapitalGroup where parentid = id_1; if count_1<>0 then  open thecursor for select -1 from dual; return; end if;  IF count_1=0 then DELETE CptCapitalGroup WHERE ( id = id_1); end if; end;


/

