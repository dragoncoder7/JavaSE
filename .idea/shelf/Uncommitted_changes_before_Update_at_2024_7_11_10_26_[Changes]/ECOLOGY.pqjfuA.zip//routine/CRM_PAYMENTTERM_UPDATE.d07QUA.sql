create PROCEDURE CRM_PaymentTerm_Update (id1 	integer, fullname1 	varchar2, description1 	varchar2,flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_PaymentTerm SET  fullname	 = fullname1, description	 = description1 WHERE ( id	 = id1) ; end;


/

