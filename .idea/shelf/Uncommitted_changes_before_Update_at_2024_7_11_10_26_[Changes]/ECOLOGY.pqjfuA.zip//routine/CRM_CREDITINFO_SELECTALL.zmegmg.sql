create PROCEDURE CRM_CreditInfo_SelectAll ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_CreditInfo ; end;


/

