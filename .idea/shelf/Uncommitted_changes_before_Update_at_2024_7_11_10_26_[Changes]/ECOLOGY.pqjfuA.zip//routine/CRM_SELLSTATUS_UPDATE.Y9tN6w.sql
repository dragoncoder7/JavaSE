create PROCEDURE CRM_SellStatus_Update (id	 	integer, fullname 	varchar2, description 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_SellStatus SET  fullname	 = fullname, description	 = description WHERE ( id	 = id)  ; end;


/

