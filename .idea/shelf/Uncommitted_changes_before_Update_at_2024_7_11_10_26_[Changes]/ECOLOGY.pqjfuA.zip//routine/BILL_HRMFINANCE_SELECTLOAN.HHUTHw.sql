create PROCEDURE bill_HrmFinance_SelectLoan ( resourceid_1	integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS tmpamount1   number(10,3); tmpamount2   number(10,3); begin select sum(amount) INTO tmpamount1 from FnaLoanLog where resourceid= resourceid_1 and loantypeid = 1;  select sum(amount) INTO tmpamount2 from FnaLoanLog where resourceid= resourceid_1 and loantypeid != 1;  if    tmpamount1 is null then tmpamount1 :=0; end if;  if    tmpamount2 is null then tmpamount2 := 0; end if;  tmpamount1 := tmpamount1-tmpamount2 ;  open thecursor for select tmpamount1 from dual; end;


/

