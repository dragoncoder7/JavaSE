create PROCEDURE CRM_Log_Insert (customerid_1 	integer, logtype_1 	char, documentid_1 	integer, logcontent_1 	varchar2, submitdate_1 	varchar2, submittime_1 	varchar2, submiter_1 	integer, submitertype_1  smallint, clientip_1 	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_Log ( customerid, logtype, documentid, logcontent, submitdate, submittime, submiter, submitertype, clientip) VALUES ( customerid_1, logtype_1, documentid_1, logcontent_1, submitdate_1, submittime_1, submiter_1, submitertype_1, clientip_1); end;


/

