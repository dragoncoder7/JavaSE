create PROCEDURE CarType_Select (flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin open thecursor for select * from cartype; end;


/

