create PROCEDURE Base_FreeField_Select (tablename_1 	varchar2, flag out 	integer	, msg out	varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for SELECT * FROM Base_FreeField WHERE  tablename	 = tablename_1; end;


/

