create PROCEDURE bill_HotelBookDetail_Delete ( bookid1		integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin delete from bill_HotelBookDetail where bookid=bookid1; end;


/

