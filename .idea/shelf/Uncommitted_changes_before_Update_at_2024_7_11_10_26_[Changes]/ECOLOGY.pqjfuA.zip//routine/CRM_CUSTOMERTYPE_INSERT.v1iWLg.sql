create PROCEDURE CRM_CustomerType_Insert (fullname varchar2, description varchar2, workflowid integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_CustomerType ( fullname, description,workflowid) VALUES ( fullname, description,workflowid); end;


/

