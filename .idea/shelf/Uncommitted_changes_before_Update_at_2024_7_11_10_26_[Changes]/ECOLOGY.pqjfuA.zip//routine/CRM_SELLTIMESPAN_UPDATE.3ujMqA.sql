create PROCEDURE CRM_SellTimespan_update ( time_1 integer, spannum_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update CRM_SelltimeSpan set timespan = time_1, spannum = spannum_1; end;


/

