create procedure BPMSequenceId_Get (indexdesc_1 varchar2, flag out 	integer, msg out	varchar2, thecursor IN OUT cursor_define.weavercursor) as id_1 integer; begin select currentid into id_1 from SequenceIndex where indexdesc = indexdesc_1; update SequenceIndex set currentid = id_1+1 where indexdesc = indexdesc_1; open thecursor for select id_1 from dual; end;


/

