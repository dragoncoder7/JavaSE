create PROCEDURE CptDepreMethod1_Select (depretype_1		char, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptDepreMethod1 where depretype = depretype_1; end;


/

