create PROCEDURE Capital_Adjust2 ( capitalid_1 integer, usedate_1 varchar2, usedeptid_1 integer, useresourceid_1 integer,userequest_1 integer, usecount_1 integer, useaddress_1 varchar2, usestatus_1 varchar2, remark_1 varchar2, olddeptid_1 integer, flag out 	integer	, msg out	varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin insert INTO CptUseLog ( capitalid, usedate, usedeptid, useresourceid,userequest, usecount, useaddress, usestatus, remark, olddeptid) values ( capitalid_1  , usedate_1  , usedeptid_1  , useresourceid_1  ,userequest_1  , usecount_1  , useaddress_1  , usestatus_1  , remark_1  , olddeptid_1  );  update CptCapital set departmentid = usedeptid_1  , resourceid = useresourceid_1 WHERE id=capitalid_1; end;


/

