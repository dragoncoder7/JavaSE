create PROCEDURE CRM_LedgerInfo_Delete ( customerid1	integer, tradetype1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin delete from CRM_LedgerInfo where customerid=customerid1 and tradetype=tradetype1 ; end;


/

