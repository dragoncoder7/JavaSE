create procedure CRM_Sort_LgcAssetTotal is total VARCHAR(1000); assortmentstr2 VARCHAR(1000); v_sqlfalg VARCHAR(1000); CURSOR RS IS select id,supassortmentid,supassortmentstr from LgcAssetAssortment where supassortmentid is not null ORDER BY id asc; RS_ROW RS%ROWTYPE; BEGIN FOR RS_ROW IN RS LOOP BEGIN v_sqlfalg:='select count(id) as a from LgcAsset where assortmentstr LIKE ''%'||RS_ROW.id|| '%'''; execute immediate v_sqlfalg into total; update LgcAssetAssortment set assetcount=total where id=RS_ROW.id;END;END LOOP;END;


/

