create PROCEDURE CptCapitalAssortment_Update (id_1 	integer, assortmentname_3 	varchar2, assortmentmark_1	varchar2, assortmentremark_7 	varchar2, supassortmentid_8 	integer, supassortmentstr_9 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CptCapitalAssortment SET assortmentname	 = assortmentname_3, assortmentmark = assortmentmark_1, assortmentremark	 = assortmentremark_7, supassortmentid	 = supassortmentid_8, supassortmentstr	 = supassortmentstr_9 WHERE ( id	 = id_1); end;


/

