create procedure CRM_Sort_LgcAssetType is supassortmentstr1 VARCHAR(1000); assortmentstr2 VARCHAR(1000); v_sqlfalg VARCHAR(1000); CURSOR RS IS select id,assortmentid,assortmentstr from LgcAsset ORDER BY id asc; RS_ROW RS%ROWTYPE; BEGIN FOR RS_ROW IN RS LOOP BEGIN v_sqlfalg:='select supassortmentstr from LgcAssetAssortment where supassortmentid is not null and id='''||RS_ROW.assortmentid|| ''''; execute immediate v_sqlfalg into assortmentstr2; supassortmentstr1:=assortmentstr2||RS_ROW.assortmentid||'|'; UPDATE LgcAsset SET assortmentstr=supassortmentstr1 WHERE id=RS_ROW.id;END;END LOOP;END;


/

