create PROCEDURE cowork_log_insert (coworkid_1 	integer, type_2 	integer, modifydate_3 	char, modifytime_4 	char, modifier_5 	integer, clientip_6  char, flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin INSERT INTO cowork_log ( coworkid, type, modifydate, modifytime, modifier, clientip) VALUES ( coworkid_1, type_2, modifydate_3, modifytime_4, modifier_5, clientip_6); end;


/

