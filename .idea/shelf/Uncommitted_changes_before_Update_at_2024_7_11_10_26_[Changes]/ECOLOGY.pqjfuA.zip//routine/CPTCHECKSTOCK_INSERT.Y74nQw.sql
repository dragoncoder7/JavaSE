create PROCEDURE CptCheckStock_Insert (checkstockno_1 	varchar2, checkstockdesc_2 	varchar2, departmentid_3 	integer, location_4 	varchar2, checkerid_5 	integer, createdate_7 	varchar2, checkstatus_9 	char, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin insert into CptCheckStock ( checkstockno, checkstockdesc, departmentid, location, checkerid, createdate, checkstatus)  VALUES ( checkstockno_1, checkstockdesc_2, departmentid_3, location_4, checkerid_5, createdate_7, checkstatus_9); open thecursor for select max(id) from CptCheckStock; end;


/

