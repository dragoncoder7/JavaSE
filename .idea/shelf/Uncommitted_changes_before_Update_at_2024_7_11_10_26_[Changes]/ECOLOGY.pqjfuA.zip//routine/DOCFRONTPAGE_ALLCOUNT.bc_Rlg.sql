create PROCEDURE DocFrontpage_ALLCount ( logintype_1		integer, usertype_1		integer, userid_1			integer, userseclevel_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin if logintype_1 =1 then open thecursor for Select count(distinct n.id ) countnew from DocDetail n , DocShareDetail d  where n.id=d.docid and d.userid= userid_1 and d.usertype = 1 and  (n.docpublishtype='2' or n.docpublishtype='3') and n.docstatus in('1','2','5'); else open thecursor for Select count(distinct n.id ) countnew from DocDetail n , DocShareDetail d  where n.id=d.docid and d.usertype= usertype_1 and d.userid<= userseclevel_1 and (n.docpublishtype='2' or n.docpublishtype='3') and n.docstatus in('1','2','5'); end if; end;


/

