create PROCEDURE CRM_CustomerInfo_InsertID ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select id from (SELECT  id from CRM_CustomerInfo ORDER BY id DESC) where rownum=1 ; END;


/

