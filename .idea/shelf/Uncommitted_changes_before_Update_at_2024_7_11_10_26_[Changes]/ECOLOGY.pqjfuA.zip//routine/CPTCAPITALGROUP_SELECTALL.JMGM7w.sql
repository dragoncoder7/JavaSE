create PROCEDURE CptCapitalGroup_SelectAll (parentid_1	integer, flag	out integer, msg out varchar2,thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * FROM CptCapitalGroup WHERE (parentid = parentid_1); end;


/

