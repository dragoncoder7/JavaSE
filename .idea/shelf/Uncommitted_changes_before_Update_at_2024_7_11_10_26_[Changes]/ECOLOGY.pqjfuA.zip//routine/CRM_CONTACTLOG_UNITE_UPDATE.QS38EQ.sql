create PROCEDURE CRM_ContactLog_Unite_Update (id_1 	integer , id_2 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_ContactLog SET customerid = id_1 where customerid = id_2; end ;


/

