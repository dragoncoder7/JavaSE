create PROCEDURE CRM_ContractType_Insert (name_1 	varchar2, contractdesc_1	varchar2, workflowid_1  integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin INSERT INTO CRM_ContractType (name, contractdesc, workflowid)  VALUES ( name_1, contractdesc_1, workflowid_1); end;


/

