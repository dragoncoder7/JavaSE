create PROCEDURE CRM_LedgerInfo_Insert ( customerid_1	integer, customercode_1	char, tradetype_1	char, ledger1_1	integer, ledger2_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into CRM_LedgerInfo values(customerid_1,customercode_1,tradetype_1,ledger1_1,ledger2_1); end;


/

