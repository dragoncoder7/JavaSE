create PROCEDURE CRM_Log_Select (id_1 	int, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * from CRM_Log WHERE (customerid = id_1) ORDER BY submitdate DESC, submittime DESC; end;


/

