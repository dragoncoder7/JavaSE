create PROCEDURE CptCapital_SByCapitalTypeID (id_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for select * from CptCapital where capitaltypeid = id_1; end;


/

