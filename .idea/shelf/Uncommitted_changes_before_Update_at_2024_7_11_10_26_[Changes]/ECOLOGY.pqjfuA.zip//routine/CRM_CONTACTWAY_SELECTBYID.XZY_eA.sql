create PROCEDURE CRM_ContactWay_SelectByID (id_1 	integer,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_ContactWay WHERE ( id	 = id_1) ; end;


/

