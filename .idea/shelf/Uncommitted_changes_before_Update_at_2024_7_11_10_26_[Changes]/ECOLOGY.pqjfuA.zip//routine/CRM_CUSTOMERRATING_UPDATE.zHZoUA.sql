create PROCEDURE CRM_CustomerRating_Update (id_1 	integer, fullname_1 	varchar2, description_1 	varchar2, workflow11_1 integer, workflow12_1 integer, workflow21_1 integer, workflow22_1 integer, workflow31_1 integer, workflow32_1 integer, canupgrade_1 char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerRating SET fullname	 = fullname_1, description	 = description_1, workflow11 = workflow11_1, workflow12 = workflow12_1, workflow21 = workflow21_1, workflow22 = workflow22_1, workflow31 = workflow31_1, workflow32 = workflow32_1, canupgrade = canupgrade WHERE ( id	 = id_1); end;


/

