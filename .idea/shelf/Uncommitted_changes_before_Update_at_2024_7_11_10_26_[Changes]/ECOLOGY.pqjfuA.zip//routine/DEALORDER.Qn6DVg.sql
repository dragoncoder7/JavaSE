create procedure dealorder as m_id_1 INTEGER; begin SELECT COUNT(*) INTO m_id_1 FROM meeting_formfield WHERE GROUPID =2 AND fieldorder = 1; IF (m_id_1 >10) THEN UPDATE meeting_formfield SET fieldorder = fieldid WHERE fieldid IN( SELECT * FROM ( SELECT fieldid FROM meeting_formfield WHERE GROUPID = 2 AND fieldorder = 1 )a); end if; commit; end;


/

