create PROCEDURE cpt_selectitem_insert_new ( fieldid2 INT , isbill2 INT , selectvalue2 INT , selectname2 varchar2 , listorder2 NUMERIC , isdefault2 CHAR , cancel2 varchar2, flag  OUT INTEGER ,msg OUT varchar2 ,thecursor      IN OUT   cursor_define.weavercursor ) AS BEGIN INSERT  INTO cpt_selectitem ( fieldid , isbill , selectvalue , selectname , listorder , isdefault,cancel ) VALUES  ( fieldid2 , isbill2 , selectvalue2 , selectname2 , listorder2 , isdefault2,cancel2 ); END;


/

