create PROCEDURE docDetail_QueryByDocid (docid_1 	integer , flag	out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for select DocSubject,maincategory,docdepartmentid,doccreaterid  from Docdetail where id = docid_1 ; end;


/

