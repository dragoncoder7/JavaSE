create PROCEDURE CRM_Find_LastModifier (id_1	integer, flag	out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT submiter,submitdate,submitertype from (select submiter,submitdate,submitertype from CRM_Log WHERE customerid = id_1 and (not (logtype = 'n')) ORDER BY submitdate DESC) where rownum=1; end;


/

