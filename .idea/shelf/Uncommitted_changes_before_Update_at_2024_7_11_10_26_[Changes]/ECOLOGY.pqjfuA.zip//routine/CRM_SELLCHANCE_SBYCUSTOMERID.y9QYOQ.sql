create PROCEDURE CRM_SellChance_SByCustomerID ( id_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * FROM CRM_SellChance WHERE customerid =id_1 order by predate desc ; end;


/

