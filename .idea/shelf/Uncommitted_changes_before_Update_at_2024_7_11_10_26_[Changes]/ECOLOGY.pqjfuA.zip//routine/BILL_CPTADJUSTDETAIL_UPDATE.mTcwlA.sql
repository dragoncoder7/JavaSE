create PROCEDURE bill_CptAdjustDetail_Update (id_1 	integer, cptid_3 	integer, number_4 	number, unitprice_5 	number, amount_6 	number, cptstatus1 	integer, needdate_7 	varchar2, purpose_8 	varchar2, cptdesc_9 	varchar2, capitalid 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE  bill_CptAdjustDetail  SET cptid	 = cptid_3, number_n	 = number_4, unitprice	 = unitprice_5, amount	 = amount_6, cptstatus	 = cptstatus, needdate	 = needdate_7, purpose	 = purpose_8, cptdesc	 = cptdesc_9 , capitalid	 = capitalid  WHERE ( id	 = id_1); end;


/

