create PROCEDURE CRM_CustomerSize_SelectAll ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_CustomerSize order by id asc; end;


/

