create PROCEDURE CRM_Successfactor_Insert (fullname_1 	varchar2, description_1 	varchar2, flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin INSERT INTO CRM_Successfactor ( fullname, description) VALUES ( fullname_1, description_1) ; end;


/

