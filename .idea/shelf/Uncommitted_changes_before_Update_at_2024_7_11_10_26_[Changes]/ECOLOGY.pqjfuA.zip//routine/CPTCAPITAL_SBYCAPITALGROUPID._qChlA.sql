create PROCEDURE CptCapital_SByCapitalGroupID (id_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for select * from CptCapital where (capitalgroupid = id_1) and (isdata  ='2'); end;


/

