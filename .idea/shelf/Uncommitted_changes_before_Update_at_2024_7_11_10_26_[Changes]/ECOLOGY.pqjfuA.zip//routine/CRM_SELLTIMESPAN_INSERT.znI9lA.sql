create PROCEDURE CRM_SellTimespan_insert ( time_1 integer, spannum_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin insert INTO CRM_SelltimeSpan (timespan,spannum)values(time_1,spannum_1); end;


/

