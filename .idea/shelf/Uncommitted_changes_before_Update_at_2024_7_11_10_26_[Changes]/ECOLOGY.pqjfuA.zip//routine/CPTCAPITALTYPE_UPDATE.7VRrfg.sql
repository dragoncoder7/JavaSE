create PROCEDURE CptCapitalType_Update (id_1 	integer, name_2 	varchar2, description_3 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin update CptCapitalType SET  name=name_2,description=description_3 WHERE ( id=id_1); end;


/

