create PROCEDURE DocDetail_SelectCrmCountByCrm (id_1 	integer, id_2 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor  for select count(crmid) from DocDetail t1, DocUserView t2 where( t1.crmid = id_1 )and( t2.userid=id_2) and (t2.docid=t1.id ) ; end;


/

