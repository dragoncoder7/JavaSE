create PROCEDURE CarDriverDataPara_Insert (driverdataid_1        integer, paraid_2        integer, flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin insert into CarDriverDataPara values (driverdataid_1,paraid_2); end;


/

