create PROCEDURE CptStockInMain_Update ( id_1 integer , invoice_1 varchar2 , buyerid_1 integer , supplierid_1 integer , checkerid_1 integer , stockindate_1 char  , ischecked_1 integer , flag	out integer, msg   out	varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin update CptStockInMain set invoice=invoice_1, buyerid=buyerid_1 , supplierid=supplierid_1 , checkerid=checkerid_1, stockindate=stockindate_1 , ischecked=ischecked_1  where id = id_1; end;


/

