create PROCEDURE CRM_ViewLog1_Insert ( id_1	integer, viewer_1	integer, submitertype_1  smallint, viewdate_1	char, viewtime_1	char, ipaddress_1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin insert into CRM_viewLog1 (id, viewer, submitertype, viewdate, viewtime, ipaddress) values(id_1, viewer_1, submitertype_1, viewdate_1, viewtime_1, ipaddress_1); end;


/

