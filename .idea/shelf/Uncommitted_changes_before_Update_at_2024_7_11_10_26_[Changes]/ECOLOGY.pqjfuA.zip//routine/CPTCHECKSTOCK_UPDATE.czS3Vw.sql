create PROCEDURE CptCheckStock_Update (id_1 	integer, checkstockno_2 	varchar2, checkstockdesc_3 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update CptCheckStock  SET  checkstockno=checkstockno_2, checkstockdesc=checkstockdesc_3  WHERE ( id=id_1); end;


/

