create PROCEDURE CptShareDetail_DeleteByUserId (userid_1 	integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin DELETE CptShareDetail  WHERE ( userid	 = userid_1)  and( usertype = '1' ); end;


/

