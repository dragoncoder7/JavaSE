create PROCEDURE CRM_T_ShareInfo_SbyRelateid ( relateditemid_1 integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS BEGIN open thecursor for select * from CRM_T_ShareInfo where ( relateditemid = relateditemid_1 ) order by sharetype ; end;


/

