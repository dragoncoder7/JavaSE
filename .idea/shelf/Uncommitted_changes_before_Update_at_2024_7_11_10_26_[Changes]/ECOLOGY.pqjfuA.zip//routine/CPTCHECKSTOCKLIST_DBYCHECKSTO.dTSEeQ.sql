create PROCEDURE CptCheckStockList_DByCheckSto (checkstockid_1 	integer, price 	number, flag out integer, msg out varchar2 )  AS begin DELETE CptCheckStockList  WHERE ( checkstockid	 = checkstockid_1); end;


/

