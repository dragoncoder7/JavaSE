create PROCEDURE CRM_Contract_SelectAll ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin open thecursor for SELECT * FROM CRM_Contract; end;


/

