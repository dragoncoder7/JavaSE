create PROCEDURE CRM_ShareInfo_SelectbyID (id1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * from CRM_ShareInfo where (id = id1 ) ; end;


/

