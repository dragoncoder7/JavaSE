create PROCEDURE CptCapitalAssortment_Select (  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptCapitalAssortment order by assortmentmark; end;


/

