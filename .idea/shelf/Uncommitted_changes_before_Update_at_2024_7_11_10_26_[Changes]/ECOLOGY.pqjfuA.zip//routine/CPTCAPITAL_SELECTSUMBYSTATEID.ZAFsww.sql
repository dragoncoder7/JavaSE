create PROCEDURE CptCapital_SelectSumByStateid (flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select stateid  resultid, COUNT(id)  resultcount from CptCapital group by stateid order by  resultcount desc; end;


/

