create PROCEDURE CptUseLogMend_Insert2(capitalid_1       integer, usedate_2         char, usedeptid_3       integer, useresourceid_4   integer, usecount_5        integer, useaddress_6      varchar2, userequest_7      integer, maintaincompany_8 varchar2, fee_9             number, usestatus_10      varchar2, remark_11         varchar2, resourceid_12     varchar2, mendperioddate_13 varchar2, olddeptid_14      integer, flag              out integer, msg               out varchar2, thecursor         IN OUT cursor_define.weavercursor) AS begin INSERT INTO CptUseLog (capitalid, usedate, usedeptid, useresourceid, usecount, useaddress, userequest, maintaincompany, fee, usestatus, remark, resourceid, mendperioddate, olddeptid) VALUES (capitalid_1, usedate_2, usedeptid_3, useresourceid_4, usecount_5, useaddress_6, userequest_7, maintaincompany_8, fee_9, '4', remark_11, resourceid_12, mendperioddate_13, olddeptid_14); Update CptCapital Set stateid = usestatus_10 where id = capitalid_1; end;


/

