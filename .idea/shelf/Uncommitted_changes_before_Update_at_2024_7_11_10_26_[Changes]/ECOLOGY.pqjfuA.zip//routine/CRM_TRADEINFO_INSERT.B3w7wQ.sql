create PROCEDURE CRM_TradeInfo_Insert (fullname_1	varchar2, rangelower_1 	varchar2, rangeupper_1 	varchar2, flag	out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into CRM_TradeInfo ( fullname, rangelower, rangeupper) VALUES ( fullname_1, to_number(rangelower_1), to_number(rangeupper_1)); end;


/

