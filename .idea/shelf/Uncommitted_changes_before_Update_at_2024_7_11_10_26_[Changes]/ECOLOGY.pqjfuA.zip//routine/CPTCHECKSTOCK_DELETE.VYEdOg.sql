create PROCEDURE CptCheckStock_Delete (id_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin delete CptCheckStockList where checkstockid=id_1; DELETE CptCheckStock WHERE ( id=id_1); end;


/

