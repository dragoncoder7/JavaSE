create PROCEDURE CptStockInMain_Insert ( invoice_1 varchar2 , buyerid_1 integer , supplierid_1 integer , checkerid_1 integer , stockindate_1 char  , ischecked_1 integer , flag	out integer, msg   out	varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin INSERT INTO CptStockInMain (invoice, buyerid, supplierid, checkerid, stockindate, ischecked) VALUES (invoice_1, buyerid_1, supplierid_1, checkerid_1, stockindate_1, ischecked_1); open thecursor for select max(id) from CptStockInMain; end;


/

