create PROCEDURE CRM_CustomerInfo_SByLoginID ( portalloginid_1 varchar2,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CRM_CustomerInfo where portalloginid = portalloginid_1; end;


/

