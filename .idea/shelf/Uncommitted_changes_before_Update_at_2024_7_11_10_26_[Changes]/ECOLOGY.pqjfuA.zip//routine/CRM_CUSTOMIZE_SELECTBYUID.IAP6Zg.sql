create PROCEDURE CRM_Customize_SelectByUid (uid_1 	integer, logintype1  smallint, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_Customize WHERE ( userid = uid_1 and logintype	 = logintype1) ; end;


/

