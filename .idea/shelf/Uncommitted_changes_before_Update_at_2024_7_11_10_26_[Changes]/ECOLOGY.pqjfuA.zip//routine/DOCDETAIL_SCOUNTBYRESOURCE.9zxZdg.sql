create PROCEDURE DocDetail_SCountByResource (id_1 	integer, id_2  integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select count(hrmresid) from DocDetail t1, DocUserView t2 where hrmresid = id_1 and t2.userid=id_2 and t1.id=t2.docid ; end;


/

