create PROCEDURE CRM_CustomerRating_Insert (fullname_1 	varchar2, description_1 	varchar2, workflow11_1 integer, workflow12_1 integer, workflow21_1 integer, workflow22_1 integer, workflow31_1 integer, workflow32_1 integer, canupgrade_1 char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_CustomerRating ( fullname, description, workflow11, workflow12, workflow21, workflow22, workflow31, workflow32, canupgrade) VALUES ( fullname_1, description_1, workflow11_1, workflow12_1, workflow21_1, workflow22_1, workflow31_1, workflow32_1, canupgrade_1); end;


/

