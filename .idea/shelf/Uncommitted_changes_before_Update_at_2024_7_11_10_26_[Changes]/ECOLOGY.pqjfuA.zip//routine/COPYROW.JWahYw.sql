create procedure CopyRow(tid integer) as cursor mycur is select id, xmltext from wsactionset; crow mycur%rowtype; begin open mycur; loop fetch mycur into crow; exit when mycur%notfound; update wsformactionset set xmltext = crow.xmltext where oldwsactionsetid = crow.id; end loop; close mycur; end;


/

