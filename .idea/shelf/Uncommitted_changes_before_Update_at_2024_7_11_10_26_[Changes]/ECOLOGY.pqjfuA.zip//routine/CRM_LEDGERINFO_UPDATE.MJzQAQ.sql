create PROCEDURE CRM_LedgerInfo_Update ( customerid1	integer, customercode1	char, tradetype1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update CRM_LedgerInfo set customercode=customercode1 where customerid=customerid1 and tradetype=tradetype1; end;


/

