create PROCEDURE CRM_CustomerAddress_UEqual (typeid_1 	integer, customerid_2 	integer, isequal_3 	smallint, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerAddress  SET  isequal	 = isequal_3  WHERE ( typeid	 = typeid_1 AND customerid	 = customerid_2); end;


/

