create PROCEDURE bill_itemusage_Select ( id1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * from bill_itemusage where id=id1; end;


/

