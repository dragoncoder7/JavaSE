create PROCEDURE Bill_NameCardinfo_Insert ( resourceid_1		integer, cname_1          varchar2, cjobtitle_1      varchar2, cdepartment_1    varchar2, phone_1          varchar2, mobile_1         varchar2, email_1          varchar2, ename_1          varchar2, ejobtitle_1      varchar2, edepartment_1    varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into bill_namecardinfo (resourceid,cname,cjobtitle,cdepartment,phone,mobile,email,ename,ejobtitle,edepartment) values(resourceid_1,cname_1,cjobtitle_1,cdepartment_1,phone_1,mobile_1,email_1,ename_1,ejobtitle_1,edepartment_1); end;


/

