create PROCEDURE CptCheckStock_Approve (id_1 	integer, approverid_1 integer, approvedate_1 char, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update CptCheckStock SET  checkstatus='1', approverid = approverid_1, approvedate = approvedate_1  WHERE ( id=id_1); end;


/

