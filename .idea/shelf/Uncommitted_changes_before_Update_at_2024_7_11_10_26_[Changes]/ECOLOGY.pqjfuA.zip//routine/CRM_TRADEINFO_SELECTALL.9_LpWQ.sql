create PROCEDURE CRM_TradeInfo_SelectAll ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_TradeInfo ; end;


/

