create procedure Bill_SelectList_Insert (billid_1 integer, fieldname_2 varchar2, selectvalue_3 integer, selectname_4 varchar2, listorder_5 integer, isdefault_6 char) as fieldid integer; begin select  id into  fieldid from workflow_billfield where billid = billid_1 and fieldname = fieldname_2; insert into workflow_SelectItem (fieldid,isbill,selectvalue,selectname,listorder,isdefault) values(fieldid,1,selectvalue_3,selectname_4,listorder_5,isdefault_6); end;


/

