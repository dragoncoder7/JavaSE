create PROCEDURE CRM_CustomerCredit_Insert ( CreditAmount_1  number  , CreditTime_1  integer  , currencytype_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_CustomerCredit (CreditAmount,CreditTime,currencytype) VALUES(CreditAmount_1, CreditTime_1,currencytype_1); end;


/

