create PROCEDURE CRM_DeliveryType_Insert (fullname_1 	varchar2, description_1 	varchar2, sendtype_1 	varchar2, shipment_1 	varchar2, receive_1 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_DeliveryType ( fullname, description, sendtype, shipment, receive) VALUES ( fullname_1, description_1, sendtype_1, shipment_1, receive_1); end;


/

