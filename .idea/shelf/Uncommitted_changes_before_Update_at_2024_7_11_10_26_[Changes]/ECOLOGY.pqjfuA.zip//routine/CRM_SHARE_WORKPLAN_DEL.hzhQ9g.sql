create PROCEDURE CRM_Share_WorkPlan_Del ( crmId_1 integer, flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS m_workid integer; begin for all_cursor in( SELECT id FROM WorkPlan WHERE type_n = '3' AND crmid = to_char(crmId_1)) loop m_workid := all_cursor.id; DELETE WorkPlanShareDetail WHERE workid = m_workid AND sharelevel = 0; end loop; end ;


/

