create PROCEDURE DocDetail_SelectByCreater (resourceid_1 	integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin open thecursor for select distinct id from DocDetail where doccreaterid = resourceid_1 or ownerid = resourceid_1; end;


/

