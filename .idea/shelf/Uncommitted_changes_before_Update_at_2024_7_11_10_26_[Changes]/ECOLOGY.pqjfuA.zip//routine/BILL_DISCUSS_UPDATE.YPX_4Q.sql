create PROCEDURE Bill_Discuss_Update ( id_1     integer, billid_1 integer, requestid_1  integer, resourceid_1 integer, accepterid_1 varchar2, subject_1    varchar2, isend_1      integer, projectid_1  integer, crmid_1      integer, relatedrequestid_1   integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update bill_Discuss set billid=billid_1, requestid=requestid_1, resourceid=resourceid_1, accepterid=accepterid_1, subject=subject_1, isend=isend_1, projectid=projectid_1, crmid=crmid_1, relatedrequestid=relatedrequestid_1 where id=id_1; end;


/

