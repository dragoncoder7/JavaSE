create PROCEDURE CRM_ContactLog_Select (id_1 		integer, issub		smallint, parent	integer,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * from CRM_ContactLog WHERE (customerid = id_1) AND (issublog = issub) AND (parentid = parent) ORDER BY contactdate DESC, contacttime DESC ; end;


/

