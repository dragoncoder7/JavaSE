create PROCEDURE bill_workinfo_UpdateMainid ( formid1		integer, userid1     integer, mainid1     integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update bill_workinfo set mainid=mainid1 where billid=formid1 and status='1' and mainid is null and manager=userid1; end;


/

