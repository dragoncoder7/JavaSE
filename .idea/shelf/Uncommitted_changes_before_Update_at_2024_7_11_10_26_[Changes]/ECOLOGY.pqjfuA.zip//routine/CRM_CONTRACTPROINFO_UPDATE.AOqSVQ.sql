create PROCEDURE CRM_ContractProInfo_Update ( id_1 	integer, factNum_1 	integer, factDate_1 	char, formNum_1   varchar2 , creater_1 	integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin UPDATE CRM_ContractProInfo set factNum = factNum_1 , factDate = factDate_1 , formNum = formNum_1 , creater = creater_1 WHERE id = id_1; end;


/

