create PROCEDURE DocDetailLog_SRead ( docid_1  integer, userid_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from DocDetailLog where ((operatetype='0' and operateuserid=userid_1) or doccreater=userid_1 ) and docid=docid_1 ; end;


/

