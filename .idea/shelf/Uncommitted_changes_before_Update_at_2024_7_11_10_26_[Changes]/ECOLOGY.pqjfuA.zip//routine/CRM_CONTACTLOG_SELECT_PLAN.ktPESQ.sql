create PROCEDURE CRM_ContactLog_Select_Plan (resourceid_1 	integer,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT id,subject,customerid,contacterid,contactdate,contacttime from CRM_ContactLog WHERE (resourceid = resourceid_1) and (isfinished = 0)  ORDER BY contactdate ASC, contacttime ASC ; end;


/

