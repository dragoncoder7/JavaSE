create PROCEDURE bill_monthinfodetail_Insert (infoid        integer, type_1        integer, targetname    varchar2, targetresult    varchar2  , forecastdate    char, scale        number, point        varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin insert into bill_monthinfodetail (infoid,type,targetname,targetresult,forecastdate,scale,point) values (infoid,type_1,targetname,targetresult,forecastdate,scale,point); end;


/

