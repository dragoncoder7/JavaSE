create PROCEDURE CRM_T_ShareInfo_SID (id_1 integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for select * from CRM_T_ShareInfo where (id = id_1 ); end;


/

