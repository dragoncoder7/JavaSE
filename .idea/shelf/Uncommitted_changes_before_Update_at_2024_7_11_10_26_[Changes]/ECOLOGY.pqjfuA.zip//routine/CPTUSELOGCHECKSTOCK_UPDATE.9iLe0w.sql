create PROCEDURE CptUseLogCheckStock_Update (capitalid_1 	integer, userequest_2 	integer, usestatus_3 	varchar2, usecount_4 	integer, fee_1		decimal, realnum_1	integer, remark_1           varchar, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin update CptUseLog  SET  usecount=usecount_4, fee = fee_1, usestatus=usestatus_3, remark = remark_1   WHERE ( capitalid=capitalid_1 AND userequest=userequest_2 AND (usestatus='-1' or usestatus='-2'));  update CptCapital set capitalnum = realnum_1 where id = capitalid_1; end;


/

