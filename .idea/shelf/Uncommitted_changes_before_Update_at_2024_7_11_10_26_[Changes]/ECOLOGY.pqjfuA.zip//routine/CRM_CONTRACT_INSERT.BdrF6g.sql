create PROCEDURE CRM_Contract_Insert (name_1  varchar2   , typeId_1  integer  , docId_1  varchar2   , price_1  number  , crmId_1  integer  , contacterId_1  integer  , startDate_1  char    , endDate_1  char  , manager_1  integer  , status_1  integer  , isRemind_1  integer  , remindDay_1  integer  , creater_1  integer  , createDate_1  char   , createTime_1  char  , prjid_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin INSERT INTO CRM_Contract (name , typeId , docId , price , crmId , contacterId , startDate , endDate , manager , status , isRemind , remindDay , creater , createDate , createTime,projid)  VALUES ( name_1, typeId_1, docId_1, price_1 , crmId_1 , contacterId_1 , startDate_1 , endDate_1 , manager_1 , status_1 , isRemind_1 , remindDay_1 , creater_1 , createDate_1 , createTime_1,prjid_1); open thecursor for select * from (select  * from CRM_Contract order by id desc ) WHERE rownum =1; end;


/

