create FUNCTION crm_f_isdate(parmin VARCHAR2) RETURN NUMBER  IS val DATE; BEGIN val := TO_DATE (NVL (parmin, 'a'), 'yyyy-MM-dd'); RETURN 1; EXCEPTION WHEN OTHERS THEN RETURN 0; END;


/

