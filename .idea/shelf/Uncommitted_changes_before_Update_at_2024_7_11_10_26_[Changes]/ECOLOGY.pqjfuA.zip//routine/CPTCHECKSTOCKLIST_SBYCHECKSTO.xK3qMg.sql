create PROCEDURE CptCheckStockList_SByCheckSto (checkstockid_1 varchar2 , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptCheckStockList where checkstockid =to_number(checkstockid_1); end;


/

