create PROCEDURE CptSearchMould_SelectByUserID (userid_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptSearchMould where userid = userid_1; end;


/

