create PROCEDURE CarType_Update (   id_1 integer, name_2   varchar2, description_3    varchar2, usefee_4    number , flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin update cartype set name=name_2,description=description_3,usefee=usefee_4 where id=id_1; end;


/

