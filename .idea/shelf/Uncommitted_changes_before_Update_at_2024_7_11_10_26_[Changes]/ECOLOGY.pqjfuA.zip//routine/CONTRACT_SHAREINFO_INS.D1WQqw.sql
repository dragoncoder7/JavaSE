create PROCEDURE CONTRACT_SHAREINFO_INS( relateditemid_1 INTEGER, sharetype_1 SMALLINT, seclevel_1 SMALLINT, seclevelMax_1 SMALLINT, rolelevel_1 SMALLINT, sharelevel_1 SMALLINT, userid_1 INTEGER, departmentid_1 INTEGER, subcompanyid_1 INTEGER, roleid_1 INTEGER, foralluser_1 SMALLINT, flag out INTEGER, msg out VARCHAR2, thecursor IN OUT cursor_define.weavercursor ) AS BEGIN INSERT INTO Contract_ShareInfo ( relateditemid, sharetype, seclevel, seclevelMax, rolelevel, sharelevel, userid, departmentid, subcompanyid, roleid, foralluser ) VALUES ( relateditemid_1, sharetype_1, seclevel_1, seclevelMax_1, rolelevel_1, sharelevel_1, userid_1, departmentid_1, subcompanyid_1, roleid_1, foralluser_1 ) ; flag := 1 ; msg := 'ok' ; END ;


/

