create PROCEDURE CarDriverDataPara_Delete (driverdataid_1       integer, flag out integer, msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin delete from CarDriverDataPara where driverdataid = driverdataid_1; end;


/

