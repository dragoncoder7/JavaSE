create PROCEDURE CptUseLogMove_Insert (capitalid_1 	integer, usedate_2 	char, departmentid_1   integer, costcenterid_1   integer, resourceid_1      integer, usecount_5 	decimal, userequest_7  integer, location_1	varchar2, fee_1	     number, remark_11 	varchar2, olddepartmentid_1 integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CptUseLog ( capitalid, usedate, usedeptid, useresourceid, usecount, useaddress, userequest, maintaincompany, fee, usestatus, remark, olddeptid) VALUES ( capitalid_1, usedate_2, departmentid_1, resourceid_1, 1, location_1, userequest_7, '', fee_1, '-4', remark_11, olddepartmentid_1); Update CptCapital Set departmentid = departmentid_1, costcenterid = costcenterid_1, resourceid    = resourceid_1 where id = capitalid_1; end;


/

