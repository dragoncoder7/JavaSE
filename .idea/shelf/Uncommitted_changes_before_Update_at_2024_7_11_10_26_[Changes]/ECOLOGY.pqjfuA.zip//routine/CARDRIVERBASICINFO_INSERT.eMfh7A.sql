create PROCEDURE CarDriverBasicinfo_Insert (   basicsalary_1    number, overtimepara_2   number , receptionpara_3  number, basicKM_4        number , basicKMpara_5    number , basictime_6      number , basictimepara_7  number , basicout_8       integer, basicoutpara_9   number , publicpara_10     number , flag out integer , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor	) AS count_1 integer; begin select count(*) into count_1 from cardriverbasicinfo; if count_1=0 then insert into cardriverbasicinfo values (basicsalary_1,overtimepara_2,receptionpara_3,basicKM_4, basicKMpara_5,basictime_6,basictimepara_7,basicout_8,basicoutpara_9,publicpara_10); else update cardriverbasicinfo set basicsalary=basicsalary_1,overtimepara=overtimepara_2, receptionpara=receptionpara_3,basicKM=basicKM_4,basicKMpara=basicKMpara_5, basictime=basictime_6,basictimepara=basictimepara_7,basicout=basicout_8,basicoutpara=basicoutpara_9,publicpara=publicpara_10; end if; end;


/

