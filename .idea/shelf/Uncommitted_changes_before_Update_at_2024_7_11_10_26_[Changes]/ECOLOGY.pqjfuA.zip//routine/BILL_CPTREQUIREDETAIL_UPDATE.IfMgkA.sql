create PROCEDURE bill_CptRequireDetail_Update (id_1 	integer, cpttype1 	integer, cptid_1 	integer, number_2 	number, unitprice_3 	number, needdate_5 	varchar2, purpose_6 	varchar2, cptdesc_7 	varchar2, buynumber1 	number, adjustnumber1 	number, fetchnumber1 	number, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE  bill_CptRequireDetail  SET cpttype	 = cpttype1, cptid	 = cptid_1, number_n	 = number_2, unitprice	 = unitprice_3, needdate	 = needdate_5, purpose	 = purpose_6, cptdesc	 = cptdesc_7 , buynumber	 = buynumber1 , adjustnumber	 = adjustnumber1 , fetchnumber	 = fetchnumber1  WHERE ( id	 = id_1); end;


/

