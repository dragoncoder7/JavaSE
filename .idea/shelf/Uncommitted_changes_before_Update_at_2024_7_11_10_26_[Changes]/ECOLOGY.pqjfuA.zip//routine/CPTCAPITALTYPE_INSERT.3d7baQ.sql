create PROCEDURE CptCapitalType_Insert (name_1 	varchar2, description_2 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin insert into CptCapitalType  ( name,description) VALUES ( name_1, description_2); end;


/

