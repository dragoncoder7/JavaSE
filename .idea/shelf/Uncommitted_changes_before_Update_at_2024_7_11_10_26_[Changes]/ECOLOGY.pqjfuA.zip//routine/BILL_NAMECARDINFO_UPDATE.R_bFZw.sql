create PROCEDURE Bill_NameCardinfo_Update ( resourceid_1		integer, cname_1          varchar2, cjobtitle_1      varchar2, cdepartment_1    varchar2, phone_1          varchar2, mobile_1         varchar2, email_1          varchar2, ename_1          varchar2, ejobtitle_1      varchar2, edepartment_1    varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update bill_namecardinfo set cname=cname_1, cjobtitle=cjobtitle_1, cdepartment=cdepartment_1, phone=phone_1, mobile=mobile_1, email=email_1, ename=ename_1, ejobtitle=ejobtitle_1, edepartment=edepartment_1 where resourceid=resourceid_1; end;


/

