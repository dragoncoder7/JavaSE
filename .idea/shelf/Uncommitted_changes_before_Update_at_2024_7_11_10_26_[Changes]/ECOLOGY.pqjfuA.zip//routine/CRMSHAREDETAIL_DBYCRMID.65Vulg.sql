create PROCEDURE CrmShareDetail_DByCrmId (crmid_1 	integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin DELETE CrmShareDetail WHERE ( crmid	 = crmid_1); end;


/

