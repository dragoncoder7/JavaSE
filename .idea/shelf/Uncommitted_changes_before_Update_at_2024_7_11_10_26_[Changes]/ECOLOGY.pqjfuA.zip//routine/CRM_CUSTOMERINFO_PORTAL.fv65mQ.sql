create PROCEDURE CRM_CustomerInfo_Portal (id1 integer, portalstatus1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerInfo  SET portalstatus = portalstatus1 WHERE ( id = id1); end;


/

