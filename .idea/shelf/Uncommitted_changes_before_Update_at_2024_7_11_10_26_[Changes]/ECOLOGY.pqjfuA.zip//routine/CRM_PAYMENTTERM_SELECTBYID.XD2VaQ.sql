create PROCEDURE CRM_PaymentTerm_SelectByID (id1 	int, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_PaymentTerm WHERE ( id	 = id1); end;


/

