create PROCEDURE CRM_T_SHAREINFO_INSERT ( relateditemid_1 INTEGER, sharetype_1 SMALLINT, seclevel_1 SMALLINT, seclevelMax_1 SMALLINT, rolelevel_1 SMALLINT, sharelevel_1 SMALLINT, userid_1 INTEGER, departmentid_1 INTEGER, roleid_1 INTEGER, foralluser_1 SMALLINT, subcompanyid_1 INTEGER, flag out INTEGER, msg out VARCHAR2, thecursor IN OUT cursor_define.weavercursor ) AS BEGIN INSERT INTO CRM_T_ShareInfo ( relateditemid, sharetype, seclevel, seclevelMax, rolelevel, sharelevel, userid, departmentid, roleid, foralluser, subcompanyid ) VALUES ( relateditemid_1, sharetype_1, seclevel_1, seclevelMax_1, rolelevel_1, sharelevel_1, userid_1, departmentid_1, roleid_1, foralluser_1, subcompanyid_1 ) ; END ;


/

