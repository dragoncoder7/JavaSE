create PROCEDURE CRM_SectorInfo_Insert (fullname_1 	varchar2, description_1 	varchar2, parentid_1 	integer, seclevel_1 	integer, sectors_1	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS id_1  integer; id_2  integer; begin id_1 := 1; id_2 := 0; select count(*) INTO id_2  from CRM_SectorInfo; if(id_2 > 0) then select max(id) INTO id_1  from CRM_SectorInfo ; id_1 := id_1+1; end if; INSERT INTO CRM_SectorInfo (id, fullname, description, parentid, seclevel, sectors) VALUES (id_1, fullname_1, description_1, parentid_1, seclevel_1, sectors_1); end;


/

