create PROCEDURE CRM_SectorInfo_SelectAllInfo ( flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_SectorInfo ; end;


/

