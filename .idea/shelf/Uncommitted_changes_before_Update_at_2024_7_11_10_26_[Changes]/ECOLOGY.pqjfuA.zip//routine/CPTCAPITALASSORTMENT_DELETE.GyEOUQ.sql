create PROCEDURE CptCapitalAssortment_Delete (id_1 	int, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS count_1 integer ; supassortmentid_1 integer; begin select  capitalcount into count_1  from CptCapitalAssortment where id =  id_1 ; if  count_1 <> 0  then open thecursor for select -1 from dual ; return ; end  if; select  subassortmentcount into count_1 from CptCapitalAssortment where id =  id_1 ; if  count_1 <> 0 then open thecursor for select -1 from dual; return ; end  if; select  supassortmentid into supassortmentid_1 from CptCapitalAssortment where id=  id_1; update CptCapitalAssortment set subassortmentcount = subassortmentcount-1 where id=  supassortmentid_1; DELETE CptCapitalAssortment WHERE id =  id_1; end;


/

