create PROCEDURE CRM_ProductTable_insert ( sellchanceid_1 integer , productid_1 integer , assetunitid_1 integer , currencyid_1 integer , salesprice_1 number , salesnum_1 integer , totelprice_1 number , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert INTO CRM_ProductTable ( sellchanceid , productid , assetunitid, currencyid , salesprice , salesnum, totelprice ) values ( sellchanceid_1  , productid_1  , assetunitid_1  , currencyid_1  , salesprice_1 , salesnum_1  , totelprice_1 ); end;


/

