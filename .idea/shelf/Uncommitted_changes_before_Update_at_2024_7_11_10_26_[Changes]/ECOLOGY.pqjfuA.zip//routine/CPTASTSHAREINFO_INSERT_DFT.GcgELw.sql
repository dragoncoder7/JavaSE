create PROCEDURE CptAstShareInfo_Insert_dft(relateditemid_1 integer, sharetype_2     integer, seclevel_3      integer, rolelevel_4     smallint, sharelevel_5    smallint, userid_6        integer, departmentid_7  integer, roleid_8        integer, foralluser_9    smallint, sharefrom_10    integer, subcompanyid_11 integer, seclevelmax_12  integer, jobtitleid_13   integer, joblevel_14     integer, scopeid_15      varchar2, flag            out integer, msg             out varchar2, thecursor       IN OUT cursor_define.weavercursor) AS begin INSERT INTO CptCapitalShareInfo (relateditemid, sharetype, seclevel, rolelevel, sharelevel, userid, departmentid, roleid, foralluser, sharefrom, subcompanyid, isdefault, seclevelmax, jobtitleid, joblevel, scopeid) VALUES (relateditemid_1, sharetype_2, seclevel_3, rolelevel_4, sharelevel_5, userid_6, departmentid_7, roleid_8, foralluser_9, sharefrom_10, subcompanyid_11, 1, seclevelmax_12, jobtitleid_13, joblevel_14, scopeid_15); end;


/

