create PROCEDURE docDetailLog_QueryByDate (fromdate_1 char , todate_1 	char , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT docid, SUM(readCount) AS COUNT FROM docReadTag where docid in (select id from docdetail) and docid in (SELECT docid FROM DocDetailLog WHERE (operatedate >= fromdate_1) AND (operatedate <= todate_1))GROUP BY docid ORDER BY COUNT DESC; end;


/

