create PROCEDURE CRM_ContractExch_Insert (contractId_1 integer  , name_1  varchar2   , remark_1 varchar2  , creater_1  integer  , createDate_1  char    , createTime_1  char  , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin INSERT INTO CRM_Contract_Exchange (contractId , name , remark , creater , createDate , createTime)  VALUES (contractId_1 , name_1, remark_1, creater_1 , createDate_1 , createTime_1); end;


/

