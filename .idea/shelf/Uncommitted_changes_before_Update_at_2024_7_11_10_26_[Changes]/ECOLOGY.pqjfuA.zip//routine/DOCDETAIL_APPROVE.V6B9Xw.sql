create PROCEDURE DocDetail_Approve ( approverid_1		integer, docstatus_1      char, approvedate_1    char, approvetime_1    char, docid_1          integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin update DocDetail set docstatus=docstatus_1,docapproveuserid=approverid_1,docapprovedate=approvedate_1,docapprovetime=approvetime_1 where id=docid_1; end;


/

