create PROCEDURE CRM_Modify_Select (id_1 	int, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_Modify WHERE ( customerid	 = id_1) ORDER BY modifydate DESC, modifytime DESC ; end;


/

