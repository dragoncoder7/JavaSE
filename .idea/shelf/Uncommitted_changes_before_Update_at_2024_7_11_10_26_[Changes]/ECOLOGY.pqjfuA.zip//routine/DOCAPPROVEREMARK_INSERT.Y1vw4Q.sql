create PROCEDURE DocApproveRemark_Insert ( docid_1		integer, approveremark_1      varchar2, approverid_1     integer, approvedate_1    char, approvetime_1    char, isapprover_1      char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into docApproveRemark (docid,approveremark,approverid,approvedate,approvetime,isapprover) values(docid_1,approveremark_1,approverid_1,approvedate_1,approvetime_1,isapprover_1); end;


/

