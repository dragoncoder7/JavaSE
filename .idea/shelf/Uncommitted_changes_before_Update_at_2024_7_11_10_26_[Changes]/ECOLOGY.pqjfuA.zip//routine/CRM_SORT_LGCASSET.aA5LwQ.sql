create procedure CRM_Sort_LgcAsset is supassortmentstr1 VARCHAR(1000); supassortmentstr2 VARCHAR(1000); v_sqlfalg VARCHAR(1000); CURSOR RS IS select id,supassortmentid,supassortmentstr from LgcAssetAssortment where supassortmentid is not null ORDER BY id asc; RS_ROW RS%ROWTYPE; BEGIN FOR RS_ROW IN RS LOOP BEGIN IF RS_ROW.supassortmentid=0 THEN supassortmentstr1:='0|'; ELSE v_sqlfalg:= 'select supassortmentstr from LgcAssetAssortment where id='''||RS_ROW.supassortmentid|| ''''; execute immediate v_sqlfalg into supassortmentstr2; supassortmentstr1:=supassortmentstr2||RS_ROW.supassortmentid||'|'; END IF; UPDATE LgcAssetAssortment SET supassortmentstr=supassortmentstr1 WHERE id=RS_ROW.id;END;END LOOP;END;


/

