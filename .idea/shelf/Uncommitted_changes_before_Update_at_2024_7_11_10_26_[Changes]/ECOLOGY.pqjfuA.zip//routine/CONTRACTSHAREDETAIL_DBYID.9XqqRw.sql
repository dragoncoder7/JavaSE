create PROCEDURE ContractShareDetail_DById ( contractid_1 	integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE ContractShareDetail WHERE ( contractid= contractid_1) ; end;


/

