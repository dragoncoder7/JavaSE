create PROCEDURE CRM_SellChance_Delete ( id_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin delete CRM_SellChance WHERE id=id_1; end;


/

