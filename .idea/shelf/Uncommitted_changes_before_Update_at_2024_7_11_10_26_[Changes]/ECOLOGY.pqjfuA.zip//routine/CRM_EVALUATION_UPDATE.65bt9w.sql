create PROCEDURE CRM_Evaluation_Update (id_1 	integer , name_1 	varchar2, proportion_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_Evaluation SET name = name_1, proportion = proportion_1 where id = id_1; end;


/

