create PROCEDURE CptShareDetail_Insert (capitalid_1 	integer, userid_1 	integer, usertype_1 	integer, sharelevel_1 	integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin INSERT INTO CptShareDetail ( cptid,	 userid , usertype, sharelevel )  VALUES ( capitalid_1,userid_1, usertype_1, sharelevel_1 ); end;


/

