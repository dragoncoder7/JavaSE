create PROCEDURE bill_HrmTime_SelectByID (id1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for  select * from bill_hrmtime where id=id1; end;


/

