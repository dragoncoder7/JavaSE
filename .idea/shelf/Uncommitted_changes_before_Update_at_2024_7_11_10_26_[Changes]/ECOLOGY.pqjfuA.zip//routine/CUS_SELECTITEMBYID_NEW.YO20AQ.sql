create PROCEDURE cus_selectitembyid_new(id_1      VARCHAR2, isbill_1  VARCHAR2, flag      OUT INTEGER, msg       OUT VARCHAR2, thecursor IN OUT cursor_define.weavercursor) AS BEGIN OPEN thecursor FOR SELECT  * FROM    cus_SelectItem WHERE   fieldid = id_1 ORDER BY fieldorder ,fieldid; END;


/

