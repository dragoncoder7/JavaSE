create PROCEDURE CRM_ContractProduct_Select (contractId_1 integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for SELECT * FROM CRM_ContractProduct where contractId = contractId_1 order by id ; end;


/

