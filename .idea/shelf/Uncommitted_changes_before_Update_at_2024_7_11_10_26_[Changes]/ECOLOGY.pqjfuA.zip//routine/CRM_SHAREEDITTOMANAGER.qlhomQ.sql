create PROCEDURE CRM_ShareEditToManager( crmId_1 integer, managerId_1 integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS count_1 integer; begin SELECT count(id) into count_1 FROM CRM_ShareInfo WHERE relateditemid = crmId_1 AND sharetype = 1 AND userid = managerId_1; if count_1 <> 0 then UPDATE CRM_ShareInfo SET sharelevel = 2 WHERE relateditemid =crmId_1 AND sharetype = 1 AND userid = managerId_1; ELSE INSERT INTO CRM_ShareInfo(relateditemid, sharetype, sharelevel, userid,contents) VALUES(crmId_1, 1, 2, managerId_1,managerId_1); end if; end;


/

