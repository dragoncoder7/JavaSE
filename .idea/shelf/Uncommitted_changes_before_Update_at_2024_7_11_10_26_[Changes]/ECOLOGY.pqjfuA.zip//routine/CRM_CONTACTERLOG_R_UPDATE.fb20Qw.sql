create PROCEDURE CRM_ContacterLog_R_Update (customerid_1 	integer, daytype_1	integer, before_1	integer, isremind_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_ContacterLog_Remind SET daytype = daytype_1 , before = before_1 , isremind = isremind_1 where  customerid = customerid_1; end;


/

