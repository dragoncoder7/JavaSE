create PROCEDURE bill_CptApplyDetail_Update (id_1 	integer, cpttype1 	integer, cptid_3 	integer, number_4 	number, unitprice_5 	number, amount_6 	number, needdate_7 	varchar2, purpose_8 	varchar2, cptdesc_9 	varchar2, capitalid1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE  bill_CptApplyDetail  SET cpttype	 = cpttype1, cptid	 = cptid_3, number_n	 = number_4, unitprice	 = unitprice_5, amount	 = amount_6, needdate	 = needdate_7, purpose	 = purpose_8, cptdesc	 = cptdesc_9 , capitalid	 = capitalid1  WHERE ( id	 = id_1); end;


/

