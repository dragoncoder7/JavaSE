create PROCEDURE CptDepreMethod2_Delete (id_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin DELETE CptDepreMethod2  WHERE ( id	 = id_1); end;


/

