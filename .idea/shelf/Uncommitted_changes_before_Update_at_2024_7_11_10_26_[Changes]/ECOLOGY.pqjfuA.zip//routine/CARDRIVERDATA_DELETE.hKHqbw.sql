create PROCEDURE CarDriverData_Delete (id_1        integer, flag out integer, msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin delete from CarDriverData where id=id_1; end;


/

