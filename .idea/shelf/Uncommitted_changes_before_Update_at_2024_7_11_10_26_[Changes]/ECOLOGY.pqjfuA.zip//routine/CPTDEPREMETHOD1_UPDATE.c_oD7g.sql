create PROCEDURE CptDepreMethod1_Update (id_1 	integer, name_2 	varchar2, description_3 	varchar2, depretype_4 	char, timelimit_5 	decimal, startunit_6 	decimal, endunit_7 	decimal, deprefunc_8 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin update CptDepreMethod1  SET  name=name_2, description=description_3, depretype=depretype_4, timelimit=timelimit_5, startunit=startunit_6, endunit=endunit_7, deprefunc=deprefunc_8  WHERE ( id=id_1); end;


/

