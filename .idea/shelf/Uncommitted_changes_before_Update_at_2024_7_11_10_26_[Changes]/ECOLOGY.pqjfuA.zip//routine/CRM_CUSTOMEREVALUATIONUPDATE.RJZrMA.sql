create PROCEDURE CRM_CustomerEvaluationUpdate (id_1 	integer , evaluation_1 	number, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_CustomerInfo SET evaluation = evaluation_1 where id = id_1; end;


/

