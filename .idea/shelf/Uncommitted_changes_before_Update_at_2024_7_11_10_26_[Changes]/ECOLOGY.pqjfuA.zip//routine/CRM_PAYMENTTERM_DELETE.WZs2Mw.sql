create PROCEDURE CRM_PaymentTerm_Delete (id1 	int,flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE CRM_PaymentTerm WHERE ( id	 = id1) ; end;


/

