create PROCEDURE CRM_DeliveryType_SelectByID (id1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_DeliveryType WHERE ( id	 = id1) ; end;


/

