create PROCEDURE bill_itemusage_UpdateStatus (id1 integer, usestatus1 char ,flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin update bill_itemusage set usestatus = usestatus1 where id=id1; end;


/

