create PROCEDURE CRM_TradeInfo_Update (id_1 	integer, fullname_1 	varchar2, rangelower_1 	varchar2, rangeupper_1 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_TradeInfo SET  fullname	 = fullname_1, rangelower	 = to_number (rangelower_1), rangeupper	 = to_number(rangeupper_1) WHERE ( id	 = id_1) ; end;


/

