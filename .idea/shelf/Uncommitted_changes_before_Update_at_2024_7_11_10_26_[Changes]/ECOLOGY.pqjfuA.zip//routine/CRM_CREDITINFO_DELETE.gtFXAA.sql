create PROCEDURE CRM_CreditInfo_Delete (id1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE CRM_CreditInfo WHERE ( id	 = id1); end;


/

