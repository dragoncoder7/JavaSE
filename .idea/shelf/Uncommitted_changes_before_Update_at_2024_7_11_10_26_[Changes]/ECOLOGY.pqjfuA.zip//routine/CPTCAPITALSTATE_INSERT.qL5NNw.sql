create PROCEDURE CptCapitalState_Insert ( name_2 	varchar2, description_3 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)   AS begin INSERT INTO CptCapitalState ( name, description)  VALUES ( name_2, description_3); end;


/

