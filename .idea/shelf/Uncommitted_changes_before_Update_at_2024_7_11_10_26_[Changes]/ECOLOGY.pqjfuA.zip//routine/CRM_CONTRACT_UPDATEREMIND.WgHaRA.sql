create PROCEDURE CRM_Contract_UpdateRemind (id_1 	integer , isRemind_1  integer , remindDay_1  char  , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_Contract SET isRemind = isRemind_1, remindDay = remindDay_1   where id = id_1; end;


/

