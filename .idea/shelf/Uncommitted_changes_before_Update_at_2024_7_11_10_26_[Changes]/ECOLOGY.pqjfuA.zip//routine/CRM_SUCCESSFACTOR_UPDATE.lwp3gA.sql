create PROCEDURE CRM_Successfactor_Update (id_1	 	integer, fullname_1 	varchar2, description_1 	varchar2, flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin UPDATE CRM_Successfactor SET  fullname	 = fullname_1, description	 = description_1 WHERE ( id	 = id_1)   ; end;


/

