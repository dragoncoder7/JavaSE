create PROCEDURE CptCapitalModifyField_SAll ( flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin open thecursor for select * from CptCapitalModifyField order by field  ; end;


/

