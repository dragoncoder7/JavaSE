create PROCEDURE deleteVotingRemark as votingidtemp integer; v_id integer; begin for voting_cursor in (select id from voting where status = 1) loop select count(votingid) into v_id from votingoption where votingid = votingidtemp; if v_id = 0 then delete from votingremark where votingid = votingidtemp; delete from votingresourceremark where votingid = votingidtemp; end if; end loop; end;


/

