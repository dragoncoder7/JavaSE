create PROCEDURE CRM_T_ShareInfo_Delete (id_1 integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin DELETE from CRM_T_ShareInfo  WHERE ( id = id_1); end;


/

