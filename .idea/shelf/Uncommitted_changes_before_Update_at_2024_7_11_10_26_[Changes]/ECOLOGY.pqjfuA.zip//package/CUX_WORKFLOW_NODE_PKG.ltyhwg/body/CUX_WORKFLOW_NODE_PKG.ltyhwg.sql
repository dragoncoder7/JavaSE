create package body cux_workflow_node_pkg is

  procedure isend_node(p_request_id    varchar2,
                       p_node_id       varchar2,
                       x_end_node_flag out varchar2,
                       x_code          out varchar2,
                       x_msg           out varchar2) is
    l_approve_path varchar2(2000); --单据的审批流   
    l_sql          varchar2(2000);
    l_workflowid   number;
    cursor c is
      select a.workflowname, b.tablename, wr.workflowid
        from workflow_requestbase wr, --审批流
             workflow_base        a,
             workflow_bill        b
       where 1 = 1
         and wr.workflowid = a.id
         and a.formid = b.id
         and a.isbill = 1 --0：表单1：单据
            -- and a.workflowname like '%标准%'
         and wr.requestid = p_request_id;
  
    cursor c_node is
      select a.nodeid,
             wn1.nodename    from_node,
             wn1.isstart,
             wn2.nodename    to_node,
             wn2.isend,
             b.elementvalue1
        from workflow_nodelink   a,
             rule_expressionbase b, --暂时不考虑运算符和相关运算的问题
             workflow_nodebase   wn1,
             workflow_nodebase   wn2
       where a.workflowid = l_workflowid
         and a.nodeid = p_node_id
         and a.newrule = b.ruleid
         and a.nodeid = wn1.id
         and a.destnodeid = wn2.id
         and l_approve_path like '%' || b.elementvalue1 || '%';
  
  begin
    x_end_node_flag := 'N';
  
    for r in c loop
      l_workflowid := r.workflowid;
      --获取审批流路径
      begin
        l_sql := 'select a.approve_path from formtable_main_2370 a where a.approve_path is not null and  a.requestid = ' ||
                 p_request_id;
        EXECUTE IMMEDIATE l_sql
          INTO l_approve_path;
      exception
        when others then
          x_code := 'E';
          x_msg  := '无法获得单据的审批流：cux_workflow_node_pkg.isend_node';
          return;
      end;
    
      for r_node in c_node loop
        x_end_node_flag := case
                             when r_node.isend = 1 then
                              'Y'
                             ELSE
                              'N'
                           END;
        x_code          := 'S';
        x_msg           := '成功';
        return;
      end loop;
    
    end loop;
  
    x_code := 'E';
    x_msg  := '未处理错误：cux_workflow_node_pkg.isend_node';
  exception
    WHEN others then
      x_end_node_flag := 'N';
      x_code          := 'E';
      x_msg           := '失败：cux_workflow_node_pkg.isend_node,' ||
                         substr(sqlerrm, 1, 1000);
  end;

  function isend_node(p_request_id varchar2, p_node_id varchar2)
    return varchar2 is
    l_end_node_flag varchar2(2);
    l_code          varchar2(2);
    l_msg           varchar2(2000);
  begin
    isend_node(p_request_id    => p_request_id,
               p_node_id       => p_node_id,
               x_end_node_flag => l_end_node_flag,
               x_code          => l_code,
               x_msg           => l_msg);
  
    return l_end_node_flag;
  end;

  procedure isstart_node(p_request_id      number,
                         p_node_id         number,
                         x_start_node_flag out varchar2,
                         x_code            out varchar2,
                         x_msg             out varchar2) is
  
  begin
    select nvl(max('Y'), 'N')
      INTO x_start_node_flag
      from workflow_nodebase a
     where a.id = p_node_id
       AND A.ISSTART = 1;
  
    x_code := 'S';
    x_msg  := '成功';
  exception
    WHEN others then
      x_start_node_flag := 'N';
      x_code            := 'E';
      x_msg             := '失败：cux_workflow_node_pkg.isstart_node,' ||
                           substr(sqlerrm, 1, 1000);
  end;

  function isstart_node(p_request_id number, p_node_id number)
    return varchar2 is
    l_start_node_flag varchar2(2);
    l_code            varchar2(2);
    l_msg             varchar2(2000);
  begin
  
    isstart_node(p_request_id      => p_request_id,
                 p_node_id         => p_node_id,
                 x_start_node_flag => l_start_node_flag,
                 x_code            => l_code,
                 x_msg             => l_msg);
  
    return l_start_node_flag;
  end;

function is_finish(p_po_header_id number ) return varchar2 is 
    l_temp varchar2(2):= 'N';
  begin 
    select NVL(max('Y'),'N') into l_temp 
    from requestiderprecord   rec, --ERP传送OA记录
         workflow_requestbase wr, --审批流基础信息表
         workflow_nodebase    wn --审批流节点信息表
     where rec.erpheadid =p_po_header_id 
       and rec.requestid = wr.requestid
       and wr.currentnodeid = wn.id
       and wn.isend = 1 --归档结点 
       and rec.erpdjlx = 'PO_STANDARD'
       ;
       
       return l_temp ;
  end ;  
  
  procedure delete_erp2oa_rec(p_po_header_id number ) is 
    PRAGMA AUTONOMOUS_TRANSACTION;
  begin 
    delete from requestiderprecord a where a.erpheadid=p_po_header_id
    and a.erpdjlx='PO_STANDARD'
     ;
    commit ; 
  end ;
  procedure isend_node_pay(p_request_id    varchar2,
                       p_node_id       varchar2,
                       x_end_node_flag out varchar2,
                       x_code          out varchar2,
                       x_msg           out varchar2) is
    l_approve_path varchar2(2000); --单据的审批流   
    l_sql          varchar2(2000);
    l_workflowid   number;
    l_tablename    varchar2(200);
    cursor c is
      select a.workflowname, b.tablename, wr.workflowid
        from workflow_requestbase wr, --审批流
             workflow_base        a,
             workflow_bill        b
       where 1 = 1
         and wr.workflowid = a.id
         and a.formid = b.id
         and a.isbill = 1 --0：表单1：单据
            -- and a.workflowname like '%标准%'
         and wr.requestid = p_request_id;
  
    cursor c_node is
      select a.nodeid,
             wn1.nodename    from_node,
             wn1.isstart,
             wn2.nodename    to_node,
             wn2.isend,
             b.elementvalue1
        from workflow_nodelink   a,
             rule_expressionbase b, --暂时不考虑运算符和相关运算的问题
             workflow_nodebase   wn1,
             workflow_nodebase   wn2
       where a.workflowid = l_workflowid
         and a.nodeid = p_node_id
         and a.newrule = b.ruleid
         and a.nodeid = wn1.id
         and a.destnodeid = wn2.id
         and l_approve_path like '%' || b.elementvalue1 || '%';
  
  begin
    x_end_node_flag := 'N';
  
    for r in c loop
      l_workflowid := r.workflowid;
      l_tablename  := r.tablename;
      --获取审批流路径
      begin
        l_sql := 'select a.SPLC from '|| l_tablename ||' a where a.SPLC is not null and  a.requestid = ' ||
                 p_request_id;
        EXECUTE IMMEDIATE l_sql
          INTO l_approve_path;
      exception
        when others then
          x_code := 'E';
          x_msg  := '无法获得单据的审批流：cux_workflow_node_pkg.isend_node';
          return;
      end;
    
      for r_node in c_node loop
        x_end_node_flag := case
                             when r_node.isend = 1 then
                              'Y'
                             ELSE
                              'N'
                           END;
        x_code          := 'S';
        x_msg           := '成功';
        return;
      end loop;
    
    end loop;
  
    x_code := 'E';
    x_msg  := '未处理错误：cux_workflow_node_pkg.isend_node';
  exception
    WHEN others then
      x_end_node_flag := 'N';
      x_code          := 'E';
      x_msg           := '失败：cux_workflow_node_pkg.isend_node,' ||
                         substr(sqlerrm, 1, 1000);
  end;
  function isend_node_pay(p_request_id varchar2, p_node_id varchar2)
    return varchar2 is
    l_end_node_flag varchar2(2);
    l_code          varchar2(2);
    l_msg           varchar2(2000);
  begin
    isend_node_pay(p_request_id    => p_request_id,
               p_node_id       => p_node_id,
               x_end_node_flag => l_end_node_flag,
               x_code          => l_code,
               x_msg           => l_msg);
  
    return l_end_node_flag;
  end;
end cux_workflow_node_pkg;
/

