create package cursor_define as type weavercursor is ref cursor ; end ;


/

