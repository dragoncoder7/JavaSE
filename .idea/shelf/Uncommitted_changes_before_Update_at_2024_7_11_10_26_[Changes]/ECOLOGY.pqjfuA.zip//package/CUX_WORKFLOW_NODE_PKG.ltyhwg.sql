create package cux_workflow_node_pkg is

  -- Author  : ADMINISTRATOR
  -- Created : 2022/05/17 13:48:42
  -- Purpose : 处理相关节点的问题
  --环境：OA

  /*
  作用：在批准时，判断指定节点是否已是最后的节点 
  参数： p_request_id 审批流ID
         p_node_id  当前审批节点
         x_end_node_flag : Y 最后节点， N 非最后节点
         x_code ： S 正常完成 ， E 执行中出现异常
         x_msg ：相关信息
  */
  procedure isend_node(p_request_id    varchar2,
                       p_node_id       varchar2,
                       x_end_node_flag out varchar2,
                       x_code          out varchar2,
                       x_msg           out varchar2);
                       
  -- Y 最后节点， N 非最后节点 ,X 异常 
  function isend_node(p_request_id varchar2, p_node_id varchar2)
    return varchar2;
  /*
  作用：在驳回时，判断指定节点是否已是创建的节点 
  参数： p_request_id 审批流ID
         p_node_id  当前审批节点
         x_start_node_flag : Y 起始节点， N 非起始节点
         x_code ： S 正常完成 ， E 执行中出现异常
         x_msg ：相关信息
  */
  procedure isstart_node(p_request_id      number,
                         p_node_id         number,
                         x_start_node_flag out varchar2,
                         x_code            out varchar2,
                         x_msg             out varchar2);

  -- Y 起始节点， N 非起始节点 ,X 异常
  function isstart_node(p_request_id number, p_node_id number)
    return varchar2;
    
    
  --判断采购订单审批是否已归档， 
  --有业务情景，当审批流已归档，需要删除ERP转OA记录（requestiderprecord），才能重新提单  
  function is_finish(p_po_header_id number ) return varchar2 ;
  
  --当审批流已归档，需要删除ERP转OA记录（requestiderprecord），才能重新提单  
  procedure delete_erp2oa_rec(p_po_header_id number );
  
  function isend_node_pay(p_request_id varchar2, p_node_id varchar2)
    return varchar2;

end cux_workflow_node_pkg;
/

