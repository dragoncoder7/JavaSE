create package body cux_eam_workflow_pkg is

  function get_leader_info(p_department_id number ) return varchar2 is 
    cursor c is 
    with t as
 (select a.id,
         a.supdepid,
         a.departmentname,
         (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
            from hrmdepartment hd
          connect by prior hd.id = hd.supdepid
           start with hd.id = a.id) buttom_str,
         (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
            from hrmdepartment hd
          connect by hd.id = prior hd.supdepid
           start with hd.id = a.id) top_str
  
    from hrmdepartment a --部门 
   where a.id = 47)

select t.id id,
       t.departmentname,
       f.field0  eam_user_id,
       
       case
         when (regexp_count(top_str, ',') = 1 and
              regexp_count(top_str || buttom_str, ',') - 1 = 1) or
              (regexp_count(top_str, ',') = 2 and
              regexp_count(top_str || buttom_str, ',') - 1 in (2, 3)) then
          t.departmentname || '部门经理'
         when regexp_count(top_str, ',') = 1 and
              regexp_count(top_str || buttom_str, ',') - 1 != 1 then
          t.departmentname || '中心经理'
         when regexp_count(top_str, ',') = 2 and
              regexp_count(top_str || buttom_str, ',') - 1 in (4, 5) then
          t.departmentname || '总监'
         when regexp_count(top_str, ',') = 3 and
              regexp_count(top_str || buttom_str, ',') - 1 = 3 then
          t.departmentname || '科室主管'
         when regexp_count(top_str, ',') = 3 and
              regexp_count(top_str || buttom_str, ',') - 1 in (4, 5) then
          t.departmentname || '部门经理'
         when regexp_count(top_str, ',') = 4 and
              regexp_count(top_str || buttom_str, ',') - 1 in (4, 5) then
          t.departmentname || '科室主管'
         when regexp_count(top_str, ',') = 5 and
              regexp_count(top_str || buttom_str, ',') - 1 = 5 then
          t.departmentname || '组长'
         else
          null
       end gw, --领导岗位
       /*case
         when regexp_count(top_str, ',') = 1 then
          d.bmfgld
         when regexp_count(top_str, ',') = 2 then
          d.bmfzr
         when regexp_count(top_str, ',') = 3 then
          d.zzjgbmfzr
         when regexp_count(top_str, ',') = 4 then
          d.ywspr
         else
          null
       end leader --领导,有多个 */
       e.id oa_user_id 

  from t,
       hrmdepartmentdefined d, --部门岗位
       hrmresource          e, -- 人员
       cus_fielddata        f --EAM人员表
 where t.id = d.deptid
   and case
         when regexp_count(top_str, ',') = 1 then
          d.bmfgld
         when regexp_count(top_str, ',') = 2 then
          d.bmfzr
         when regexp_count(top_str, ',') = 3 then
          d.zzjgbmfzr
         when regexp_count(top_str, ',') = 4 then
          d.ywspr
         else
          null
       end is not null
   and ',' || (case
         when regexp_count(top_str, ',') = 1 then
          d.bmfgld
         when regexp_count(top_str, ',') = 2 then
          d.bmfzr
         when regexp_count(top_str, ',') = 3 then
          d.zzjgbmfzr
         when regexp_count(top_str, ',') = 4 then
          d.ywspr
         else
          null
       end) || ',' like '%,' || e.id || ',%'
   and e.id = f.field2

;

l_temp varchar2(2000) ;
  begin 
    for r in c loop 
      if c%rowcount = 1 then 
        l_temp :=r.gw||',';
      end if ;  
    
      l_temp :=  l_temp||r.oa_user_id||'='||r.eam_user_id ||',' ;
    end loop ;
    
    return l_temp ;
  end ;   

  
  
  
end cux_eam_workflow_pkg;
/

