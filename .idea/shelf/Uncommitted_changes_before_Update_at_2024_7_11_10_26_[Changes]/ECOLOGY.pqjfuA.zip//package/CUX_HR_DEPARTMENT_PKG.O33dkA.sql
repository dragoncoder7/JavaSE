create package cux_hr_department_PKG is

-- Author  : ADMINISTRATOR
-- Created : 2021/12/30 13:54:23
-- Purpose : 
procedure do_change(p_type    varchar2,
                      p_new_rec hrmdepartment%rowtype,
                      p_old_rec hrmdepartment%rowtype);
end cux_hr_department_PKG;
/

