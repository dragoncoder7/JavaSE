create package body department_level_update_pkg is
  --每天定时更新表department_level的数据
  procedure main is
    x_code varchar2(2) := '';
    x_msg  varchar2(2000) := '';
    l_str varchar2(200);
    cursor c is
      select tl.id,
             tl.departmentname,
             dl.departmentname departmentname1,
             dl.supdepid       supdepid1,
             dl.all_tlevel     all_tlevel1,
             dl.tlevel         tlevel1,
             tl.supdepid       supdepid2,
             tl.all_tlevel     all_tlevel2,
             tl.tlevel         tlevel2
        from department_level dl,
             (select t.id id,
                     t.supdepid supdepid,
                     t.departmentname departmentname,
                     regexp_count(top_str || buttom_str, ',') - 1 all_tlevel,
                     regexp_count(top_str, ',') tlevel
                from (select a.id,
                             a.supdepid,
                             a.departmentname,
                             (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
                                from hrmdepartment hd
                              connect by prior hd.id = hd.supdepid
                               start with hd.id = a.id) buttom_str,
                             (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
                                from hrmdepartment hd
                              connect by hd.id = prior hd.supdepid
                               start with hd.id = a.id) top_str
                        from hrmdepartment a) t) tl
       where dl.id(+) = tl.id
         --and dl.departmentname(+) = tl.departmentname  mod by cjl 2021-03-22 ID相同，部门不同时更改部门
         ;
  
  begin
    begin
      --遍历游标
      for c_ in c loop
        --两表数据不一样且不为空时更新
        if c_.supdepid1 is not null and
           (c_.supdepid1 <> c_.supdepid2 or
           c_.all_tlevel1 <> c_.all_tlevel2 or c_.tlevel1 <> c_.tlevel2 or c_.departmentname<>c_.departmentname1) then
          update department_level a
             set a.supdepid   = c_.supdepid2,
                 a.all_tlevel = c_.all_tlevel2,
                 a.tlevel     = c_.tlevel2,
                 a.departmentname=c_.departmentname
           where a.id = c_.id
             /*and a.departmentname = c_.departmentname*/;
             --将更改记录插入到表中
             insert into DEPARTMENT_LEVEL_ALTER_INFO values(c_.id,c_.supdepid1,c_.departmentname1,c_.all_tlevel1,
             c_.tlevel1,c_.supdepid2,c_.departmentname,c_.all_tlevel2,c_.tlevel2,sysdate);
          commit;
        end if;
        --表1不存在该数据时插入
        if c_.supdepid1 is null then
          l_str:=c_.supdepid1||'---------------'||c_.id;
          insert into department_level
            (id, supdepid, departmentname, all_tlevel, tlevel)
          values
            (c_.id,
             c_.supdepid2,
             c_.departmentname,
             c_.all_tlevel2,
             c_.tlevel2);
          commit;
        end if;
      end loop;
      --删除不使用的部门
    delete from department_level a
     where a.id not in
           (select t.id id
              from (select a.id,
                           a.supdepid,
                           a.departmentname,
                           (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
                              from hrmdepartment hd
                            connect by prior hd.id = hd.supdepid
                             start with hd.id = a.id) buttom_str,
                           (select max(SYS_CONNECT_BY_PATH(hd.id, ',')) str
                              from hrmdepartment hd
                            connect by hd.id = prior hd.supdepid
                             start with hd.id = a.id) top_str
                      from hrmdepartment a) t);
      commit;
      x_code := 'S';
    exception
      when others then
        dbms_output.put_line(substr(sqlerrm, 1, 2000));
        dbms_output.put_line(l_str);
        x_code := 'E';
        x_msg  := substr(sqlerrm, 1, 200);
    end;
    insert into department_level_info values(department_level_seq.nextval,sysdate,x_code,x_msg);
    commit;
  end;
end department_level_update_pkg;
/

