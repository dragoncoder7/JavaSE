create package CUX_FACTORY_PKG is

  -- Author  : ADMINISTRATOR
  -- Created : 2022/05/05 17:16:44
  -- Purpose : 通过工号获取考核单位（分厂），用于ERP和OA的采购审批
  --这个是OA的包

  function get_factory(p_employee_num varchar2) return varchar2;

end CUX_FACTORY_PKG;
/

