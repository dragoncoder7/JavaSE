create trigger WORKFLOW_SMARTPROCESSLOG_TRI
    before insert
    on WORKFLOW_SMARTPROCESSLOG
    for each row
begin select workflow_smartprocesslog_seq.nextval into :new.id from dual; end;
/

