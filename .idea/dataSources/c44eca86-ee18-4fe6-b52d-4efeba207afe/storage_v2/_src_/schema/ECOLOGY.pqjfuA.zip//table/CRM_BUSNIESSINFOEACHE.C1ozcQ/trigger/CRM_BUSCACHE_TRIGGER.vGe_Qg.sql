create trigger CRM_BUSCACHE_TRIGGER
    before insert
    on CRM_BUSNIESSINFOEACHE
    for each row
    when (new.id is null)
begin select CRM_busCache_sequence.nextval into:new.id from dual; end;
/

