create trigger SOCIALIMUSERSYSCONFIG_TRIGGER
    before insert
    on SOCIAL_IMUSERSYSCONFIG
    for each row
begin select SocialIMUserSysConfig_seq.nextval into:new.id from sys.dual; end;
/

