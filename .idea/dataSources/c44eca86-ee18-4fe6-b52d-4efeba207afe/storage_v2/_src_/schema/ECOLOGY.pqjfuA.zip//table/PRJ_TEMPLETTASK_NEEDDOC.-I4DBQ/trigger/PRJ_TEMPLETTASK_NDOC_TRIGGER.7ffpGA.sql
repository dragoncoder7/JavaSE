create trigger PRJ_TEMPLETTASK_NDOC_TRIGGER
    before insert
    on PRJ_TEMPLETTASK_NEEDDOC
    for each row
begin select Prj_TTask_ndoc_id.nextval into :new.id from dual; end;
/

