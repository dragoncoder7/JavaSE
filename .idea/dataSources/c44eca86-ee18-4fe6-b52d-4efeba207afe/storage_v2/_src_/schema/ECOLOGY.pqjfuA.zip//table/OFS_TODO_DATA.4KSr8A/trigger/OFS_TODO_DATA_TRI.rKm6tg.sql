create trigger OFS_TODO_DATA_TRI
    before insert
    on OFS_TODO_DATA
    for each row
begin select ofs_todo_data_id.nextval into :new.id from dual; end;
/

