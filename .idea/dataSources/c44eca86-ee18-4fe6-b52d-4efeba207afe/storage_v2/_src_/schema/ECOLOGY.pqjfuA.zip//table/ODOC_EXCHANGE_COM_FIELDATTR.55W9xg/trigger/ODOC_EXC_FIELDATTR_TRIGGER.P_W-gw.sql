create trigger ODOC_EXC_FIELDATTR_TRIGGER
    before insert
    on ODOC_EXCHANGE_COM_FIELDATTR
    for each row
begin select seq_odoc_exc_fieldattr.nextval into :new.id from dual;end;
/

