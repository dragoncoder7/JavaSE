create trigger ODOC_SIGN_MODIFYLOG_INSERT
    before insert
    on ODOC_SIGN_MODIFYLOG
    for each row
declare begin select odoc_sign_modifylog_id_seq.nextval into :new.ID from dual; end odoc_sign_modifylog_insert;
/

