create trigger OUTTER_ENCRYPTCLASS_TRI
    before insert
    on OUTTER_ENCRYPTCLASS
    for each row
begin select outter_encryptclass_seq.nextval into :new.id from dual; end;
/

