create trigger MEETING_SEAT_CONF_TRIGGER
    before insert
    on MEETING_SEAT_CONF
    for each row
begin select meeting_seat_conf_ID.nextval into :new.id from dual; end;
/

