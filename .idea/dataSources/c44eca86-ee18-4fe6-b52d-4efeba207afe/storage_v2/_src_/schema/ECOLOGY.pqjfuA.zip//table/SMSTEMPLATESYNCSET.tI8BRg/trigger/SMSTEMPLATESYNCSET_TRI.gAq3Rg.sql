create trigger SMSTEMPLATESYNCSET_TRI
    before insert
    on SMSTEMPLATESYNCSET
    for each row
begin select smstemplateSyncSet_seq.nextval into :new.id from dual; end;
/

