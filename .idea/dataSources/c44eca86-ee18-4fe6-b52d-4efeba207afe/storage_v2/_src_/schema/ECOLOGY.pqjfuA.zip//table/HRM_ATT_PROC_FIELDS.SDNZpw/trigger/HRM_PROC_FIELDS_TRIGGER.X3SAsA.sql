create trigger HRM_PROC_FIELDS_TRIGGER
    before insert
    on HRM_ATT_PROC_FIELDS
    for each row
begin select hrm_att_proc_fields_id.nextval into :new.id from dual; end;
/

