create trigger MODE_CUSTOMCOUNT_SETTING_TRI
    before insert
    on MODE_CUSTOMCOUNT_SETTING
    for each row
begin select mode_customcount_setting_id .nextval into:new.id from dual; end;
/

