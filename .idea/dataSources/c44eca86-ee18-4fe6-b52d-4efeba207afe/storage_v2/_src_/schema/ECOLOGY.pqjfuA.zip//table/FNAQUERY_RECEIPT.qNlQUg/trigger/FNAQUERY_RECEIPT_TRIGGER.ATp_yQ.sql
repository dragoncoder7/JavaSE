create trigger FNAQUERY_RECEIPT_TRIGGER
    before insert
    on FNAQUERY_RECEIPT
    for each row
begin select seq_fnaQuery_Receipt.nextval into :new.id from dual; end;
/

