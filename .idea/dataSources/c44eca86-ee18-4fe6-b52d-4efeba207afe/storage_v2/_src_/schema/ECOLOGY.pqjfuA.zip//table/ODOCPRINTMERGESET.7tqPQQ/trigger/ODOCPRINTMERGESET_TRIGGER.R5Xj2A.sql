create trigger ODOCPRINTMERGESET_TRIGGER
    before insert
    on ODOCPRINTMERGESET
    for each row
begin select odocPrintMergeSet_seq.nextval into :new.id from dual; end;
/

