create trigger PRJ_REQUEST_TRIGGER
    before insert
    on PRJ_REQUEST
    for each row
begin select Prj_Request_id.nextval into :new.id from dual; end;
/

