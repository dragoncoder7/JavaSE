create trigger GOVERN_TASKSHAREDETAIL_INS_TRG
    before insert
    on GOVERN_TASKSHAREDETAIL
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_taskShareDetail_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

