create trigger HRMSALARYCHANGE_TRIGGER
    before insert
    on HRMSALARYCHANGE
    for each row
begin select HrmSalaryChange_id.nextval into :new.id from dual; end;
/

