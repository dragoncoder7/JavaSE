create trigger ACTIONSETTING_TRI
    before insert
    on ACTIONSETTING
    for each row
begin select actionsetting_seq.nextval into :new.id from dual; end;
/

