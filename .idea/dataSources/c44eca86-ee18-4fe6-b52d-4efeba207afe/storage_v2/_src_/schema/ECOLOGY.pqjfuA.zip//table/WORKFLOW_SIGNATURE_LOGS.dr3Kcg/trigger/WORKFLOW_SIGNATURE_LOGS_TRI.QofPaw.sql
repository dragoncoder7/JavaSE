create trigger WORKFLOW_SIGNATURE_LOGS_TRI
    before insert
    on WORKFLOW_SIGNATURE_LOGS
    for each row
begin select workflow_signature_logs_id.nextval into :new.id from dual; end;
/

