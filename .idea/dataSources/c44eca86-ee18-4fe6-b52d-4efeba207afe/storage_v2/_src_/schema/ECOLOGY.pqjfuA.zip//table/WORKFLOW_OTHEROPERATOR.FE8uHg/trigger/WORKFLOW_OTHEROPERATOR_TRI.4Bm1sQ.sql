create trigger WORKFLOW_OTHEROPERATOR_TRI
    before insert
    on WORKFLOW_OTHEROPERATOR
    for each row
begin select workflow_otheroperator_seq.nextval into :new.id from dual; end;
/

