create trigger MAILCONTACTERGROUP_TRI
    before insert
    on MAILCONTACTERGROUP
    for each row
begin select MailContacterGroup_id.nextval into :new.id from dual; end;
/

