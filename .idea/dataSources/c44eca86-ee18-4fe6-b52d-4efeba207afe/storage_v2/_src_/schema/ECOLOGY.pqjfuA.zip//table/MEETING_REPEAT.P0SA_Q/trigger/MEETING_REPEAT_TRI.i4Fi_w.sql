create trigger MEETING_REPEAT_TRI
    before insert
    on MEETING_REPEAT
    for each row
begin select Meeting_repeat_id.nextval into :new.id from dual; end;
/

