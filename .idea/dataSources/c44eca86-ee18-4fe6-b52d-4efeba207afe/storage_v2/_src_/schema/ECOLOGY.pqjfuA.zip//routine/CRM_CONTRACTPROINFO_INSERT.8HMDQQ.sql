create PROCEDURE CRM_ContractProInfo_Insert ( proId_1 	integer, factNum_1 	integer, factDate_1 	char, formNum_1   varchar2 , creater_1 	integer , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin INSERT INTO CRM_ContractProInfo (proId,factNum,factDate,formNum,creater) VALUES ( proId_1, factNum_1, factDate_1, formNum_1, creater_1 ); end;


/

