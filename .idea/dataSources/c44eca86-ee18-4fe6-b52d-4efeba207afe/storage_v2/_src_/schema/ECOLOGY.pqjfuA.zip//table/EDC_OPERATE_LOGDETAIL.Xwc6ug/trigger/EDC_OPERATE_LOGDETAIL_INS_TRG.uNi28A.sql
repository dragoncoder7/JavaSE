create trigger EDC_OPERATE_LOGDETAIL_INS_TRG
    before insert
    on EDC_OPERATE_LOGDETAIL
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_operate_logdetail_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

