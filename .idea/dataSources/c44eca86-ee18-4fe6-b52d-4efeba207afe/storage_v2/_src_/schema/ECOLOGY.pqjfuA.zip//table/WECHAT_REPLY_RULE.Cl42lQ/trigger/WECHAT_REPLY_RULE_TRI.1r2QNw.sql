create trigger WECHAT_REPLY_RULE_TRI
    before insert
    on WECHAT_REPLY_RULE
    for each row
begin select wechat_reply_rule_id.nextval into :new.id from dual; end;
/

