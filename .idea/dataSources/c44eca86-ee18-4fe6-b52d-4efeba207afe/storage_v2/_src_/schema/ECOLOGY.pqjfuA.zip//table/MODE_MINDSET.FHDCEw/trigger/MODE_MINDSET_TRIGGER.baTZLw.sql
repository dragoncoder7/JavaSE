create trigger MODE_MINDSET_TRIGGER
    before insert
    on MODE_MINDSET
    for each row
begin select mode_mindSet_id.nextval into :new.id from dual; end;
/

