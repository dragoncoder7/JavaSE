create trigger HPFIELDLENGTH_TRIGGER
    before insert
    on HPFIELDLENGTH
    for each row
begin select hpFieldLength_id.nextval into :new.id from dual; end;
/

