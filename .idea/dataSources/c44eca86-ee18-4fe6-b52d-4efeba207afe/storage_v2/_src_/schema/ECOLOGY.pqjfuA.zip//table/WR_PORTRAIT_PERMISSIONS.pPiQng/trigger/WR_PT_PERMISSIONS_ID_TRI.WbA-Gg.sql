create trigger WR_PT_PERMISSIONS_ID_TRI
    before insert
    on WR_PORTRAIT_PERMISSIONS
    for each row
begin select WR_PT_Permissions_SEQ.nextval into :new.id from dual; end;
/

