create PROCEDURE CptCapital_SelectbyRandT (resourceid_1 integer, capitaltypeid_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select id,name,capitalspec,capitalnum from CptCapital where (resourceid = resourceid_1 and  capitaltypeid=capitaltypeid_1); end;


/

