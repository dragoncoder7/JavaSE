create package body cux_other2oa_pkg_2 is

  /*
  作用：通过字面值获得对应的ｉｄ
  注意：调用此函数有，确保p_comments中包含字符串resouce
  */
  function get_id(p_table_name  varchar2, --表名
                  p_column_name varchar2, --栏位
                  p_value       varchar2, --值
                  p_comments    varchar2 --栏位的备注信息
                  ) return varchar2 is
    l_temp varchar2(200) := p_value;
  
    l_fieldid    number;
    l_main_table varchar2(200);
    -----
    v_temp varchar2(60) := null;

    cursor c is
    SELECT REGEXP_SUBSTR(p_value, '[^,]+', 1, LEVEL) AS workcode
FROM dual
CONNECT BY REGEXP_SUBSTR(p_value, '[^,]+', 1, LEVEL) IS NOT NULL;
-----
  
  begin
    --获得用户ID
    if p_comments like '%resouce_type=hr%' then
      select a.id
        into l_temp
        from hrmresource a --人员表
       where a.workcode = p_value;
      return l_temp;
    
    end if;
  
    --获得用户ID
    if p_comments like '%resouce_type=users%' then
      select LISTAGG(hs.ID, ',') WITHIN GROUP(ORDER BY seq_num)
        INTO l_temp
        from (select level seq_num,
                     regexp_substr(p_value, '[^,]+', 1, level) workcode
                from dual
              connect by level <= regexp_count(p_value, ',') + 1) xx,
             hrmresource hs
       where hs.workcode = xx.workcode;
    
      RETURN l_temp;
    
    end if;
  
        --获得部门ID
    if p_comments like '%resouce_type=department%' then
      select a.departmentid --部门ID
        into l_temp
        from hrmresource a --人员表
       where a.workcode = p_value;
      return l_temp;
    
    end if;
    
     ----------------通过多个工号获得多个人员id
    if  p_comments like '%resouce_type=multiple_hr%' then
      for x in c loop
      select a.id
        into l_temp
        from hrmresource a --人员表
       where a.workcode = x.workcode;

       v_temp := v_temp || l_temp || ',';
      end loop;

      return rtrim(v_temp,',');
    end if;
  ----------------------
  
    --获得选择栏的ID
    if p_comments like 'column_type=select' then
      select regexp_replace(p_table_name,
                            '([^_]+)_([^_]+)_([^_]+).*',
                            '\1_\2_\3')
        into l_main_table
        from dual;
    
      --获得栏位ID
      select MAX(b.id)
        INTO l_fieldid
        from workflow_bill a, workflow_billfield b
       where 1 = 1
         and a.id = b.billid
         and a.tablename = LOWER(l_main_table)
            /*and b.viewtype = (case
              when l_main_table = p_column_name then
               0 --主表
              else
               1 --明细表
            end)*/
         and ((l_main_table = p_table_name and b.detailtable is null) --主明时， 明细表为空
             or (l_main_table != p_table_name and
             b.detailtable = lower(p_table_name)) --明细表时，要指定表
             )
         and b.fieldname = LOWER(p_column_name);
    
      select max(a.selectvalue)
        into l_temp
        from workflow_selectitem a --栏位列表值
       where fieldid = l_fieldid
         and a.selectname = p_value;
    
      return NVL(l_temp, p_value);
    end if;
    return l_temp;
  end;

  /*
  通过用户ID获取用户的相当信息
  返回值：部门ID,公司ID
  */
  function get_user_info(p_user_id varchar2) return varchar2 is
    l_department_id varchar2(2000);
    l_company_id    varchar(200);
  begin
    select a.departmentid, A.subcompanyid1
      into l_department_id, l_company_id
      from hrmresource a
     where a.id = p_user_id;
  
    return l_department_id || ',' || l_company_id;
  end;
end cux_other2oa_pkg_2;
/

