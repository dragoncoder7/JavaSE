create trigger GM_GOALPARTNER_ID_TRIGGER
    before insert
    on GM_GOALPARTNER
    for each row
begin select GM_GoalPartner_id.nextval into :new.id from dual; end;
/

