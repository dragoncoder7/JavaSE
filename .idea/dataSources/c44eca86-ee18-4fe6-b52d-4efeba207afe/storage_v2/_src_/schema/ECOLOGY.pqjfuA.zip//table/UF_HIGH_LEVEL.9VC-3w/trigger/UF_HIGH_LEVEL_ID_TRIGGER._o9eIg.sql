create trigger UF_HIGH_LEVEL_ID_TRIGGER
    before insert
    on UF_HIGH_LEVEL
    for each row
begin select uf_high_level_Id.nextval into :new.id from dual; end;
/

