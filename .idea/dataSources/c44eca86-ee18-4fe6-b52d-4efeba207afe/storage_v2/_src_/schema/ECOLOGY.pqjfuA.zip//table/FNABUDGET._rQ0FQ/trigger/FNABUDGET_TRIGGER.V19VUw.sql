create trigger FNABUDGET_TRIGGER
    before insert
    on FNABUDGET
    for each row
begin select FnaBudget_id.nextval into :new.id from dual; end;
/

