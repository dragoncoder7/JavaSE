create PROCEDURE bill_monthinfodetail_DByType ( infoid1		integer, type1		integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin delete from bill_monthinfodetail where infoid=infoid1 and type=type1; end;


/

