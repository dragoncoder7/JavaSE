create trigger HRMJOBCALL_TR
    before insert
    on HRMJOBCALL
    for each row
begin select HrmJobCall_id.nextval into :new.id from dual; end;
/

