create trigger WORKFLOW_DEPTABBR_TRI
    before insert
    on WORKFLOW_DEPTABBR
    for each row
begin select workflow_deptAbbr_id.nextval into :new.id from dual; end;
/

