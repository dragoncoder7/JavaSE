create trigger WORKPLAN_SYNC_INFO_TRIGGER
    before insert
    on WORKPLAN_SYNC_INFO
    for each row
begin select workplan_sync_info_ID.nextval into :new.id from dual; end;
/

