create trigger CRM_SELLCHANCE_REMIND_SQ_TG
    before insert
    on CRM_SELLCHANCE_REMIND
    for each row
BEGIN SELECT CRM_SellChance_Remind_SQ.nextval INTO:NEW.ID FROM dual;END;
/

