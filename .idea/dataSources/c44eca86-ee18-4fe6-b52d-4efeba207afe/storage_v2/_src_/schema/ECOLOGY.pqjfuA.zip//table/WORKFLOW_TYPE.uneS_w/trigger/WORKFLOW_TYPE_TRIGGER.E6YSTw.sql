create trigger WORKFLOW_TYPE_TRIGGER
    before insert
    on WORKFLOW_TYPE
    for each row
begin select workflow_type_id.nextval into :new.id from dual; end;
/

