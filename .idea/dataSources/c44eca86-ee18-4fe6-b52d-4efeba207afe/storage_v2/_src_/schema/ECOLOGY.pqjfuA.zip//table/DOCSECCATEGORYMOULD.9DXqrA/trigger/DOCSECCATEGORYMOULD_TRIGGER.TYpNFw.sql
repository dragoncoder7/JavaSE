create trigger DOCSECCATEGORYMOULD_TRIGGER
    before insert
    on DOCSECCATEGORYMOULD
    for each row
begin select DocSecCategoryMould_Id.nextval into :new.id from dual; end;
/

