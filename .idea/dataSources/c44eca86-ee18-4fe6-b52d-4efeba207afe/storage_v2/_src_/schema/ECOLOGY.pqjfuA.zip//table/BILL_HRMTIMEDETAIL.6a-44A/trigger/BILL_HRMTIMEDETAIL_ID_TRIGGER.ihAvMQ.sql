create trigger BILL_HRMTIMEDETAIL_ID_TRIGGER
    before insert
    on BILL_HRMTIMEDETAIL
    for each row
begin select bill_hrmtimedetail_Id.nextval into :new.id from dual; end;
/

