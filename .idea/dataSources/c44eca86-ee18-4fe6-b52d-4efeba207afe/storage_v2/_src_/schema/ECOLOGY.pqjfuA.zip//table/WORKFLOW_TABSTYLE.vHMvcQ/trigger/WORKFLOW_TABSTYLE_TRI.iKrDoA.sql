create trigger WORKFLOW_TABSTYLE_TRI
    before insert
    on WORKFLOW_TABSTYLE
    for each row
begin select workflow_TabStyle_seq.nextval into :new.styleid from DUAL; END;
/

