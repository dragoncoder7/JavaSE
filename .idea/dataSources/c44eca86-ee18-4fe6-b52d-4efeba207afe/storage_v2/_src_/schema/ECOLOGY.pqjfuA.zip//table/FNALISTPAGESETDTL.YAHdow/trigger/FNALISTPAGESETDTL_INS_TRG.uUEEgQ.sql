create trigger FNALISTPAGESETDTL_INS_TRG
    before insert
    on FNALISTPAGESETDTL
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT fnaListPageSetDtl_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

