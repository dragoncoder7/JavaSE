create trigger PR_BASESETTING_ID_TRIGGER
    before insert
    on PR_BASESETTING
    for each row
begin select PR_BaseSetting_id.nextval into :new.id from dual; end;
/

