create PROCEDURE CRM_ContractProduct_Update (id_1 	integer , factnumber_n_1  integer , factDate_1  char   , isFinish_1  integer  , isRemind_1  integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_ContractProduct SET factnumber_n = factnumber_n_1, factDate = factDate_1 , isFinish = isFinish_1 , isRemind = isRemind_1  where id = id_1; end;


/

