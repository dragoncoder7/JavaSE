create trigger WR_P_TDZBLX_ID_TRI
    before insert
    on WR_TEAMTOTALITEM_TYPE
    for each row
begin select WR_P_tdzblx_SEQ.nextval into :new.id from dual; end;
/

