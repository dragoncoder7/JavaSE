create view OA_DEPT_VIEW as
select a.id DEPT_ID, a.departmentname DEPT_NAME, a.supdepid PARENT_DEPT_ID, b. subcompanyname COMPANY_NAME
  from hrmdepartment a
 inner join hrmsubcompany b
    on a. subcompanyid1 = b. id
 where a.canceled = 0 or a.canceled is null
/

