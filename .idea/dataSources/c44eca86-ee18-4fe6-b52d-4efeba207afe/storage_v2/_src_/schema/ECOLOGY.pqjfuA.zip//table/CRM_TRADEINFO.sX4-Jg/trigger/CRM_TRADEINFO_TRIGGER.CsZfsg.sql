create trigger CRM_TRADEINFO_TRIGGER
    before insert
    on CRM_TRADEINFO
    for each row
begin select CRM_TradeInfo_id.nextval into :new.id from dual; end;
/

