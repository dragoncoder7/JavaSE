create trigger WF_PROXY_CONFIG_ID_TRIG
    before insert
    on WF_PROXY_CONFIG
    for each row
begin select wf_proxy_config_ID.nextval into :new.id from dual; end;
/

