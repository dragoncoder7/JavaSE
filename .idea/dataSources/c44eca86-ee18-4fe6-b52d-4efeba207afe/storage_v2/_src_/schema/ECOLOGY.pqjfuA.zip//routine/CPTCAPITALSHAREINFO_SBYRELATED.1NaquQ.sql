create PROCEDURE CptCapitalShareInfo_SbyRelated (relateditemid_1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptCapitalShareInfo where ( relateditemid = relateditemid_1 ) order by sharetype; end;


/

