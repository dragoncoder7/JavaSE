create PROCEDURE bill_MailboxApply_UpdateStatus ( id1		integer, status1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update bill_MailboxApply set status=status1 where id=id1; end;


/

