create trigger EDC_DATASET_INS_TRG
    before insert
    on EDC_DATASET
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_dataset_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

