create trigger PRJ_SHAREINFO_TRIGGER
    before insert
    on PRJ_SHAREINFO
    for each row
begin select Prj_ShareInfo_id.nextval into :new.id from dual; end;
/

