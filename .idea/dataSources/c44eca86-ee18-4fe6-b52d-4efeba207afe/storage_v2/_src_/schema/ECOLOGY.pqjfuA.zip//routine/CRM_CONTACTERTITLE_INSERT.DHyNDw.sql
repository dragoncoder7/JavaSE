create PROCEDURE CRM_ContacterTitle_Insert (fullname_1 	varchar2, description_1 	varchar2, usetype_1 	char, language_1 	integer, abbrev_1 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_ContacterTitle ( fullname, description, usetype, language, abbrev) VALUES ( fullname_1, description_1, usetype_1, language_1, abbrev_1); end;


/

