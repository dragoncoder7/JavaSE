create trigger ECME_LAYOUTLINK_INS_TRG
    before insert
    on ECME_LAYOUTLINK
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT ecme_layoutlink_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

