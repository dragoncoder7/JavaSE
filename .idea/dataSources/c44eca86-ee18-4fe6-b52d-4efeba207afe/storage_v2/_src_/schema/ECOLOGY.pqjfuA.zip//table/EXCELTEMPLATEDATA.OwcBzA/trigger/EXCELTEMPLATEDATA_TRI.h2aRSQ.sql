create trigger EXCELTEMPLATEDATA_TRI
    before insert
    on EXCELTEMPLATEDATA
    for each row
begin select excelTemplateData_id.nextval into :new.id from dual; end;
/

