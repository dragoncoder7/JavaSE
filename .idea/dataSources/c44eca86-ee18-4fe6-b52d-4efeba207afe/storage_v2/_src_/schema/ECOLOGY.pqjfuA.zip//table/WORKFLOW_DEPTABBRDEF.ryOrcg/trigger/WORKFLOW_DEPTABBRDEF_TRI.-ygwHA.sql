create trigger WORKFLOW_DEPTABBRDEF_TRI
    before insert
    on WORKFLOW_DEPTABBRDEF
    for each row
begin select workflow_deptAbbrDef_id.nextval into :new.id from dual; end;
/

