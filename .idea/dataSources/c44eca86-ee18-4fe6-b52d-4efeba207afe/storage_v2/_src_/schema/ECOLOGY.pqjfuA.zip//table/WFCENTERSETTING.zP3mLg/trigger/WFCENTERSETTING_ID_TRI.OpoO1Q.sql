create trigger WFCENTERSETTING_ID_TRI
    before insert
    on WFCENTERSETTING
    for each row
begin select wfcenterSetting_id.nextval into :new.id from dual; end;
/

