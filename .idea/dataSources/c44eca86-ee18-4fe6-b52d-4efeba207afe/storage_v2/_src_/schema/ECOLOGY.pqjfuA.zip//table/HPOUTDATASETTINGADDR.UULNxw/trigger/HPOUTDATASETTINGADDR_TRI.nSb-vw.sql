create trigger HPOUTDATASETTINGADDR_TRI
    before insert
    on HPOUTDATASETTINGADDR
    for each row
begin select hpOutDataSettingAddr_seq.nextval into :new.id from dual; end;
/

