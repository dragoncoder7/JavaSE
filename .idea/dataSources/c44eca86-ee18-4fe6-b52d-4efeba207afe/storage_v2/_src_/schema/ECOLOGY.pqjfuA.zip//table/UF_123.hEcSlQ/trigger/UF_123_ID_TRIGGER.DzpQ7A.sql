create trigger UF_123_ID_TRIGGER
    before insert
    on UF_123
    for each row
begin select uf_123_Id.nextval into :new.id from dual; end;
/

