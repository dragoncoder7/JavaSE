create trigger TR_WS_DATASOURCE
    before insert
    on WS_DATASOURCE
    for each row
begin select sq_ws_datasource.nextval into :new.id from dual; end;
/

