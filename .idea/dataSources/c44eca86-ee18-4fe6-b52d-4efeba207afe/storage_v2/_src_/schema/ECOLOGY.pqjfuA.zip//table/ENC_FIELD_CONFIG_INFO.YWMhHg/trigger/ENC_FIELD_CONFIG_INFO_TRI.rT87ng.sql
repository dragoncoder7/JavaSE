create trigger ENC_FIELD_CONFIG_INFO_TRI
    before insert
    on ENC_FIELD_CONFIG_INFO
    for each row
begin select enc_field_config_info_id.nextval into :new.id from dual; end;
/

