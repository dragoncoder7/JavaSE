create trigger FORMTABLE_MAIN_3496_ID_TR
    before insert
    on FORMTABLE_MAIN_3496
    for each row
begin select formtable_main_3496_Id.nextval into :new.id from dual; end;
/

