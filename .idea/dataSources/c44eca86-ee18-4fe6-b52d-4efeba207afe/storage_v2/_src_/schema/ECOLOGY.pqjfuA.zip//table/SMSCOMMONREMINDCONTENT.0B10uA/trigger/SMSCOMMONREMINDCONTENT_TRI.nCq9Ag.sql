create trigger SMSCOMMONREMINDCONTENT_TRI
    before insert
    on SMSCOMMONREMINDCONTENT
    for each row
begin select smsCommonRemindContent_seq.nextval into :new.id from dual; end;
/

