create trigger DOCSECCATFTPCONFIG_TRIGGER
    before insert
    on DOCSECCATFTPCONFIG
    for each row
begin select DocSecCatFTPConfig_id.nextval into :new.id from dual; end;
/

