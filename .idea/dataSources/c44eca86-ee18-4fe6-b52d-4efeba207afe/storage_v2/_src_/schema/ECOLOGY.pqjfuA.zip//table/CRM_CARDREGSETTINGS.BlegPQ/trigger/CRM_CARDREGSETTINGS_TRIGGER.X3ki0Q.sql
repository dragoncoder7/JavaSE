create trigger CRM_CARDREGSETTINGS_TRIGGER
    before insert
    on CRM_CARDREGSETTINGS
    for each row
    when (new.id is null)
begin select CRM_CardRegSettings_sequence.nextval into:new.id from dual; end;
/

