create trigger WEBMAGAZINE_TRIGGER
    before insert
    on WEBMAGAZINE
    for each row
begin select WebMagazine_id.nextval into :new.id from dual; end ;
/

