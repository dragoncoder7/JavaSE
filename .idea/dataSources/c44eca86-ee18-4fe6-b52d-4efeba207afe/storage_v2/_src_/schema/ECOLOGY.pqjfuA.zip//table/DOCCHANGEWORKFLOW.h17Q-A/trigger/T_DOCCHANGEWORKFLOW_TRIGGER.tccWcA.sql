create trigger T_DOCCHANGEWORKFLOW_TRIGGER
    before insert
    on DOCCHANGEWORKFLOW
    for each row
    when (new.id is null)
begin select t_DocChangeWorkflow_seq.nextval into:NEW.ID from dual; end;
/

