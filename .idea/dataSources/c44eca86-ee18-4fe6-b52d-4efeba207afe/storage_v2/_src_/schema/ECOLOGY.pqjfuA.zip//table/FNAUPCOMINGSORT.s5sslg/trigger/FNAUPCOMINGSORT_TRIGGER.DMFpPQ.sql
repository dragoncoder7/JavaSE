create trigger FNAUPCOMINGSORT_TRIGGER
    before insert
    on FNAUPCOMINGSORT
    for each row
begin select seq_fnaUpComingSort.nextval into :new.id from dual; end;
/

