create trigger HRM_ST_PC_SET_TRIGGER
    before insert
    on HRM_STATE_PROC_SET
    for each row
begin select hrm_state_proc_set_id.nextval into :new.id from dual; end;
/

