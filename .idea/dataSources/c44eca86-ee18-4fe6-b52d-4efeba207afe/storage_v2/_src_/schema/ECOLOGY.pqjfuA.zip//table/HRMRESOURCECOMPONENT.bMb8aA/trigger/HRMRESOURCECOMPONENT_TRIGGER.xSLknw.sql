create trigger HRMRESOURCECOMPONENT_TRIGGER
    before insert
    on HRMRESOURCECOMPONENT
    for each row
begin select HrmResourceComponent_id.nextval into :new.id from dual; end;
/

