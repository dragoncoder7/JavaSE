create trigger OUTERDATAWFSETD_ID_TRIGGER
    before insert
    on OUTERDATAWFSETDETAIL
    for each row
begin select outerdatawfsetD_Id.nextval into :new.id from dual; end;
/

