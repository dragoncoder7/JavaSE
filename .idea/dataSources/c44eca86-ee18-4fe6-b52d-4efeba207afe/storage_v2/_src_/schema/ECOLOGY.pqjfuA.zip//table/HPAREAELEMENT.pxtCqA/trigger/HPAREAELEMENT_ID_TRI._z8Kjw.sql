create trigger HPAREAELEMENT_ID_TRI
    before insert
    on HPAREAELEMENT
    for each row
begin select hpareaelement_id.nextval into :new.id from dual; end;
/

