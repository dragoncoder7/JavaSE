create trigger BLOG_VISIT_ID_TRIGGER
    before insert
    on BLOG_VISIT
    for each row
begin select blog_visit_id.nextval into :new.id from dual; end;
/

