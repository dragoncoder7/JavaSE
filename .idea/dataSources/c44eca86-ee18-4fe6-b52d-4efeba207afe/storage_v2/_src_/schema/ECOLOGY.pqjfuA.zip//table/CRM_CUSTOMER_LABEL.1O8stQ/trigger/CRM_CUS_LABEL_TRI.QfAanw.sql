create trigger CRM_CUS_LABEL_TRI
    before insert
    on CRM_CUSTOMER_LABEL
    for each row
begin select CRM_cus_label_id.nextval into :new.id from dual; end;
/

