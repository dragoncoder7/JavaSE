create trigger CONTRACT_SHAREINFO_TRIGGER
    before insert
    on CONTRACT_SHAREINFO
    for each row
begin select Contract_ShareInfo_id.nextval into :new.id from dual; end;
/

