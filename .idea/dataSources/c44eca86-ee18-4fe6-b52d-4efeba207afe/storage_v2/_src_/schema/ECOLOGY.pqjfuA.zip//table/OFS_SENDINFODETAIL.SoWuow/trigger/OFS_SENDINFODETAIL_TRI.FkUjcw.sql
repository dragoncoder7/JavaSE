create trigger OFS_SENDINFODETAIL_TRI
    before insert
    on OFS_SENDINFODETAIL
    for each row
begin select ofs_sendinfodetail_seq.nextval into :new.id from DUAL; END;
/

