create trigger WORKFLOW_CODESEQ_TRIGGER
    before insert
    on WORKFLOW_CODESEQ
    for each row
begin select workflow_codeSeq_id.nextval into :new.id from dual; end;
/

