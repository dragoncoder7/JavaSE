create trigger MODE_CARREMINDSET_TR
    before insert
    on MODE_CARREMINDSET
    for each row
begin select mode_carremindset_ID.nextval into :new.id from dual; end;
/

