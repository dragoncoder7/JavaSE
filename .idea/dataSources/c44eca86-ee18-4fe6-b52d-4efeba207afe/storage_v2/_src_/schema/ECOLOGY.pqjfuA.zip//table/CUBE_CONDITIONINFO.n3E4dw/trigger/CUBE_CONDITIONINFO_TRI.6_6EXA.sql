create trigger CUBE_CONDITIONINFO_TRI
    before insert
    on CUBE_CONDITIONINFO
    for each row
begin   select cube_conditioninfo_id.nextval into :new.id from dual; end;
/

