create trigger WORKFLOW_SHAREDSCOPE_TRI
    before insert
    on WORKFLOW_SHAREDSCOPE
    for each row
begin select Workflow_SharedScope_seq.nextval into :new.id from DUAL; END;
/

