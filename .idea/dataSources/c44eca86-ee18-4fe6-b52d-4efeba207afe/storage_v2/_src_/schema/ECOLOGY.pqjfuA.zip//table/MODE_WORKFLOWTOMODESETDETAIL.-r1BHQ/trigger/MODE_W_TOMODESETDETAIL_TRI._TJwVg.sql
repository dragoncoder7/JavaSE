create trigger MODE_W_TOMODESETDETAIL_TRI
    before insert
    on MODE_WORKFLOWTOMODESETDETAIL
    for each row
begin select mode_w_tomodesetdetail_id.nextval into :new.id from dual; end;
/

