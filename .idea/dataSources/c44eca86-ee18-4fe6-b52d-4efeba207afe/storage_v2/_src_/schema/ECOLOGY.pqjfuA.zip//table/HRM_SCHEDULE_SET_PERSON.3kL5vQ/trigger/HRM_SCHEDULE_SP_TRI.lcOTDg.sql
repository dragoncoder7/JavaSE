create trigger HRM_SCHEDULE_SP_TRI
    before insert
    on HRM_SCHEDULE_SET_PERSON
    for each row
begin select hrm_schedule_set_person_id.nextval into :new.id from dual; end;
/

