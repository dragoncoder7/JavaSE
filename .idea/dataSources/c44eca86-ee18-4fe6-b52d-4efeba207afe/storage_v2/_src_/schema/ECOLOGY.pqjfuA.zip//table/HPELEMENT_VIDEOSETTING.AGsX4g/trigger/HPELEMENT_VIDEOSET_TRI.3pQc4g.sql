create trigger HPELEMENT_VIDEOSET_TRI
    before insert
    on HPELEMENT_VIDEOSETTING
    for each row
begin select hpElement_videoset_seq.nextval into :new.id from DUAL; END;
/

