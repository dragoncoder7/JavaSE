create trigger KQ_WIFI_TRI
    before insert
    on KQ_WIFI
    for each row
begin select kq_wifi_id.nextval into :new.id from dual; end;
/

