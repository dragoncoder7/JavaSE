create trigger ODOC_WITHDRAWSET_INSERT
    before insert
    on ODOC_WITHDRAWSET
    for each row
declare begin select odoc_withdrawSet_id_seq .nextval into :new.ID from dual; end odoc_withdrawSet_insert;
/

