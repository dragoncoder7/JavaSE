create trigger MEETING_MEMBER_SEAT_TRIGGER
    before insert
    on MEETING_MEMBER_SEAT
    for each row
begin select meeting_member_seat_ID.nextval into :new.id from dual; end;
/

