create trigger T_WF_CUROPT_TRIGGER
    before insert
    on WORKFLOW_CURRENTOPERATOR
    for each row
begin select T_wf_curopt_id.nextval into :new.id from dual; end;
/

