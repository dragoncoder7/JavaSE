create trigger WORKPLANMONITOR_TRIGGER
    before insert
    on WORKPLANMONITOR
    for each row
begin select WorkPlanMonitor_WorkPlanMID.nextval into :new.WorkPlanMonitorID from dual; end ;
/

