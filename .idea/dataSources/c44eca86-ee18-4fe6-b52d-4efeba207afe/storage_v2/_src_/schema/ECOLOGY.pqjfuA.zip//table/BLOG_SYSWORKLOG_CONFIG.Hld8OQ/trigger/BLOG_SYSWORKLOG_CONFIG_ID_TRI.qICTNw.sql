create trigger BLOG_SYSWORKLOG_CONFIG_ID_TRI
    before insert
    on BLOG_SYSWORKLOG_CONFIG
    for each row
begin select BLOGSYSWORK_ID.nextval into :new.id from dual; end;
/

