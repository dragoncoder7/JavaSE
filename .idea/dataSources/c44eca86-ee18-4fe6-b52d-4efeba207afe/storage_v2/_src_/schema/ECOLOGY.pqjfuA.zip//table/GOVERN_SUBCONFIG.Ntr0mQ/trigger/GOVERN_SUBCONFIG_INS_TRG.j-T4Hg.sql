create trigger GOVERN_SUBCONFIG_INS_TRG
    before insert
    on GOVERN_SUBCONFIG
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_subconfig_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

