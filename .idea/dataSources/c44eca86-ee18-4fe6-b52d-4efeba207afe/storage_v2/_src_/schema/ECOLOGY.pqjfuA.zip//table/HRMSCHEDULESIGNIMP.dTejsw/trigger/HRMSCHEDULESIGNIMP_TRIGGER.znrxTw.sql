create trigger HRMSCHEDULESIGNIMP_TRIGGER
    before insert
    on HRMSCHEDULESIGNIMP
    for each row
begin select HRMSCHEDULESIGNIMP_id.nextval into :new.id from dual; end;
/

