create trigger HRMSALARYCOMPONENTTYPES_TR
    before insert
    on HRMSALARYCOMPONENTTYPES
    for each row
begin select HrmSalaryComponentTypes_id.nextval into :new.id from dual; end;
/

