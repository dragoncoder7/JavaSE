create trigger HRMPSLPERIOD_TRIGGER
    before insert
    on HRMPSLPERIOD
    for each row
begin select HrmPSLPeriod_id.nextval into :new.id from dual; end;
/

