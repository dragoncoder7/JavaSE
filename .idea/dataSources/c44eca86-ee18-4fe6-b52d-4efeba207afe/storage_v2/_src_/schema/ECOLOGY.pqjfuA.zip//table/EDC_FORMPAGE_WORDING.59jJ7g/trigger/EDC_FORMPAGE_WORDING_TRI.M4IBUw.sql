create trigger EDC_FORMPAGE_WORDING_TRI
    before insert
    on EDC_FORMPAGE_WORDING
    for each row
begin select edc_formpage_wording_seq.nextval into :new.id from dual; end;
/

