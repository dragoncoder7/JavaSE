create trigger WR_NDPDM_ML_TRG
    before insert
    on WR_INVENTORY_MODULES_LOG
    for each row
begin select WR_NDPDM_ML_SEQ.nextval into :new.id from DUAL; END;
/

