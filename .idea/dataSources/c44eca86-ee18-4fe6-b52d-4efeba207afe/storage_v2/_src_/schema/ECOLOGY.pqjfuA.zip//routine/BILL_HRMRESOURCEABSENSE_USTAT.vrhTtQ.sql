create PROCEDURE Bill_HrmResourceAbsense_UStat (id_1 integer, usestatus_1 char , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin update Bill_HrmResourceAbsense set usestatus = usestatus_1 where id=id_1; end;


/

