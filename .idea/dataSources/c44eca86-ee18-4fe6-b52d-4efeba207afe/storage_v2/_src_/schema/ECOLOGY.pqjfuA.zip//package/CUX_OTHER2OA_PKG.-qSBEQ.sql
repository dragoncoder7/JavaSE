create package cux_other2oa_pkg is

  -- Author  : ADMINISTRATOR
  -- Created : 2022/1/19 8:13:25
  -- Purpose : 用于提供接口给其它系统调用

  function get_id(p_table_name  varchar2, --表名
                  p_column_name varchar2, --栏位
                  p_value       varchar2, --值
                  p_comments    varchar2 --栏位的备注信息
                  ) return varchar2;

  function get_user_info(p_user_id varchar2) return varchar2;
end cux_other2oa_pkg;
/

