create trigger MODE_T_WORKFLOWSETDETAIL_TRI
    before insert
    on MODE_TRIGGERWORKFLOWSETDETAIL
    for each row
begin select mode_t_workflowsetdetail_id.nextval into :new.id from dual; end;
/

