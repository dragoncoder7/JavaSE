create trigger DOCUSERSELFCATEGORY_TRIGGER
    before insert
    on DOCUSERSELFCATEGORY
    for each row
begin select DocUserselfCategory_id.nextval into :new.id from dual; end;
/

