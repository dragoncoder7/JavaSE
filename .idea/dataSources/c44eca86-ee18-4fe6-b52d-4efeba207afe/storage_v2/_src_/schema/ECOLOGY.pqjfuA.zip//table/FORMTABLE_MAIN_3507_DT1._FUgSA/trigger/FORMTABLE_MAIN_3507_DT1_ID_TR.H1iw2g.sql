create trigger FORMTABLE_MAIN_3507_DT1_ID_TR
    before insert
    on FORMTABLE_MAIN_3507_DT1
    for each row
begin select formtable_main_3507_dt1_Id.nextval into :new.id from dual; end;
/

