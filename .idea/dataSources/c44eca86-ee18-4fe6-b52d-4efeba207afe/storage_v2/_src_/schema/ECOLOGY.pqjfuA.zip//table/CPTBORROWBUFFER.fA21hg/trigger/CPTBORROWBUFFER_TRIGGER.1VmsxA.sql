create trigger CPTBORROWBUFFER_TRIGGER
    before insert
    on CPTBORROWBUFFER
    for each row
begin select CptBorrowBuffer_id.nextval into :new.id from dual; end;
/

