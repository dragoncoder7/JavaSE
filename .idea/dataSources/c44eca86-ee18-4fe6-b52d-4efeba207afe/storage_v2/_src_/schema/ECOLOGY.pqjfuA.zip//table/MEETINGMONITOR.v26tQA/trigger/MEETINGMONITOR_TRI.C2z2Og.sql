create trigger MEETINGMONITOR_TRI
    before insert
    on MEETINGMONITOR
    for each row
begin select MeetingMonitor_ID.nextval into :new.id from dual; end;
/

