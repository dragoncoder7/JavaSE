create trigger KT_MAPDETAIL_ID_TRIGGER
    before insert
    on KT_MAPDETAIL
    for each row
begin select KT_MapDetail_id.nextval into :new.id from dual; end;
/

