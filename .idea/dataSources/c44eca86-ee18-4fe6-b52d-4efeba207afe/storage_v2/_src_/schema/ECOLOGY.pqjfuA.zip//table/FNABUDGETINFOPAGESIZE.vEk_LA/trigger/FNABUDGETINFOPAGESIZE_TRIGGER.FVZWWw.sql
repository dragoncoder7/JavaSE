create trigger FNABUDGETINFOPAGESIZE_TRIGGER
    before insert
    on FNABUDGETINFOPAGESIZE
    for each row
begin select seq_FnaBudgetInfoPageSize_id.nextval into :new.id from dual; end;
/

