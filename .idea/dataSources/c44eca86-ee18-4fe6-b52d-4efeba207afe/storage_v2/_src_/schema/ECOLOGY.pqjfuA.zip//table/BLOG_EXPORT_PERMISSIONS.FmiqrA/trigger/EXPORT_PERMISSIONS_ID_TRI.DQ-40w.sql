create trigger EXPORT_PERMISSIONS_ID_TRI
    before insert
    on BLOG_EXPORT_PERMISSIONS
    for each row
begin select export_permissions_SEQ.nextval into :new.id from dual; end;
/

