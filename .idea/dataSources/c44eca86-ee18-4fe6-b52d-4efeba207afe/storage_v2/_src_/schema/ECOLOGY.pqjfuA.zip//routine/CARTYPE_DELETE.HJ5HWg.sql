create PROCEDURE CarType_Delete (   id_1 integer, flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin delete from cartype where id=id_1; end;


/

