create trigger DOCPRIVATESECCATEGORY_TRIGGER
    before insert
    on DOCPRIVATESECCATEGORY
    for each row
begin select DocPrivateSecCategory_SEQ.nextval into :new.id from dual; end ;
/

