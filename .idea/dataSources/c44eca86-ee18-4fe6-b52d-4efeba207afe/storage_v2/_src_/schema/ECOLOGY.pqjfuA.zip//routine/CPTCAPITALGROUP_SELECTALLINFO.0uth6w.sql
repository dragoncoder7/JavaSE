create PROCEDURE CptCapitalGroup_SelectAllInfo ( flag	out integer, msg out varchar2,thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * FROM CptCapitalGroup; end;


/

