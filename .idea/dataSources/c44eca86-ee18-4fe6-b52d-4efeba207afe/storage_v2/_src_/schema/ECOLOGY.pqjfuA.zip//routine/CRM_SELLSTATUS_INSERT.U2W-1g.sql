create PROCEDURE CRM_SellStatus_Insert (fullname 	varchar2, description 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_SellStatus ( fullname, description) VALUES ( fullname, description) ; end;


/

