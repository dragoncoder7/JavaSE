create trigger WSREGISTE_TRI
    before insert
    on WSREGISTE
    for each row
begin select wsregiste_seq.nextval into :new.id from dual; end;
/

