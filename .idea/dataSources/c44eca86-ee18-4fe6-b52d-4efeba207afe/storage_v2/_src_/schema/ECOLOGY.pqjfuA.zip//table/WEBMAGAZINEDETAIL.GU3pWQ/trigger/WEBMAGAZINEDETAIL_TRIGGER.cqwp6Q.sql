create trigger WEBMAGAZINEDETAIL_TRIGGER
    before insert
    on WEBMAGAZINEDETAIL
    for each row
begin select WebMagazineDetail_id.nextval into :new.id from dual; end ;
/

