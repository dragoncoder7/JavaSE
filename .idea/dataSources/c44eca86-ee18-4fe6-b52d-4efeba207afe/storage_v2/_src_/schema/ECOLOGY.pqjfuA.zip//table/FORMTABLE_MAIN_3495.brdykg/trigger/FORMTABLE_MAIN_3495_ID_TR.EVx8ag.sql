create trigger FORMTABLE_MAIN_3495_ID_TR
    before insert
    on FORMTABLE_MAIN_3495
    for each row
begin select formtable_main_3495_Id.nextval into :new.id from dual;  end;
/

