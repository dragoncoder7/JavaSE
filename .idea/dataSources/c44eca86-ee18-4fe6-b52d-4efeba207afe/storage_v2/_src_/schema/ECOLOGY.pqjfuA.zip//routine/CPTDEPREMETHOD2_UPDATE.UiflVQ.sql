create PROCEDURE CptDepreMethod2_Update (id_1 	integer, depreid_2 	integer, time_3 	decimal, depreunit_4 	decimal, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin update CptDepreMethod2  SET  depreid=depreid_2, time=time_3, depreunit=depreunit_4  WHERE ( id=id_1); end;


/

