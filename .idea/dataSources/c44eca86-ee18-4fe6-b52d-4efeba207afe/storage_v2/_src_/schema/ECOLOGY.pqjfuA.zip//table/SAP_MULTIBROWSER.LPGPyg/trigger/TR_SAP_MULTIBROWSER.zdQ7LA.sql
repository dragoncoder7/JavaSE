create trigger TR_SAP_MULTIBROWSER
    before insert
    on SAP_MULTIBROWSER
    for each row
begin select sq_sap_multiBrowser.nextval into :new.id from dual; end;
/

