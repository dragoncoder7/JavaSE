create trigger MODE_PAGEEXPANDDETAIL_TRI
    before insert
    on MODE_PAGEEXPANDDETAIL
    for each row
begin select mode_pageexpanddetail_id.nextval into :new.id from dual; end;
/

