create trigger PRJ_TTASK_NWF_TRIGGER
    before insert
    on PRJ_TEMPLETTASK_NEEDWF
    for each row
begin select Prj_TTask_nwf_id.nextval into :new.id from dual; end;
/

