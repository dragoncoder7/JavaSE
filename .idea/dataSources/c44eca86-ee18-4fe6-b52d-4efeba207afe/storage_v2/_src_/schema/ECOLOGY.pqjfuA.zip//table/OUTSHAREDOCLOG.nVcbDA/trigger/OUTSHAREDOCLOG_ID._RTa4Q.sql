create trigger OUTSHAREDOCLOG_ID
    before insert
    on OUTSHAREDOCLOG
    for each row
begin select OUTSHAREDOCLOG_seq.nextval into :new.id from dual; end;
/

