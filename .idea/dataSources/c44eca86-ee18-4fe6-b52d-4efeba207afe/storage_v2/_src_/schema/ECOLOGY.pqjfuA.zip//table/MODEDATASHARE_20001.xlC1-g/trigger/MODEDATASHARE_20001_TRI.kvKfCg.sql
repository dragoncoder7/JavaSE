create trigger MODEDATASHARE_20001_TRI
    before insert
    on MODEDATASHARE_20001
    for each row
begin   select modeDataShare_20001_id.nextval into :new.id from dual;   end;
/

