create trigger WORKFLOW_CTGROUP_ID_TRI
    before insert
    on WORKFLOW_CREATETASKGROUP
    for each row
begin select workflow_createtaskgroup_id.nextval into :new.id from dual; end;
/

