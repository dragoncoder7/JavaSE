create trigger FNAEMAILINVOICE_TRIGGER
    before insert
    on FNAEMAILINVOICE
    for each row
begin select seq_fnaEmailInvoice.nextval into :new.id from dual; end;
/

