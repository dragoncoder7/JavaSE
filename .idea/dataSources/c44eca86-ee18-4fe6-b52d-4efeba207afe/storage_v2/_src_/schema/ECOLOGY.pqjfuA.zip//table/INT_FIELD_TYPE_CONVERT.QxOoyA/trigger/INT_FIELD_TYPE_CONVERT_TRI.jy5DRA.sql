create trigger INT_FIELD_TYPE_CONVERT_TRI
    before insert
    on INT_FIELD_TYPE_CONVERT
    for each row
begin select int_field_type_convert_seq.nextval into :new.id from dual; end ;
/

