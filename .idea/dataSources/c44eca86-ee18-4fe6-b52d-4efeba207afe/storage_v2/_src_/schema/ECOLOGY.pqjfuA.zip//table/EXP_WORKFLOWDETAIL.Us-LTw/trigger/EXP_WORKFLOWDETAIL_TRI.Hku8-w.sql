create trigger EXP_WORKFLOWDETAIL_TRI
    before insert
    on EXP_WORKFLOWDETAIL
    for each row
begin select exp_workflowDetail_id.nextval into :new.id from dual; end;
/

