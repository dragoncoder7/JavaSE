create trigger TASK_MODIFY_TRIGGER
    before insert
    on TASK_MODIFY
    for each row
begin select Prj_Log_SEQ.nextval into :new.id from dual; end ;
/

