create PROCEDURE CptDepreMethod2_Insert (depreid_1 	integer, time_2 	decimal, depreunit_3 	decimal, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into CptDepreMethod2 ( depreid, time, depreunit)  VALUES ( depreid_1, time_2, depreunit_3); end;


/

