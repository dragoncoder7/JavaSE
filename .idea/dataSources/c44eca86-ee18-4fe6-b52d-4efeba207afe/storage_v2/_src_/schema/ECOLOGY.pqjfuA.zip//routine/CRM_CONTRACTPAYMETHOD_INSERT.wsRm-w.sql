create PROCEDURE CRM_ContractPayMethod_Insert ( contractId_1  integer  , prjName_1  varchar2   , typeId_1  integer  , payPrice_1  number  , payDate_1  char    , factPrice_1  number , factDate_1  char  , qualification_1 varchar2 , isFinish_1  integer  , isRemind_1  integer  , feetypeid_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin INSERT INTO CRM_ContractPayMethod (contractId , prjName , typeId , payPrice , payDate , factPrice , factDate , qualification , isFinish , isRemind,feetypeid )  VALUES (contractId_1, prjName_1, typeId_1, payPrice_1 , payDate_1 , factPrice_1 , factDate_1 , qualification_1 , isFinish_1 , isRemind_1,feetypeid_1); end;


/

