create trigger MODE_DMLACTIONSQLSET_TRI
    before insert
    on MODE_DMLACTIONSQLSET
    for each row
begin select mode_dmlactionsqlset_seq.nextval into :new.id from dual; end;
/

