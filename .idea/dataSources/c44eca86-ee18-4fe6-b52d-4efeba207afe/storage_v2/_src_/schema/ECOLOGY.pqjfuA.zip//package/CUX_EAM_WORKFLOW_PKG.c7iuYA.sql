create package cux_eam_workflow_pkg is

  -- Author  : ADMINISTRATOR
  -- Created : 2021/1/7 10:11:57
  -- Purpose : 
  
  function get_leader_info(p_department_id number ) return varchar2 ; 

end cux_eam_workflow_pkg;


/

