create package cux_create_doc_utl_pkg is

  -- Author  : CEDAR
  -- Created : 2024/7/5 8:43:43
  -- Purpose : 创建单据使用到的标准方法

  /*
  通过流程ID,获得流程的开始节点
  */
  procedure get_begin_nodeid(p_workflow_id number, --流程id
                             x_node_id     out number, --开始结点
                             x_node_type   out varchar2, --结点类型
                             x_code        out varchar2,
                             x_msg         out varchar2);

end cux_create_doc_utl_pkg;
/

