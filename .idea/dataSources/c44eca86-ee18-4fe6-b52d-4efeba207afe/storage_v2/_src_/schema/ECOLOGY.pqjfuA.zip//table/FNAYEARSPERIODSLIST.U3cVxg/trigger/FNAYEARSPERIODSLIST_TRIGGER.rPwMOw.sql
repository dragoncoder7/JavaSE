create trigger FNAYEARSPERIODSLIST_TRIGGER
    before insert
    on FNAYEARSPERIODSLIST
    for each row
begin select FnaYearsPeriodsList_id.nextval into :new.id from dual; end;
/

