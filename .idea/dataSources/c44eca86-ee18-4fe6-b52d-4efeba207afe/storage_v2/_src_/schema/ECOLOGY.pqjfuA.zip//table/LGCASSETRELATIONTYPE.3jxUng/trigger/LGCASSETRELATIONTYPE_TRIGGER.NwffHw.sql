create trigger LGCASSETRELATIONTYPE_TRIGGER
    before insert
    on LGCASSETRELATIONTYPE
    for each row
begin select LgcAssetRelationType_id.nextval into :new.id from dual; end ;
/

