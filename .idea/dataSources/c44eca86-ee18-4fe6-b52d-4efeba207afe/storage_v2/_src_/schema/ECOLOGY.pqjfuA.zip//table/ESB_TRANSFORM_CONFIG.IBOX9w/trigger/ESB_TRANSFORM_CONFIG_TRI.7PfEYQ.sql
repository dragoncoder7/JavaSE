create trigger ESB_TRANSFORM_CONFIG_TRI
    before insert
    on ESB_TRANSFORM_CONFIG
    for each row
begin select esb_transform_config_seq.nextval into :new.id from dual; end;
/

