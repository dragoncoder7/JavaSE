create PROCEDURE CRM_SellChance_Update ( creater_1 integer , subject_1 varchar2 , customerid_1 integer , comefromid_1 integer , sellstatusid_1 integer , endtatusid_1 char , predate_1 char , preyield_1 number , currencyid_1 integer , probability_1 number , content_1 varchar2 , id_1 integer, sufactor_1 integer, defactor_1 integer, departmentId_1 integer, subCompanyId_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update CRM_SellChance set  creater = creater_1, subject = subject_1, customerid =customerid_1, comefromid =comefromid_1, sellstatusid=sellstatusid_1 , endtatusid =endtatusid_1, predate=predate_1 , preyield =preyield_1, currencyid =currencyid_1, probability =probability_1, content= content_1, sufactor = sufactor_1, defactor = defactor_1, departmentId = departmentId_1, subCompanyId = subCompanyId_1 WHERE id=id_1; end;


/

