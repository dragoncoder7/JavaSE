create trigger CRM_CONTACTWAY_TRIGGER
    before insert
    on CRM_CONTACTWAY
    for each row
begin select CRM_ContactWay_id.nextval into :new.id from dual; end;
/

