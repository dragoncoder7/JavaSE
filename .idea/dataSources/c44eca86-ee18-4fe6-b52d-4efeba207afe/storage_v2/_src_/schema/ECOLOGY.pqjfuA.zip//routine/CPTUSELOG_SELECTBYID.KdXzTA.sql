create PROCEDURE CptUseLog_SelectByID ( id_1 varchar2 , flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select * from CptUseLog where id = to_number( id_1); end;


/

