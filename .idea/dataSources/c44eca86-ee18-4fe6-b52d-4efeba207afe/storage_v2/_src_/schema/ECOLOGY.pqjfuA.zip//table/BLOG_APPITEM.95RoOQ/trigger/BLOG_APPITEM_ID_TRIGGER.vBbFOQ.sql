create trigger BLOG_APPITEM_ID_TRIGGER
    before insert
    on BLOG_APPITEM
    for each row
begin select blog_AppItem_id.nextval into :new.id from dual; end;
/

