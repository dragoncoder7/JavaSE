create trigger FNACREATEXMLSQLLOG_TRIGGER
    before insert
    on FNACREATEXMLSQLLOG
    for each row
begin select seq_FnaCreateXmlSqlLog_id.nextval into :new.id from dual; end;
/

