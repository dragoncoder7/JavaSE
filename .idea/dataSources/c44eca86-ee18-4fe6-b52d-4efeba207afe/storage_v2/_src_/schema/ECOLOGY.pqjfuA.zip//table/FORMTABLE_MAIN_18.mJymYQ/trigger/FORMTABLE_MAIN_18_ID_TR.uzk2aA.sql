create trigger FORMTABLE_MAIN_18_ID_TR
    before insert
    on FORMTABLE_MAIN_18
    for each row
begin select formtable_main_18_Id.nextval into :new.id from dual;  end;


/

