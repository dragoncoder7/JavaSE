create trigger FORMTABLE_MAIN_101_ID_TR
    before insert
    on FORMTABLE_MAIN_101
    for each row
begin select formtable_main_101_Id.nextval into :new.id from dual;  end;
/

