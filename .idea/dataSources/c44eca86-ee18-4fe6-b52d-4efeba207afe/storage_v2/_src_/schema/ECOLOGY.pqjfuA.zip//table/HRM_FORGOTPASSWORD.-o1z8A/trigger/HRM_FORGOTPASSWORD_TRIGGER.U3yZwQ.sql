create trigger HRM_FORGOTPASSWORD_TRIGGER
    before insert
    on HRM_FORGOTPASSWORD
    for each row
begin select hrm_forgotPassword_ID.nextval INTO :new.id from dual; end;
/

