create PROCEDURE CptCapitalGroup_Insert (name_1 	varchar2, description_1 	varchar2, parentid_1 	integer, flag	out integer, msg out varchar2,thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CptCapitalGroup ( name,description, parentid) VALUES ( name_1, description_1, parentid_1); end;


/

