create PROCEDURE CptCapitalAssortment_SRoot (  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptCapitalAssortment where supassortmentid = 0; end;


/

