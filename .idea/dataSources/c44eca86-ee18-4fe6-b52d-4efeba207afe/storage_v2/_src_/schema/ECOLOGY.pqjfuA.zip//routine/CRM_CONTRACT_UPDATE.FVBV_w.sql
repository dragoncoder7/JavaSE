create PROCEDURE CRM_Contract_Update (id_1 	integer , name_1  varchar2   , typeId_1  integer  , docId_1  varchar2   , price_1  number  , crmId_1  integer  , contacterId_1  integer  , startDate_1  char   , endDate_1  char   , manager_1  integer  , status_1  integer  , isRemind_1  integer  , remindDay_1  integer  , prjid_1 integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin UPDATE CRM_Contract SET name = name_1, typeId = typeId_1 , docId = docId_1 , price = price_1 , crmId = crmId_1 , contacterId = contacterId_1 , startDate = startDate_1 , endDate = endDate_1 , manager = manager_1 , status = status_1 , isRemind = isRemind_1 , remindDay = remindDay_1 ,projid=prjid_1  where id = id_1; end;


/

