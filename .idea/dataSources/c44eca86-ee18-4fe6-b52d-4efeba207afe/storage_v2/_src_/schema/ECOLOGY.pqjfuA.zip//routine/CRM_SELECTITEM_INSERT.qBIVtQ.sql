create procedure crm_selectitem_insert ( fieldname_1 in varchar, selectvalue_1 in VARCHAR, selectname_1 in varchar, fieldorder_1 in varchar, isdel_1 in varchar ) AS maxid NUMBER(10); BEGIN SELECT id into maxid  from CRM_CustomerDefinField  where fieldname = fieldname_1; insert into crm_selectitem (fieldid,selectvalue,selectname,fieldorder,isdel)values(maxid,selectvalue_1,selectname_1,fieldorder_1,isdel_1); END;
/

