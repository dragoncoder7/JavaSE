create PROCEDURE CptCapital_SCountByResourceid (resourceid_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select count(id) from CptCapital where resourceid = resourceid_1 and isdata= '2' ; end;


/

