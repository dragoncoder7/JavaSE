create trigger EDC_TASK_INS_TRG
    before insert
    on EDC_TASK
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_task_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

