create trigger HPELEMENT_QUICKDE_TRI
    before insert
    on HPELEMENT_QUICKENTRYDETIAL
    for each row
begin select hpElement_quickde_seq.nextval into :new.id from DUAL; END;
/

