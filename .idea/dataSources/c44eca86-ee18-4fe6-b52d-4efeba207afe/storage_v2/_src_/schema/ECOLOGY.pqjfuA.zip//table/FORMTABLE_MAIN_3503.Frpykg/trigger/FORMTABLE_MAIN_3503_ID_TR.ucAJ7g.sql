create trigger FORMTABLE_MAIN_3503_ID_TR
    before insert
    on FORMTABLE_MAIN_3503
    for each row
begin select formtable_main_3503_Id.nextval into :new.id from dual; end;
/

