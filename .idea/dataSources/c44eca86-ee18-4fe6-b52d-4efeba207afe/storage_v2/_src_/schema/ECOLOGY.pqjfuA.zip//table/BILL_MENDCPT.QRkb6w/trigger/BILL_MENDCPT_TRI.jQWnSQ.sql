create trigger BILL_MENDCPT_TRI
    before insert
    on BILL_MENDCPT
    for each row
begin select bill_mendCpt_id.nextval into :new.id from dual; end;
/

