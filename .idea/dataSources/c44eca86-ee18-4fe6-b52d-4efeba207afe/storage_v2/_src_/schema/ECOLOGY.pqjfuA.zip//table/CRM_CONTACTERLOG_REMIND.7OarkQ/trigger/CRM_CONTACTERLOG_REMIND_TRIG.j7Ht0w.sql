create trigger CRM_CONTACTERLOG_REMIND_TRIG
    before insert
    on CRM_CONTACTERLOG_REMIND
    for each row
begin select CRM_ContacterLog_Remind_id.nextval into :new.id from dual; end;
/

