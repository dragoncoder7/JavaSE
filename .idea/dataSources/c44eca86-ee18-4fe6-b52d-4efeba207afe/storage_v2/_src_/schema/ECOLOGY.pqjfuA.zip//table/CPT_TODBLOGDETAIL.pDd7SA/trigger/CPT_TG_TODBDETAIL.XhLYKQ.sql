create trigger CPT_TG_TODBDETAIL
    before insert
    on CPT_TODBLOGDETAIL
    for each row
    when (new.id is null)
begin select cptToDBDetail_id.Nextval into:new.id from dual; end;
/

