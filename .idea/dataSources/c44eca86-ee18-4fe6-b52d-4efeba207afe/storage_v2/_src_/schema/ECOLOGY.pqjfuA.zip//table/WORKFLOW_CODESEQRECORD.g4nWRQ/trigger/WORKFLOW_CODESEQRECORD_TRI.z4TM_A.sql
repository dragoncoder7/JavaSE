create trigger WORKFLOW_CODESEQRECORD_TRI
    before insert
    on WORKFLOW_CODESEQRECORD
    for each row
begin select workflow_codeSeqRecord_id.nextval into :new.id from dual; end;
/

