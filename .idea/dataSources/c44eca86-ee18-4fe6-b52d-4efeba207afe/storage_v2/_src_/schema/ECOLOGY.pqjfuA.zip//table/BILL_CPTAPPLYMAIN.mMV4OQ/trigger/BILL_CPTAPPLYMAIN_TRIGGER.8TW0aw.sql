create trigger BILL_CPTAPPLYMAIN_TRIGGER
    before insert
    on BILL_CPTAPPLYMAIN
    for each row
begin select bill_CptApplyMain_id.nextval INTO :new.id from dual; end;
/

