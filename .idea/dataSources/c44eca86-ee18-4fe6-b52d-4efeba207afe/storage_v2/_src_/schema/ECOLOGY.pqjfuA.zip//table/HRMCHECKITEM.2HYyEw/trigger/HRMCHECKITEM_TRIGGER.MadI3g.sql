create trigger HRMCHECKITEM_TRIGGER
    before insert
    on HRMCHECKITEM
    for each row
begin select HrmCheckItem_id.nextval INTO :new.id from dual; end;
/

