create PROCEDURE "CPTCAPITALMODIFY_INSERT" ( capitalid_1 integer , field_1 varchar2 , oldvalue_1 varchar2 , currentvalue_1 varchar2 , resourceid_1 integer , modifydate_1 char , flag out integer , msg out varchar2 , thecursor IN OUT cursor_define . weavercursor ) AS begin INSERT INTO CptCapitalModify ( cptid , field  , oldvalue  , currentvalue  , resourceid , modifydate ) VALUES (capitalid_1, field_1, oldvalue_1, currentvalue_1, resourceid_1, modifydate_1) ;  end;


/

