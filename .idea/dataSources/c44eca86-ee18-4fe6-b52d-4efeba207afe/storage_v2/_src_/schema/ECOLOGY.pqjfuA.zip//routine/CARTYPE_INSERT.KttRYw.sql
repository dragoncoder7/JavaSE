create PROCEDURE CarType_Insert (name_1 	varchar2, description_2  varchar2, usefee_3    number , flag out integer , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor	) AS begin insert into cartype(name,description,usefee) values (name_1,description_2,usefee_3); end;


/

