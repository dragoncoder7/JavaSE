create trigger FNABOATINVOICE_TRIGGER
    before insert
    on FNABOATINVOICE
    for each row
begin select seq_fnaBoatInvoice.nextval into :new.id from dual; end;
/

