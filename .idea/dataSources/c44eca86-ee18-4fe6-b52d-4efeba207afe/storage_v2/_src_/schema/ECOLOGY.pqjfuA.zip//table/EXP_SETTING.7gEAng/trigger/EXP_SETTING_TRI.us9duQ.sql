create trigger EXP_SETTING_TRI
    before insert
    on EXP_SETTING
    for each row
begin select exp_setting_id.nextval into :new.id from dual; end;
/

