create trigger PORTAL_MLOGINPAGE_TRIGGER
    before insert
    on PORTAL_MLOGINPAGE
    for each row
begin select portal_mloginpage_seq.nextval into :new.id from dual; end;
/

