create trigger CHECKMOBILEMODERULE_ID_TRI
    before insert
    on CHECKMOBILEMODERULE
    for each row
begin select checkmobilemoderule_id.nextval into :new.id from dual; end;
/

