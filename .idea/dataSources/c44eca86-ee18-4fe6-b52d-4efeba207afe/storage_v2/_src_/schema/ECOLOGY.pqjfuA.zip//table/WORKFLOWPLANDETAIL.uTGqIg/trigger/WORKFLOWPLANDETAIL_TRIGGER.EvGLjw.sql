create trigger WORKFLOWPLANDETAIL_TRIGGER
    before insert
    on WORKFLOWPLANDETAIL
    for each row
begin select WorkFlowPlanDetail_id.nextval into :new.id from dual; end;
/

