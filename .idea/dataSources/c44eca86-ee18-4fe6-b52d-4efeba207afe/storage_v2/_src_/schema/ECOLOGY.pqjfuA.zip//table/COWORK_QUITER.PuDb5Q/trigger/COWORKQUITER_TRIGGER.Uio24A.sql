create trigger COWORKQUITER_TRIGGER
    before insert
    on COWORK_QUITER
    for each row
begin select coworkquiter_seq.nextval into:new.id from sys.dual; end;
/

