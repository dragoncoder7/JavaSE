create trigger HRMINFOSTATUS_TRIGGER
    before insert
    on HRMINFOSTATUS
    for each row
begin select HrmInfoStatus_id.nextval into :new.id from dual; end;
/

