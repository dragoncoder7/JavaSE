create trigger MEETINGTYPE_SHARE_TRIGGER
    before insert
    on MEETINGTYPE_SHARE
    for each row
begin select MeetingType_share_id.nextval into :new.id from dual; end ;
/

