create trigger SOCIAL_IMCONVERSATION_ID_TRI
    before insert
    on SOCIAL_IMCONVERSATION
    for each row
begin select social_IMConversation_id.nextval into :new.id from dual; end;
/

