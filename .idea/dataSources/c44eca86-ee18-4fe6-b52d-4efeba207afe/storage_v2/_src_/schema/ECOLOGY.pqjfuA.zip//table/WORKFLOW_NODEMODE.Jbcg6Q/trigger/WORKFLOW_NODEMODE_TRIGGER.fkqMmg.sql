create trigger WORKFLOW_NODEMODE_TRIGGER
    before insert
    on WORKFLOW_NODEMODE
    for each row
begin select workflow_nodemode_id.nextval into :new.id from dual; end;
/

