create trigger ESBMETHODPARAMVALUE_ID_TRI
    before insert
    on ESBMETHODPARAMVALUE
    for each row
begin select esbformactionset_id.nextval into :new.id from dual; end;
/

