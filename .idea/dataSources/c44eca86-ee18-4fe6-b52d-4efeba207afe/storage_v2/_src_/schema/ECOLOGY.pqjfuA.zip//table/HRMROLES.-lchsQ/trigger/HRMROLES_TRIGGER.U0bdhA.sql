create trigger HRMROLES_TRIGGER
    before insert
    on HRMROLES
    for each row
begin select HrmRoles_id.nextval into :new.id from dual; end;
/

