create trigger DOCPREVIEW_ID_TRIGGER
    before insert
    on DOCPREVIEW
    for each row
begin select DocPreview_id.nextval into :new.id from dual; end;
/

