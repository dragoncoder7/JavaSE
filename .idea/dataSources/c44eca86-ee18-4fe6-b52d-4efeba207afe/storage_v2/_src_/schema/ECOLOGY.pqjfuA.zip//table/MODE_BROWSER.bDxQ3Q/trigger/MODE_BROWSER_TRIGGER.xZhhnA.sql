create trigger MODE_BROWSER_TRIGGER
    before insert
    on MODE_BROWSER
    for each row
begin  select MODE_BROWSER_id.nextval into :new.id from dual; end;
/

