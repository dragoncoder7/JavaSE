create trigger WORKPLANWEEKLIST_GROUP_TRIGGER
    before insert
    on WORKPLANWEEKLIST_GROUP
    for each row
begin select WorkPlanWeekList_Group_ID.nextval into :new.id from dual; end;
/

