create trigger SENSITIVE_WORDS_TYPE_TRI
    before insert
    on SENSITIVE_WORDS_TYPE
    for each row
begin select sensitive_words_type_id.nextval into :new.id from dual; end;
/

