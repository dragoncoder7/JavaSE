create trigger DBUPGRADEMAIN_TRIGGER
    before insert
    on DBUPGRADEMAIN
    for each row
begin select DBUpgradeMain_id.nextval into :new.id from dual; end;
/

