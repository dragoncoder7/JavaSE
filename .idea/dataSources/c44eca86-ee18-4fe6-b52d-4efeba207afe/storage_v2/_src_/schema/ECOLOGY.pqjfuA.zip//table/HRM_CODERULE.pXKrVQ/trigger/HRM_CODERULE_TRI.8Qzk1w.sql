create trigger HRM_CODERULE_TRI
    before insert
    on HRM_CODERULE
    for each row
begin select hrm_coderule_id.nextval into :new.id from dual; end;
/

