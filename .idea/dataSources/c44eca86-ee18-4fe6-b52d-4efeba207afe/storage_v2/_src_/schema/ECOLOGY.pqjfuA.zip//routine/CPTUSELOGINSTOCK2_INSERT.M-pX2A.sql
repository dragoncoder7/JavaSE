create PROCEDURE CptUseLogInStock2_Insert (capitalid_1 	integer, usedate_2 	char, usecount_5 	integer, userequest_7  integer, remark_11 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS departmentid_1  integer; resourceid_1 integer; location_1 varchar2(4000); num_1 integer; recordcount integer; begin  select 	count(*) into recordcount from CptCapital where id = capitalid_1; if recordcount > 0 then  select 	departmentid,resourceid,location,capitalnum into departmentid_1, resourceid_1,location_1,num_1 from CptCapital where id = capitalid_1; end if ;  INSERT INTO CptUseLog ( capitalid, usedate, usedeptid, useresourceid, usecount, useaddress, userequest, maintaincompany, fee, usestatus, remark)  VALUES ( capitalid_1, usedate_2, departmentid_1, resourceid_1, usecount_5, location_1, userequest_7, '', 0, '1', remark_11);  Update CptCapital Set capitalnum = num_1+usecount_5 where id = capitalid_1; end;


/

