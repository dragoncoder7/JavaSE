create PROCEDURE CrmShareDetail_SByCrmId (crmid_1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select * from CrmShareDetail where crmid = crmid_1 ; end;


/

