create trigger SOCIAL_IMDELGROUPLOG_TRIGGER
    before insert
    on SOCIAL_IMDELGROUPLOG
    for each row
begin select social_ImDelGroupLog_seq.nextval into:new.id from dual; end;
/

