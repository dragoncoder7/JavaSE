create PROCEDURE CRM_ContactLog_Update (id_1 	integer, contacterid_1 	integer, resourceid_1 	integer, agentid_1 	integer, contactway_1 	integer, ispassive_1 	smallint, subject_1 	varchar2, contacttype_1 	integer, contactdate_1 	varchar2, contacttime_1 	varchar2, enddate_1 	varchar2, endtime_1 	varchar2, contactinfo_1 varchar2, documentid_1 	integer, isfinished_1 smallint, flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin UPDATE CRM_ContactLog SET contacterid	 = contacterid_1, resourceid	 = resourceid_1, agentid	 = agentid_1, contactway	 = contactway_1, ispassive	 = ispassive_1, subject	 = subject_1, contacttype	 = contacttype_1, contactdate	 = contactdate_1, contacttime	 = contacttime_1, enddate	 = enddate_1, endtime	 = endtime_1, contactinfo	 = contactinfo_1, documentid	 = documentid_1, isfinished	 = isfinished_1 WHERE ( id	 = id_1); end;


/

