create trigger WORKFLOW_FORMMODE_TRIGGER
    before insert
    on WORKFLOW_FORMMODE
    for each row
begin select workflow_formmode_id.nextval into :new.id from dual; end;
/

