create trigger WF_BARCODESETDETAIL_TRI
    before insert
    on WORKFLOW_BARCODESETDETAIL
    for each row
begin select Wf_BarCodeSetDetail_id.nextval into :new.id from dual; end;
/

