create trigger WORKFLOW_TESTLOG_TRI
    before insert
    on WORKFLOW_TESTLOG
    for each row
begin select workflow_testlog_seq.nextval into :new.id from dual; end;
/

