create trigger DP_ATTENTION_TRI
    before insert
    on DP_ATTENTION
    for each row
BEGIN SELECT DP_Attention_id.NEXTVAL INTO :NEW.id FROM dual; END;
/

