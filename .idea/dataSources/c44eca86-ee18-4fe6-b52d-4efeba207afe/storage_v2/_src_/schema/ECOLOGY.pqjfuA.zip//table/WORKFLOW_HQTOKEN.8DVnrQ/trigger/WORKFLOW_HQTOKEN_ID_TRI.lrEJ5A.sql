create trigger WORKFLOW_HQTOKEN_ID_TRI
    before insert
    on WORKFLOW_HQTOKEN
    for each row
begin select workflow_hqtoken_id.nextval into :new.id from dual; end;
/

