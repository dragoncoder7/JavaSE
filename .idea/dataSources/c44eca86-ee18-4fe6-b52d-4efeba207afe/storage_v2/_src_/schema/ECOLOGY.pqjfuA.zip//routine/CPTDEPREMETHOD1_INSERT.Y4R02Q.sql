create PROCEDURE CptDepreMethod1_Insert (name_1 	varchar2, description_2 	varchar2, depretype_3 	char, timelimit_4 	decimal, startunit_5 	decimal, endunit_6 	decimal, deprefunc_7 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into CptDepreMethod1 ( name, description, depretype, timelimit, startunit, endunit, deprefunc)  VALUES ( name_1, description_2, depretype_3, timelimit_4, startunit_5, endunit_6, deprefunc_7); open thecursor for select max(id) from CptDepreMethod1; end;


/

