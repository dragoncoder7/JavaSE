create trigger WORKFLOW_INITIALIZATION_TRI
    before insert
    on WORKFLOW_INITIALIZATION
    for each row
begin select Workflow_Initialization_seq.nextval into :new.id from DUAL; END;
/

