create trigger FORMTABLE_MAIN_3499_DT1_ID_TR
    before insert
    on FORMTABLE_MAIN_3499_DT1
    for each row
begin select formtable_main_3499_dt1_Id.nextval into :new.id from dual;  end;
/

