create PROCEDURE CRM_PayInfo_update (id_1		integer, factprice_1	number, factdate_1 char, creater_1 integer, formNum_1   varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update  CRM_PayInfo set factprice=factprice_1, factdate=factdate_1, creater=creater_1, formNum=formNum_1 WHERE id=id_1; end;


/

