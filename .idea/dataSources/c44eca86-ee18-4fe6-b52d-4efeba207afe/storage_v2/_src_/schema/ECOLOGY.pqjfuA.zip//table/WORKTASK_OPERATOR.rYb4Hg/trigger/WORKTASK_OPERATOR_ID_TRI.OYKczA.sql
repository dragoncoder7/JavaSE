create trigger WORKTASK_OPERATOR_ID_TRI
    before insert
    on WORKTASK_OPERATOR
    for each row
begin select worktask_operator_id.nextval into :new.id from dual; end;
/

