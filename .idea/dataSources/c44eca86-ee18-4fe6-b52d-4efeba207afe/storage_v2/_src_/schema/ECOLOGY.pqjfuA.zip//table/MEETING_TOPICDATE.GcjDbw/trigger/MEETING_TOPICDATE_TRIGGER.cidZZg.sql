create trigger MEETING_TOPICDATE_TRIGGER
    before insert
    on MEETING_TOPICDATE
    for each row
begin select Meeting_TopicDate_id.nextval into :new.id from dual; end ;
/

