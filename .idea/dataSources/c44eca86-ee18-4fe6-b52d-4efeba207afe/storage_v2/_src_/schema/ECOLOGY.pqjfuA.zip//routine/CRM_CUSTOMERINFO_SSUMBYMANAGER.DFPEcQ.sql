create PROCEDURE CRM_CustomerInfo_SSumByManager ( id_1	integer ,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select count(id) from CRM_CustomerInfo where manager = id_1 ; end;


/

