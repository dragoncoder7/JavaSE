create trigger CRM_SEASCUSTOMER_TR1
    before insert
    on CRM_SEASCUSTOMER
    for each row
    when (new.id is null)
begin select seq_crm_seas.nextval into:new.id from dual; end;
/

