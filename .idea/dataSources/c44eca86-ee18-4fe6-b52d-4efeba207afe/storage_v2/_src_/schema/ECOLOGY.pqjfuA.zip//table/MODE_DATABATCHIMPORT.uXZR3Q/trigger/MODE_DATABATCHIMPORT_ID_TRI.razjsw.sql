create trigger MODE_DATABATCHIMPORT_ID_TRI
    before insert
    on MODE_DATABATCHIMPORT
    for each row
begin select mode_DataBatchImport_id.nextval into :new.id from dual; end;
/

