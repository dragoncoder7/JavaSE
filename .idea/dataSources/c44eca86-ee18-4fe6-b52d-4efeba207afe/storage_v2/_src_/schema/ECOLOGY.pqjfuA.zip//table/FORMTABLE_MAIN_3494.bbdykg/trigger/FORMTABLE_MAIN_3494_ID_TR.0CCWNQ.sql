create trigger FORMTABLE_MAIN_3494_ID_TR
    before insert
    on FORMTABLE_MAIN_3494
    for each row
begin select formtable_main_3494_Id.nextval into :new.id from dual;  end;
/

