create trigger DBUPGRADEDETAIL_TRIGGER
    before insert
    on DBUPGRADEDETAIL
    for each row
begin select DBUpgradeDetail_id.nextval into :new.id from dual; end;
/

