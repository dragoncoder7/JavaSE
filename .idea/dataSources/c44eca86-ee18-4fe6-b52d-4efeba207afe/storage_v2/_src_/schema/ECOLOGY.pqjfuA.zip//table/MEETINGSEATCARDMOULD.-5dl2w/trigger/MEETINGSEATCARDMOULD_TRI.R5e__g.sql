create trigger MEETINGSEATCARDMOULD_TRI
    before insert
    on MEETINGSEATCARDMOULD
    for each row
begin select MeetingSeatCardMould_ID.nextval into :new.id from dual; end;
/

