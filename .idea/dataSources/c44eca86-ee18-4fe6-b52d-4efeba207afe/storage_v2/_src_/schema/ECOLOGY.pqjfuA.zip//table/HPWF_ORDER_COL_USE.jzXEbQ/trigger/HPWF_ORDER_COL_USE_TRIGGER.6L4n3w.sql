create trigger HPWF_ORDER_COL_USE_TRIGGER
    before insert
    on HPWF_ORDER_COL_USE
    for each row
begin select hpwf_order_col_use_seq.nextval into :new.id from dual; end;
/

