create PROCEDURE CptCapital_UpdatePic ( id_1 integer, capitalimageid_2 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS BEGIN UPDATE CptCapital SET capitalimageid = 0 WHERE id = id_1; DELETE ImageFile WHERE imagefileid = capitalimageid_2; END;


/

