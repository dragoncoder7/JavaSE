create PROCEDURE CRM_ContractProduct_Update1 ( id_1 	integer , productId_1  integer  , unitId_1  integer  , currencyId_1  integer  , price_1  number , depreciation_1  integer  , number_n_1  number  , sumPrice_1  number  , planDate_1  char    , isRemind_1  integer  , flag out integer  , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin UPDATE CRM_ContractProduct SET productId = productId_1 , unitId = unitId_1, currencyId = currencyId_1, price = price_1, depreciation = depreciation_1, number_n = number_n_1 , sumPrice = sumPrice_1, planDate = planDate_1 , isRemind = isRemind_1 where id = id_1 ; end;


/

