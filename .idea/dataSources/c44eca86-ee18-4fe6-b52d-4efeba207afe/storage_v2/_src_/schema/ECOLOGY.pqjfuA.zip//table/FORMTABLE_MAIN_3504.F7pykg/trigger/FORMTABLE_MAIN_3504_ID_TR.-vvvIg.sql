create trigger FORMTABLE_MAIN_3504_ID_TR
    before insert
    on FORMTABLE_MAIN_3504
    for each row
begin select formtable_main_3504_Id.nextval into :new.id from dual;  end;
/

