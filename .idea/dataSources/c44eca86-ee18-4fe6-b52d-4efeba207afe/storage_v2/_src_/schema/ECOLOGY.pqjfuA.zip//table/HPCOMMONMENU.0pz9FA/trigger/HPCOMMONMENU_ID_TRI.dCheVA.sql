create trigger HPCOMMONMENU_ID_TRI
    before insert
    on HPCOMMONMENU
    for each row
begin select hpCommonMenu_id.nextval into :new.id from dual; end;
/

