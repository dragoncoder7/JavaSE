create trigger WEATHER_TRIGGER
    before insert
    on WEATHER
    for each row
begin select Weather_id.nextval INTO :new.id from dual; end;
/

