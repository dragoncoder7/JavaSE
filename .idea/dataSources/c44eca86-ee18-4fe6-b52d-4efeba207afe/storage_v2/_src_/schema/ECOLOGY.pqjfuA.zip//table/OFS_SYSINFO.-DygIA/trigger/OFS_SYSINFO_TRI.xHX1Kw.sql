create trigger OFS_SYSINFO_TRI
    before insert
    on OFS_SYSINFO
    for each row
begin select ofs_sysinfo_id.nextval into :new.sysid from dual; end;
/

