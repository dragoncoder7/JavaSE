create trigger DATASEARCHPARAM_TRI
    before insert
    on DATASEARCHPARAM
    for each row
begin select datasearchparam_seq.nextval into :new.id from dual; end;
/

