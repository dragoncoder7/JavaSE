create PROCEDURE bill_NameCardinfo_SByResource ( resourceid1		integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin open thecursor for  select * from bill_NameCardinfo where resourceid=resourceid1; end;


/

