create PROCEDURE CRM_ContractPayMethod_Delete (id_1 	integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE CRM_ContractPayMethod WHERE ( id	 = id_1); end;


/

