create trigger BLOG_EXPORT_SORT_ID_TRI
    before insert
    on BLOG_EXPORT_SORT
    for each row
begin select blog_export_sort_SEQ.nextval into :new.id from dual; end;
/

