create PROCEDURE bill_HireResource_UpdateStatus ( id1		integer, status1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update bill_HireResource set status=status where id=id1; end;


/

