create trigger MOB_ELE_SHOWFIELDD_TRI
    before insert
    on HP_ELEMENT_SHOWFIELD_DETIAL
    for each row
begin select  mob_ele_showfieldd_seq.nextval into :new.id from DUAL; END;
/

