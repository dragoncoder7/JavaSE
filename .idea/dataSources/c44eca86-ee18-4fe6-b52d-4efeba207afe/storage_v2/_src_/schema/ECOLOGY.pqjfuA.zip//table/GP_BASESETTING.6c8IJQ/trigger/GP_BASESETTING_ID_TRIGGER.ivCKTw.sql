create trigger GP_BASESETTING_ID_TRIGGER
    before insert
    on GP_BASESETTING
    for each row
begin select GP_BaseSetting_id.nextval into :new.id from dual; end;
/

