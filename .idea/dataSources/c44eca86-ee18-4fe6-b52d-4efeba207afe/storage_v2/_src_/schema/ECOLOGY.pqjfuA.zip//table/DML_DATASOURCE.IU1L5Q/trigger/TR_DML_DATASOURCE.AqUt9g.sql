create trigger TR_DML_DATASOURCE
    before insert
    on DML_DATASOURCE
    for each row
begin select sq_dml_datasource.nextval into :new.id from dual; end;
/

