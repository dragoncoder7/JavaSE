create trigger INT_CACHE_PLUGIN_TRI
    before insert
    on INT_CACHE_PLUGIN
    for each row
begin select Int_Cache_Plugin_id.nextval into :new.id from dual; end ;
/

