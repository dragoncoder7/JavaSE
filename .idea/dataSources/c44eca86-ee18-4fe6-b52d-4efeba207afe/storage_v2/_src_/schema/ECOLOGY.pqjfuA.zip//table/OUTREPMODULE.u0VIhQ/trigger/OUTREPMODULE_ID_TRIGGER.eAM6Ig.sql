create trigger OUTREPMODULE_ID_TRIGGER
    before insert
    on OUTREPMODULE
    for each row
begin select outrepmodule_Id.nextval into :new.id from dual; end;
/

