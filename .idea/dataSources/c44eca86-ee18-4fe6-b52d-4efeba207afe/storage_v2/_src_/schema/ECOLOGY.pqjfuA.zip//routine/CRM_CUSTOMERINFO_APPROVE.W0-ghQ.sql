create PROCEDURE CRM_CustomerInfo_Approve (id_1 		integer, status_1 	integer, rating_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerInfo  SET  	  status	 = status_1, rating	 = rating_1  WHERE ( id	 = id_1) ; end;


/

