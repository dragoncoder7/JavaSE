create trigger DOCHANDWRITTENDETAIL_TRI
    before insert
    on DOCHANDWRITTENDETAIL
    for each row
begin select DocHandwrittenDetail_id.nextval into :new.id from dual; end;
/

