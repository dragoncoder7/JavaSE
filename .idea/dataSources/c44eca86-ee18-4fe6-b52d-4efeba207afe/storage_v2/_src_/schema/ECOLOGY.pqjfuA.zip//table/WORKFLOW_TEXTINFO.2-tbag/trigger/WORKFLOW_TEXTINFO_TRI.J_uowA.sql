create trigger WORKFLOW_TEXTINFO_TRI
    before insert
    on WORKFLOW_TEXTINFO
    for each row
begin select workflow_textInfo_seq.nextval into :new.id from dual; end;
/

