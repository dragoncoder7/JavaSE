create PROCEDURE CRM_Find_RecentRemark (id_1 	integer, flag	out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * from (select * from CRM_Log WHERE (customerid = id_1) ORDER BY submitdate DESC, submittime DESC) where rownum<4; end;


/

