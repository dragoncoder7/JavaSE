create trigger KQ_INITHISTORY_TRI
    before insert
    on KQ_INITHISTORY
    for each row
begin select kq_initHistory_id.nextval INTO :new.id from dual; end;
/

