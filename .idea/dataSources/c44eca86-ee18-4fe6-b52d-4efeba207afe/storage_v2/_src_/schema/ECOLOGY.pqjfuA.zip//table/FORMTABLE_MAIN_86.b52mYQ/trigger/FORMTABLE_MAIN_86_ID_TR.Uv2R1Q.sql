create trigger FORMTABLE_MAIN_86_ID_TR
    before insert
    on FORMTABLE_MAIN_86
    for each row
begin select formtable_main_86_Id.nextval into :new.id from dual;  end;
/

