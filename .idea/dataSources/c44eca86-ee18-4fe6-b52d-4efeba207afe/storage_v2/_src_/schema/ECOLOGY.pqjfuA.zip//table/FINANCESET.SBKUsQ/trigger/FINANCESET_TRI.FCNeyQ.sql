create trigger FINANCESET_TRI
    before insert
    on FINANCESET
    for each row
begin select financeset_seq.nextval into :new.id from dual; end;
/

