create trigger INT_FIELD_TRANSADAPTER_ID_TRI
    before insert
    on INT_FIELD_TRANSADAPTER
    for each row
begin select Int_Field_TransAdapter_id.nextval into :new.id from dual; end ;
/

