create trigger "workflow_interfaces_id_TRIGGER"
    before insert
    on WORKFLOW_INTERFACES
    for each row
begin select workflow_interfaces_id.nextval into :new.id from dual; end;
/

