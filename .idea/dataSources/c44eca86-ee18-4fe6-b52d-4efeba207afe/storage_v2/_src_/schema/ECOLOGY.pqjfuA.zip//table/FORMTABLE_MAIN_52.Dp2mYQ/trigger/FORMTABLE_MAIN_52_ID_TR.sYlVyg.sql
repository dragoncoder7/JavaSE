create trigger FORMTABLE_MAIN_52_ID_TR
    before insert
    on FORMTABLE_MAIN_52
    for each row
begin select formtable_main_52_Id.nextval into :new.id from dual;  end;
/

