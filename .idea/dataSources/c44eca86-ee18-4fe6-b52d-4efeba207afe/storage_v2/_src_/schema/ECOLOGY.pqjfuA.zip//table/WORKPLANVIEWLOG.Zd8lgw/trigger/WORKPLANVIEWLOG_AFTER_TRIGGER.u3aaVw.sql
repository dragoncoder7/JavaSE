create trigger WORKPLANVIEWLOG_AFTER_TRIGGER
    after insert
    on WORKPLANVIEWLOG
    for each row
DECLARE relatedname varchar(400); begin select  name into relatedname from workplan where id=:new.workPlanId; exception when others then select '???' into  relatedname from dual; SysMaintenanceLog_proc( :new.workPlanId, relatedname, :new.userId, :new.usertype, :new.viewType, '??????', '91', :new.logDate, :new.logTime, 1, :new.ipAddress, 0 ); end;


/

