create PROCEDURE CptDepreMethod2_SByDepreID (depreid1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * FROM CptDepreMethod2 WHERE  depreid	 = depreid1 order by  time ; end;


/

