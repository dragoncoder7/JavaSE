create trigger HPFPOINTADJUST_TRIGGER
    before insert
    on HRMPERFORMANCEPOINTADJUST
    for each row
begin select HPfPointAdjust_id.nextval into :new.id from dual; end;
/

