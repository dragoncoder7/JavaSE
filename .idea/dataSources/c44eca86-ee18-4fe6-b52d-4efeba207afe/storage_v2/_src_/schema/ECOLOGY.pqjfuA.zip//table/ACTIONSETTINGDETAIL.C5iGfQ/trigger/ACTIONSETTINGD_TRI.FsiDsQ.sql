create trigger ACTIONSETTINGD_TRI
    before insert
    on ACTIONSETTINGDETAIL
    for each row
begin select actionsettingd_seq.nextval into :new.id from dual; end;
/

