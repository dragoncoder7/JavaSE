create trigger BILL_RETURNCPT_TRI
    before insert
    on BILL_MENDCPT
    for each row
begin select bill_returncpt_id.nextval into :new.id from dual; end;
/

