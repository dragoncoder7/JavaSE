create trigger SUBSCRIBE1_INS_TRG
    before insert
    on ECOLOGY_MESSAGE_SUBSCRIBE
    for each row
begin select SUBSCRIBE1_ID_seq.nextval into :new.ID from dual; end;
/

