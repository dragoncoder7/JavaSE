create trigger WORKFLOW_CUSTOMPAGE_TRI
    before insert
    on WORKFLOW_CUSTOMPAGECONFIG
    for each row
begin select workflow_custompage_seq.nextval into :new.keyid from DUAL; END;
/

