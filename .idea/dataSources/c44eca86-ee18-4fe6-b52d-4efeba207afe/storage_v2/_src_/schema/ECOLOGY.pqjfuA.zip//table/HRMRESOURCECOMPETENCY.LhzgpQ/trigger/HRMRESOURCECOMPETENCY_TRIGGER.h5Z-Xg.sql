create trigger HRMRESOURCECOMPETENCY_TRIGGER
    before insert
    on HRMRESOURCECOMPETENCY
    for each row
begin select HrmResourceCompetency_id.nextval into :new.id from dual; end;
/

