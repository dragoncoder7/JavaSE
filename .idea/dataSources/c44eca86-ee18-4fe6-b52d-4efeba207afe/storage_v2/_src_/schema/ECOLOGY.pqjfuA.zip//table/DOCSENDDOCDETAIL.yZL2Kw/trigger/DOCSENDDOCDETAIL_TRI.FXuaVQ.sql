create trigger DOCSENDDOCDETAIL_TRI
    before insert
    on DOCSENDDOCDETAIL
    for each row
begin select DocSendDocDetail_id.nextval into :new.id from dual; end;
/

