create PROCEDURE CRM_ContactLog_Process (id_1 	integer, processdate_1 	varchar2, processtime_1 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_ContactLog SET isprocessed	 = 1, processdate	 = processdate_1, processtime	 = processtime_1 WHERE ( id	 = id_1); end;


/

