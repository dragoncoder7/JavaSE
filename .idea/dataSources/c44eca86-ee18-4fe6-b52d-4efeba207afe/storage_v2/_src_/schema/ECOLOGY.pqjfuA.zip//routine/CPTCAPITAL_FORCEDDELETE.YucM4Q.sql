create PROCEDURE CptCapital_ForcedDelete ( id_1 integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS isdata_1 integer; begin select isdata into isdata_1 from CptCapital where id = id_1; if (isdata_1 = 1) then UPDATE CptCapitalAssortment SET capitalcount = capitalcount-1 WHERE id IN (SELECT capitalgroupid FROM CptCapital WHERE id = id_1) ; end if; DELETE CptCapital WHERE id = id_1 ; end;


/

