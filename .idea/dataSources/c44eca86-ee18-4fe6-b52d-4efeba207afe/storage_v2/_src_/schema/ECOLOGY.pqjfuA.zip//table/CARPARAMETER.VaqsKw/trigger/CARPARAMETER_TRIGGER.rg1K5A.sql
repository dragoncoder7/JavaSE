create trigger CARPARAMETER_TRIGGER
    before insert
    on CARPARAMETER
    for each row
begin select CarParameter_id.nextval into :new.id from dual; end ;
/

