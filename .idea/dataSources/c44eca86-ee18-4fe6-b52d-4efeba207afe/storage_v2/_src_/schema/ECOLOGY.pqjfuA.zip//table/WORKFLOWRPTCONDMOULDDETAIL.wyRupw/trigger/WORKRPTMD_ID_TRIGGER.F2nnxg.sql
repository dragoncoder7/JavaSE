create trigger WORKRPTMD_ID_TRIGGER
    before insert
    on WORKFLOWRPTCONDMOULDDETAIL
    for each row
begin select WorkRptMD_id.nextval into :new.id from dual; end;
/

