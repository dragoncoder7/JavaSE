create trigger COWORK_TYPES_TRIGGER
    before insert
    on COWORK_TYPES
    for each row
begin select cowork_types_id.nextval into :new.id from dual; end;
/

