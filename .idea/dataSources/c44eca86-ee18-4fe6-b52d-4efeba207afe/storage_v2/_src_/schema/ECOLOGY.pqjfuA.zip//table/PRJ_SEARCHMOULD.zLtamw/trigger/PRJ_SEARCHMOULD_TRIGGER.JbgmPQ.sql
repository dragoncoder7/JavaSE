create trigger PRJ_SEARCHMOULD_TRIGGER
    before insert
    on PRJ_SEARCHMOULD
    for each row
begin select Prj_SearchMould_id.nextval into :new.id from dual; end;
/

