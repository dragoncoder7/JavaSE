create trigger WT_MONITORLOG_ID_TRI
    before insert
    on WORKTASK_MONITORLOG
    for each row
begin select wt_monitorlog_id.nextval into :new.id from dual; end;
/

