create trigger WR_INDITEM_STATISTICS_TRI
    before insert
    on WR_INDIVIDUALITEM_STATISTICS
    for each row
begin select WR_indItem_Statistics_SEQ.nextval into :new.id from dual; end;
/

