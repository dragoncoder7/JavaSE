create trigger ODOC_NODELINK_EXT_INSERT
    before insert
    on ODOC_NODELINK_EXT
    for each row
declare begin select odoc_nodelink_ext_id_seq.nextval into :new.ID from dual; end odoc_nodelink_ext_insert;
/

