create trigger MAILSHARE_TRIGGER
    before insert
    on MAILSHARE
    for each row
begin select MailShare_id.nextval into :new.id from dual; end ;
/

