create trigger ENC_FIELD_VIEW_SCOPE_TRI
    before insert
    on ENC_FIELD_VIEW_SCOPE
    for each row
begin select enc_field_view_scope_id.nextval into :new.id from dual; end;
/

