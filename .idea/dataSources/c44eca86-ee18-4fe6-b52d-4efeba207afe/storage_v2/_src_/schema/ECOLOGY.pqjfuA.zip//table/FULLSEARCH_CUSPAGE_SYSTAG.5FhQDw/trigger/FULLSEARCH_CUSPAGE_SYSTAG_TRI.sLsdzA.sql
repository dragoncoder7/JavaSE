create trigger FULLSEARCH_CUSPAGE_SYSTAG_TRI
    before insert
    on FULLSEARCH_CUSPAGE_SYSTAG
    for each row
begin select fullsearch_cuspage_sysTag_ID.nextval into :new.id from dual; end;
/

