create PROCEDURE bill_CptFetchDetail_Insert (cptfetchid 	integer, cptid_1 	integer, capitalid_2 	integer, number_3        number , unitprice_4 	number, amount_5 	number, needdate_6 	varchar2, purpose_7 	varchar2, cptdesc_8 	varchar2, flag	out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO bill_CptFetchDetail ( cptfetchid, cptid, capitalid, number_n, unitprice, amount, needdate, purpose, cptdesc) VALUES ( cptfetchid, cptid_1, capitalid_2, number_3, unitprice_4, amount_5, needdate_6, purpose_7, cptdesc_8); end;


/

