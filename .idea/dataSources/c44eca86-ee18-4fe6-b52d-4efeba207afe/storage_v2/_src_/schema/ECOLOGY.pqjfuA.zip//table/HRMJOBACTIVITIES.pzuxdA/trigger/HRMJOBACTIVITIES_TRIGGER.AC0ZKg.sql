create trigger HRMJOBACTIVITIES_TRIGGER
    before insert
    on HRMJOBACTIVITIES
    for each row
begin select HrmJobActivities_id.nextval into :new.id from dual; end;
/

