create trigger WEBMAGAZINETYPE_TRIGGER
    before insert
    on WEBMAGAZINETYPE
    for each row
begin select WebMagazineType_id.nextval into :new.id from dual; end ;
/

