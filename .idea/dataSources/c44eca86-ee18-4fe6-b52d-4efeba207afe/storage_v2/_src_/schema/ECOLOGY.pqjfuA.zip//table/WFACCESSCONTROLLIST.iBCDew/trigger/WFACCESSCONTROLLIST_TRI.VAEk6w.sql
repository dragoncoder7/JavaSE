create trigger WFACCESSCONTROLLIST_TRI
    before insert
    on WFACCESSCONTROLLIST
    for each row
BEGIN SELECT wfAccessControlList_MAINID.NEXTVAL INTO :NEW.MAINID FROM dual; END;
/

