create trigger AUTOCONFIGLOG_TRI
    before insert
    on AUTOCONFIGLOG
    for each row
begin select autoConfigLog_seq.nextval into :new.id from dual; end;
/

