create trigger PRJTSK_SELECTITEM_TRIGGER
    before insert
    on PRJTSK_SELECTITEM
    for each row
begin select prjtsk_SelectItem_ID.nextval into :new.id from dual; end;
/

