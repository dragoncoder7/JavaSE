create trigger DESK_TOP_MANAGER_TRI
    before insert
    on USERCOMMONMENUDESKTOPMANAGER
    for each row
begin select Desk_Top_Manager_id.nextval into :new.id from dual; end;
/

