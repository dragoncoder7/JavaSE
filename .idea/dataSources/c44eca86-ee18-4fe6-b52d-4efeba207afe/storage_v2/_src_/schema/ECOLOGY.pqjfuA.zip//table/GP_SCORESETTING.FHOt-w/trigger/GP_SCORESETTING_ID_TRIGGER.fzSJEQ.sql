create trigger GP_SCORESETTING_ID_TRIGGER
    before insert
    on GP_SCORESETTING
    for each row
begin select GP_ScoreSetting_id.nextval into :new.id from dual; end;
/

