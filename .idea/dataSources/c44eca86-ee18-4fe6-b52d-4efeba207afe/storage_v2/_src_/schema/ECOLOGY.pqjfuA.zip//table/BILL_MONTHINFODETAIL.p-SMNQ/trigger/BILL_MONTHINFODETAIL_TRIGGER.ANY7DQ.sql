create trigger BILL_MONTHINFODETAIL_TRIGGER
    before insert
    on BILL_MONTHINFODETAIL
    for each row
begin select bill_monthinfodetail_id.nextval INTO :new.id from dual; end;
/

