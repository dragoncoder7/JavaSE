create trigger GP_ACCESSSCORELOG_ID_TRIGGER
    before insert
    on GP_ACCESSSCORELOG
    for each row
begin select GP_AccessScoreLog_id.nextval into :new.id from dual; end;
/

