create trigger LDAPSETPARAM_TRI
    before insert
    on LDAPSETPARAM
    for each row
begin select ldapsetparam_seq.nextval into :new.id from dual; end;
/

