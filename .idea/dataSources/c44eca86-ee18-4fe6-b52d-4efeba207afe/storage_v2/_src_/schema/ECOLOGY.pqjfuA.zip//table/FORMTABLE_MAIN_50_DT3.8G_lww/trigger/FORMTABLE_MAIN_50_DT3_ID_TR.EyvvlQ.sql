create trigger FORMTABLE_MAIN_50_DT3_ID_TR
    before insert
    on FORMTABLE_MAIN_50_DT3
    for each row
begin select formtable_main_50_dt3_Id.nextval into :new.id from dual;  end;
/

