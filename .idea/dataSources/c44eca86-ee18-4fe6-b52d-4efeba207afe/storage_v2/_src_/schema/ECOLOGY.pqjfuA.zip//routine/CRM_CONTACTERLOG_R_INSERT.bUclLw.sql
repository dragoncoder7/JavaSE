create PROCEDURE CRM_ContacterLog_R_Insert (customerid_1 	integer, daytype_1	integer, before_1	integer, isremind_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin INSERT INTO CRM_ContacterLog_Remind (customerid,daytype,before,isremind) VALUES ( customerid_1, daytype_1 , before_1 , isremind_1); end;


/

