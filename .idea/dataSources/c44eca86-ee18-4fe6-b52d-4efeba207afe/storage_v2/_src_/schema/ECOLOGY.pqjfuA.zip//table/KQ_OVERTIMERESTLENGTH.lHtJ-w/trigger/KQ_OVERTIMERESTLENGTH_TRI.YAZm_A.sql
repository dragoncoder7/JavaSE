create trigger KQ_OVERTIMERESTLENGTH_TRI
    before insert
    on KQ_OVERTIMERESTLENGTH
    for each row
begin select kq_OvertimeRestlength_id.nextval INTO :new.id from dual; end;
/

