create PROCEDURE Bill_HrmResourceAbsense_SByW (flag out integer  , msg out varchar2,  thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select distinct workflowid , workflowname from Bill_HrmResourceAbsense; end;


/

