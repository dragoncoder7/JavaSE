create trigger WORKFLOW_FD_CACHE_TRIGGER
    before insert
    on WORKFLOW_FIELDDATA_CACHE
    for each row
begin select workflow_fielddata_cache_id.nextval into :new.id from dual; end;
/

