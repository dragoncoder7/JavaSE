create PROCEDURE CarType_SelectByID (   id_1 integer, flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin open thecursor for select * from cartype where id=id_1; end;


/

