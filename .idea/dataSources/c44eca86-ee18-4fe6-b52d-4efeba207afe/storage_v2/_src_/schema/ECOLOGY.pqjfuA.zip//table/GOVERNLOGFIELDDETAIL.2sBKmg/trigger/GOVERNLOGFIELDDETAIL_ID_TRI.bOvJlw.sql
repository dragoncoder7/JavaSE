create trigger GOVERNLOGFIELDDETAIL_ID_TRI
    before insert
    on GOVERNLOGFIELDDETAIL
    for each row
begin select GovernLogFieldDetail_id.nextval into :new.id from dual; end;
/

