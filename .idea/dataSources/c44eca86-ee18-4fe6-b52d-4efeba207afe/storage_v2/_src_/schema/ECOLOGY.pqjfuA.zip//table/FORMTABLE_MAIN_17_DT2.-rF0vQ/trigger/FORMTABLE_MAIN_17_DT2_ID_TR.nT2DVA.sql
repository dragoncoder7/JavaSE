create trigger FORMTABLE_MAIN_17_DT2_ID_TR
    before insert
    on FORMTABLE_MAIN_17_DT2
    for each row
begin select formtable_main_17_dt2_Id.nextval into :new.id from dual; end;
/

