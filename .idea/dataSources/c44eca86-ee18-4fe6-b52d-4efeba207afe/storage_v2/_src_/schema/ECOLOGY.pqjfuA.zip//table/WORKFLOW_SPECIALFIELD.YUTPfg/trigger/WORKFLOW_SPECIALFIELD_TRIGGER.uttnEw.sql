create trigger WORKFLOW_SPECIALFIELD_TRIGGER
    before insert
    on WORKFLOW_SPECIALFIELD
    for each row
begin select workflow_specialfield_id.nextval into :new.id from dual; end;
/

