create trigger MOULDBOOKMARK_TRIGGER
    before insert
    on MOULDBOOKMARK
    for each row
begin select MouldBookMark_Id.nextval into :new.id from dual; end;
/

