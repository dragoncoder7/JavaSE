create trigger SQLCOUNTER_TRI
    before insert
    on SQLCOUNTER
    for each row
begin select SqlCounter_id.nextval into :new.id from dual; 
 end;
/

