create trigger SRSUBRIGHT_TRIGGER
    before insert
    on SYSROLESUBCOMRIGHT
    for each row
begin select SysRoleSubcomRight_id.nextval into :new.id from dual; end;
/

