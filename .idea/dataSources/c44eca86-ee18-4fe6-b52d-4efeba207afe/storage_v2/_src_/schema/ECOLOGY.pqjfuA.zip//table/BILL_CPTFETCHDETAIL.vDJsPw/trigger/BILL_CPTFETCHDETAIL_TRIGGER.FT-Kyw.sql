create trigger BILL_CPTFETCHDETAIL_TRIGGER
    before insert
    on BILL_CPTFETCHDETAIL
    for each row
begin select bill_CptFetchDetail_id.nextval INTO :new.id from dual; end;
/

