create trigger INT_MODULE_DDL_DEF_ID_TRI
    before insert
    on INT_MODULE_DDL_DEF
    for each row
begin select Int_Module_DDL_Def_id.nextval into :new.id from dual; end ;
/

