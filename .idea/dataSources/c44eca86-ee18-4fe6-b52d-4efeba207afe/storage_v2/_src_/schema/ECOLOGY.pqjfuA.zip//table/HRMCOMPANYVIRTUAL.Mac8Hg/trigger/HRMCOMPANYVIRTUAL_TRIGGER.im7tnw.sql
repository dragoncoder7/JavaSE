create trigger HRMCOMPANYVIRTUAL_TRIGGER
    before insert
    on HRMCOMPANYVIRTUAL
    for each row
begin select HrmCompanyVirtual_id.nextval into :new.id from dual; end;
/

