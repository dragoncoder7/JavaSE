create trigger KQ_FLOW_DEDUCT_CARD_TRIGGER
    before insert
    on KQ_FLOW_DEDUCT_CARD
    for each row
begin select kq_flow_deduct_card_ID.nextval INTO :new.id from dual; end;
/

