create trigger KT_ACCESSLOG_ID_TRIGGER
    before insert
    on KT_ACCESSLOG
    for each row
begin select KT_AccessLog_id.nextval into :new.id from dual; end;
/

