create PROCEDURE CptCheckStockList_Update (id_1 	integer, realnumber_2 	integer, remark_3 	varchar2, apitalimageid_2     integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin update CptCheckStockList  SET  realnumber=realnumber_2, remark=remark_3  WHERE ( id=id_1); end;


/

