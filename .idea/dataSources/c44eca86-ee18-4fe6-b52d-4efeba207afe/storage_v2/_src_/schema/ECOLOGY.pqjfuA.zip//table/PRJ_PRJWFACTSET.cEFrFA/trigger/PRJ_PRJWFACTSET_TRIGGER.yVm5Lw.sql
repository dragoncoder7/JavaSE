create trigger PRJ_PRJWFACTSET_TRIGGER
    before insert
    on PRJ_PRJWFACTSET
    for each row
begin select prj_prjwfactset_ID.nextval into :new.id from dual; end;
/

