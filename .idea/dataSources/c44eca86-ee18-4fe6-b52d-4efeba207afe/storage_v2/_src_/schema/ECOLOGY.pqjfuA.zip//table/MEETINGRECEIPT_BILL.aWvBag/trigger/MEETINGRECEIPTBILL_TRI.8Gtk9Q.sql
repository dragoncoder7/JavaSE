create trigger MEETINGRECEIPTBILL_TRI
    before insert
    on MEETINGRECEIPT_BILL
    for each row
begin select meetingReceiptBill_id.nextval into :new.id from dual; end;
/

