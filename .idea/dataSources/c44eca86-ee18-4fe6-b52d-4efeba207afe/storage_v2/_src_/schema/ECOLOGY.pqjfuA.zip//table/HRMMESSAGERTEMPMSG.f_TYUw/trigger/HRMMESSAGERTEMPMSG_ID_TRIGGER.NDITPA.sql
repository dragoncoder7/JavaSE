create trigger HRMMESSAGERTEMPMSG_ID_TRIGGER
    before insert
    on HRMMESSAGERTEMPMSG
    for each row
begin select HrmMessagerTempMsg_id.nextval into :new.id from dual; end;
/

