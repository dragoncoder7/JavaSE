create trigger MODE_BARCODE_ID_TRI
    before insert
    on MODE_BARCODE
    for each row
begin select  mode_barcode_id.nextval into :new.id from dual; end;
/

