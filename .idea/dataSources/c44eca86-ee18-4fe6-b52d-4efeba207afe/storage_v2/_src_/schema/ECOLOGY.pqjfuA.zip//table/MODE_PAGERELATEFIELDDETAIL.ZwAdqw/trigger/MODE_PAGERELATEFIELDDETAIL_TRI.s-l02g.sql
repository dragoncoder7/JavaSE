create trigger MODE_PAGERELATEFIELDDETAIL_TRI
    before insert
    on MODE_PAGERELATEFIELDDETAIL
    for each row
begin select mode_pagerelatefielddetail_id.nextval into :new.id from dual; end;
/

