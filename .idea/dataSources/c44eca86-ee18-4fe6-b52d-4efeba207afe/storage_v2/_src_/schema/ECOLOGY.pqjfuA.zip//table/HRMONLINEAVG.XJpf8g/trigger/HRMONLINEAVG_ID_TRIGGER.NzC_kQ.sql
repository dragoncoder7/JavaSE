create trigger HRMONLINEAVG_ID_TRIGGER
    before insert
    on HRMONLINEAVG
    for each row
begin select HrmOnlineAvg_id.nextval into :new.id from dual; end;
/

