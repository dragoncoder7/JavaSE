create trigger WORKPLANRECEIVESCOPESET_TRI
    before insert
    on WORKPLANRECEIVESCOPESET
    for each row
begin select workplanReceiveScopeSet_id.nextval into :new.id from dual; end;
/

