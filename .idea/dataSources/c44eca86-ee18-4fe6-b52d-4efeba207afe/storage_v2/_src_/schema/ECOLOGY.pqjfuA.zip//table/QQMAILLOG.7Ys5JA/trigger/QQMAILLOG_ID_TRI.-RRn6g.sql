create trigger QQMAILLOG_ID_TRI
    before insert
    on QQMAILLOG
    for each row
begin select QQMailLog_id.nextval into :new.id from dual; end ;
/

