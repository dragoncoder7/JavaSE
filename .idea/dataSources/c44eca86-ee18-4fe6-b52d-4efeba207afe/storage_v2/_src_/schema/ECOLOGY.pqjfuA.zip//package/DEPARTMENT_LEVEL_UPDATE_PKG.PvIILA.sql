create package department_level_update_pkg is
  --create by cjl
  --date 2021-01-21
  --purpose 每天定时更新表department_level的数据
  procedure main;
end department_level_update_pkg;


/

