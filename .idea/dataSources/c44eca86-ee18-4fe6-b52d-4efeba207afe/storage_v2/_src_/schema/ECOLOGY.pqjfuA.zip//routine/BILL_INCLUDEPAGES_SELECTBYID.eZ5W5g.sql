create PROCEDURE bill_includepages_SelectByID ( id1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for  select * from workflow_bill where id=id1; end;


/

