create PROCEDURE CRM_Find_Creater (id1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT submiter,submitdate,submitertype from CRM_Log WHERE (customerid = id1) and (logtype = 'n'); end;


/

