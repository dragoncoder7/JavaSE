create trigger FORMTABLE_MAIN_51_ID_TR
    before insert
    on FORMTABLE_MAIN_51
    for each row
begin select formtable_main_51_Id.nextval into :new.id from dual;  end;
/

