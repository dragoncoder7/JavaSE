create trigger WORKFLOW_GROUPINFO_TRI
    before insert
    on WORKFLOW_GROUPINFO
    for each row
begin select workflow_groupinfo_seq.nextval into :new.id from dual; end;
/

