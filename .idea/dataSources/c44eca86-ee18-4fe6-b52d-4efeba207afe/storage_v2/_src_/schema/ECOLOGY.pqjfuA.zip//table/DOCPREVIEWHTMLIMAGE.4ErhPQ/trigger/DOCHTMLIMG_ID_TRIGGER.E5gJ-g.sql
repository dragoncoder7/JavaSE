create trigger DOCHTMLIMG_ID_TRIGGER
    before insert
    on DOCPREVIEWHTMLIMAGE
    for each row
begin select DocHtmlImg_id.nextval into :new.id from dual; end;
/

