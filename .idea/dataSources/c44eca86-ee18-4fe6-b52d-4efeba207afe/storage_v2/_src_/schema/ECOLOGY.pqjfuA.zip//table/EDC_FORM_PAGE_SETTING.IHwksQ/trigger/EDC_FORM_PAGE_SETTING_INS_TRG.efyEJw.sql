create trigger EDC_FORM_PAGE_SETTING_INS_TRG
    before insert
    on EDC_FORM_PAGE_SETTING
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_form_page_setting_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

