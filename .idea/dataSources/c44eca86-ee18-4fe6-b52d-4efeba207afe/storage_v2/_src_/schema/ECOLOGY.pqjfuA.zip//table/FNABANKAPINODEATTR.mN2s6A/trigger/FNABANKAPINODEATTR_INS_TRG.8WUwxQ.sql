create trigger FNABANKAPINODEATTR_INS_TRG
    before insert
    on FNABANKAPINODEATTR
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT fnaBankAPINodeAttr_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

