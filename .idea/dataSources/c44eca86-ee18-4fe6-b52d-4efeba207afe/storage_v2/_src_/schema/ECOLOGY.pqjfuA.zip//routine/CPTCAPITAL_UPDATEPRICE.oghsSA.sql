create PROCEDURE CptCapital_UpdatePrice ( id_1 	        integer, price 	        number, capitalspec_1	varchar2, customerid_1	integer, location_1		varchar2, invoice_1		varchar2, StockInDate_1   char, flag    out     integer , msg     out     varchar2, thecursor IN OUT cursor_define.weavercursor) AS  begin UPDATE CptCapital SET  startprice=price, capitalspec=capitalspec_1, customerid=customerid_1, location=location_1, invoice=invoice_1, StockInDate=StockInDate_1 WHERE ( id	= id_1) ; end;


/

