create trigger LGCASSET_TRIGGER
    before insert
    on LGCASSET
    for each row
begin select LgcAsset_id.nextval into :new.id from dual; end;
/

