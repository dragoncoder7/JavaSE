create trigger HRMSALARYSHIFTPAY_TRIGGER
    before insert
    on HRMSALARYSHIFTPAY
    for each row
begin select HrmSalaryShiftPay_id.nextval into :new.id from dual; end;
/

