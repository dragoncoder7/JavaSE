create trigger CPTCODE1_TRIGGER
    before insert
    on CPTCODE1
    for each row
begin select cptcode1_ID.nextval into :new.id from dual; end;
/

