create PROCEDURE CRM_ContractProInfo_Select ( proId_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin open thecursor for SELECT * FROM CRM_ContractProInfo WHERE proId = proId_1; end;


/

