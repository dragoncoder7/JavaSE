create trigger SOCIAL_SR_RECEIVER_TRIGGER
    before insert
    on SOCIAL_SYSREMINDRECEIVER
    for each row
begin select social_sr_receiver_seq.nextval into:new.id from sys.dual; end;
/

