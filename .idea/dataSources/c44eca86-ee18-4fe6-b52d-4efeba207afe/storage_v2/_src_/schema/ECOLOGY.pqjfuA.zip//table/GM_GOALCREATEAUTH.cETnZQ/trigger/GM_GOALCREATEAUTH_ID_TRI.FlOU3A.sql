create trigger GM_GOALCREATEAUTH_ID_TRI
    before insert
    on GM_GOALCREATEAUTH
    for each row
begin select GM_GOALCREATEAUTH_SEQ.nextval into :new.id from dual; end;
/

