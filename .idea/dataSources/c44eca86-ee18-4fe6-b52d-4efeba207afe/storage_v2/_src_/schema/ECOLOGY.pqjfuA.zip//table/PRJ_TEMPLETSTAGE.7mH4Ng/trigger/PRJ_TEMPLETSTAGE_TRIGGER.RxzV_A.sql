create trigger PRJ_TEMPLETSTAGE_TRIGGER
    before insert
    on PRJ_TEMPLETSTAGE
    for each row
begin select prj_templetstage_id.nextval into :new.id from dual; end;
/

