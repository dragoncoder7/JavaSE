create PROCEDURE CRM_CustomerType_SelectByID (id_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT CRM_CustomerType.* , workflow_base.workflowname FROM CRM_CustomerType , workflow_base where CRM_CustomerType.workflowid = workflow_base.id(+) and (CRM_CustomerType.id = id_1); end;


/

