create trigger TR_INT_AUTHORIZEDETARIGHT
    before insert
    on INT_AUTHORIZEDETARIGHT
    for each row
begin select sq_int_authorizeDetaRight.nextval into :new.id from dual; end;
/

