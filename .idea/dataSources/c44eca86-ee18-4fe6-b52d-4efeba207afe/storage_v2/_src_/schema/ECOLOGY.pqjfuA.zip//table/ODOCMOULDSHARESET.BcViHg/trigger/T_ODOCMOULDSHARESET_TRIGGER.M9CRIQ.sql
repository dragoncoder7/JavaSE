create trigger T_ODOCMOULDSHARESET_TRIGGER
    before insert
    on ODOCMOULDSHARESET
    for each row
begin select t_OdocMouldShareSet_seq.nextval into:NEW.ID from dual; end;
/

