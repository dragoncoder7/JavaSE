create trigger T_RECEIVEDOCINFOOA_TRIGGER
    before insert
    on EXCHANGE_RECEIVE_DOC_INFO_OA
    for each row
    when (new.id is null)
begin select t_receiveDocInfooa_seq.nextval into:NEW.ID from dual; end;
/

