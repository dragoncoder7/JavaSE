create trigger MOBILEMODEUSERTOKEN_TRI
    before insert
    on MOBILEMODEUSERTOKEN
    for each row
begin select MobilemodeUserToken_seq.nextval into :new.id from dual; end;
/

