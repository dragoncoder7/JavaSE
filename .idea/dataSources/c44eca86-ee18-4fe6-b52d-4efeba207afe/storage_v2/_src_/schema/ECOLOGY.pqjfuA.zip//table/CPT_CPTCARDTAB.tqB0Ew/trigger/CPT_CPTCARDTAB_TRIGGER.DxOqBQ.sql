create trigger CPT_CPTCARDTAB_TRIGGER
    before insert
    on CPT_CPTCARDTAB
    for each row
begin select cpt_cptcardtab_ID.nextval into :new.id from dual; end;
/

