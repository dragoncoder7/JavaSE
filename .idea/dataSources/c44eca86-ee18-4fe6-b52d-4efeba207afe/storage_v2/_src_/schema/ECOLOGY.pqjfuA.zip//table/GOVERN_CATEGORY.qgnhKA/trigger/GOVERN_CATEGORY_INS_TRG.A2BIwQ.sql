create trigger GOVERN_CATEGORY_INS_TRG
    before insert
    on GOVERN_CATEGORY
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_category_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

