create trigger DEPARTMENTDEFINEFIELD_TRI
    before insert
    on DEPARTMENTDEFINEFIELD
    for each row
BEGIN SELECT departmentDefineField_id.NEXTVAL INTO :NEW.id FROM dual; END;
/

