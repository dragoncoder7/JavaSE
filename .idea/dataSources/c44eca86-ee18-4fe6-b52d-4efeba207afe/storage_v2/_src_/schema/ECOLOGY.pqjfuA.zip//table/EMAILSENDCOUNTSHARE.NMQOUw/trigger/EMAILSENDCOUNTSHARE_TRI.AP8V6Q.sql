create trigger EMAILSENDCOUNTSHARE_TRI
    before insert
    on EMAILSENDCOUNTSHARE
    for each row
begin select emailsendcountshare_seq.nextval INTO :new.id from sys.dual; end;
/

