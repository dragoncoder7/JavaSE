create trigger OFMUCROOMUSERS_TRI
    before insert
    on OFMUCROOMUSERS
    for each row
BEGIN SELECT ofMucRoomUsers_seq.nextval INTO :new.id  FROM dual; END;
/

