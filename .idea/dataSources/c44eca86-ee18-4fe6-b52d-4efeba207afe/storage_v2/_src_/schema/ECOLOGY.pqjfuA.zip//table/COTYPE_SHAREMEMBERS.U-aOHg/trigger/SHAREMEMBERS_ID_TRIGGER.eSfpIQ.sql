create trigger SHAREMEMBERS_ID_TRIGGER
    before insert
    on COTYPE_SHAREMEMBERS
    for each row
begin select sharemembers_Id.nextval into :new.id from dual; end;
/

