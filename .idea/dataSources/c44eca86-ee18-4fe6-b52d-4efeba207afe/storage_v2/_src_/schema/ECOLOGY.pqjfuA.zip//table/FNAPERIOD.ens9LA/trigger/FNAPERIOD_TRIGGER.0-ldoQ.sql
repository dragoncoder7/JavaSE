create trigger FNAPERIOD_TRIGGER
    before insert
    on FNAPERIOD
    for each row
begin select seq_fnaPeriod.nextval into :new.id from dual; end;
/

