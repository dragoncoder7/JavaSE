create PROCEDURE bill_workinfodetail_Insert ( infoid1		integer, type1		integer, workname1	varchar2, workdesc1	varchar2, forecastdate1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin insert into bill_weekinfodetail (infoid,type,workname,workdesc,forecastdate) values (infoid1,type1,workname1,workdesc1,forecastdate1); end;


/

