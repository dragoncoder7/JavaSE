create trigger MODEDATASHARE_19501_TRI
    before insert
    on MODEDATASHARE_19501
    for each row
begin   select modeDataShare_19501_id.nextval into :new.id from dual;   end;
/

