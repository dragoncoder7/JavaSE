create trigger WORKFLOW_DIMENSION_ID_TRI
    before insert
    on WORKFLOW_DIMENSION
    for each row
begin select workflow_dimension_id.nextval into :new.id from dual; end;
/

