create trigger MODEFORMFIELDENCRYPT_TRIGGER
    before insert
    on MODEFORMFIELDENCRYPT
    for each row
begin select ModeFormFieldEncrypt_id.nextval into :new.id from dual; end;
/

