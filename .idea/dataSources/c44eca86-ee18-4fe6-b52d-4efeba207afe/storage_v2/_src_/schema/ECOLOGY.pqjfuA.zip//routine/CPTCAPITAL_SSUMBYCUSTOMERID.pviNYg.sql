create PROCEDURE CptCapital_SSumByCustomerid (flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin open thecursor for select customerid AS resultid, COUNT(id) AS resultcount from CptCapital group by customerid order by  resultcount desc; end;


/

