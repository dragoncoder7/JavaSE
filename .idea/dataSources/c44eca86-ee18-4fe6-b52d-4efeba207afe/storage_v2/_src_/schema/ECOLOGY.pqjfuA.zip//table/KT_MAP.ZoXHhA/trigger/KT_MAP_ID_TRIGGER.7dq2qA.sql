create trigger KT_MAP_ID_TRIGGER
    before insert
    on KT_MAP
    for each row
begin select KT_Map_id.nextval into :new.id from dual; end;
/

