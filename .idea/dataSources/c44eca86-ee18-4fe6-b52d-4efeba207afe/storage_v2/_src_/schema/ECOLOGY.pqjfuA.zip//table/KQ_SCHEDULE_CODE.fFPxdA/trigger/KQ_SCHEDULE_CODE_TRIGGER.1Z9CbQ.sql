create trigger KQ_SCHEDULE_CODE_TRIGGER
    before insert
    on KQ_SCHEDULE_CODE
    for each row
begin select kq_schedule_code_id.nextval INTO :new.id from dual; end;
/

