create PROCEDURE CRM_ContractPayMethod_Update (id_1 	integer , factPrice_1  number  , factDate_1  char   , isFinish_1  integer  , isRemind_1  integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_ContractPayMethod SET factPrice = factPrice_1, factDate = factDate_1 , isFinish = isFinish_1 , isRemind = isRemind_1  where id = id_1; end;


/

