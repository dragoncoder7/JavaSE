create PROCEDURE CptDepreMethod2_DByDepreID (depreid_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin DELETE CptDepreMethod2  WHERE ( depreid	 = depreid_1); end;


/

