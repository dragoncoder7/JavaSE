create trigger WORKFLOW_DETAILPAGING_TRI
    before insert
    on WORKFLOW_DETAILPAGING
    for each row
begin select workflow_detailpaging_seq.nextval into :new.keyid from DUAL; END;
/

