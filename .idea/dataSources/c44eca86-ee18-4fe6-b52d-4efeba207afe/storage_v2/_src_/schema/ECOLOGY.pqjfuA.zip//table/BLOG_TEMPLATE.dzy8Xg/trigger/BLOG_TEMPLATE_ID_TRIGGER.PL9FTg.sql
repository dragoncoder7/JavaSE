create trigger BLOG_TEMPLATE_ID_TRIGGER
    before insert
    on BLOG_TEMPLATE
    for each row
begin select blog_template_id.nextval into :new.id from dual; end;
/

