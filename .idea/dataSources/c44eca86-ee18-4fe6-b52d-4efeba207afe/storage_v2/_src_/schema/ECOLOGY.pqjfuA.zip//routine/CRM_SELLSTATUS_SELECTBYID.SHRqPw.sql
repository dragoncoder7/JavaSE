create PROCEDURE CRM_SellStatus_SelectByID (id_1 integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for SELECT * FROM CRM_SellStatus WHERE ( id  = id_1)  ; end;


/

