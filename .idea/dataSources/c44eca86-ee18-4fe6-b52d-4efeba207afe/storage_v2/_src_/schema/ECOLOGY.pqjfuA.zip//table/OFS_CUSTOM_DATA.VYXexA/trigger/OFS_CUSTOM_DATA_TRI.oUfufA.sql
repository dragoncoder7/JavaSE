create trigger OFS_CUSTOM_DATA_TRI
    before insert
    on OFS_CUSTOM_DATA
    for each row
begin select ofs_custom_data_id.nextval into :new.id from dual; end;
/

