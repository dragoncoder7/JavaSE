create trigger FNATENPAYSUPPORTBANK_INS_TRG
    before insert
    on FNATENPAYSUPPORTBANK
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT fnaTenPaySupportBank_id_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

