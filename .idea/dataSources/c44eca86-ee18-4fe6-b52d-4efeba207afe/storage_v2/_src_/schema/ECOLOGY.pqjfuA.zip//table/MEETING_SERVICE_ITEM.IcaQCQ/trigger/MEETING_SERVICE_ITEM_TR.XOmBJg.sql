create trigger MEETING_SERVICE_ITEM_TR
    before insert
    on MEETING_SERVICE_ITEM
    for each row
begin select Meeting_Service_Item_ID.nextval into :new.id from dual; end;
/

