create trigger SOCIAL_IMMSGCOUNT_ID_TRI
    before insert
    on SOCIAL_IMMSGCOUNT
    for each row
begin select social_IMMsgCount_id.nextval into :new.id from dual; end;
/

