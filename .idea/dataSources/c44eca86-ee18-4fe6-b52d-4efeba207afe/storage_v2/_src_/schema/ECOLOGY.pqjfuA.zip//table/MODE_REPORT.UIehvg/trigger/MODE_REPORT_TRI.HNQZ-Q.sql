create trigger MODE_REPORT_TRI
    before insert
    on MODE_REPORT
    for each row
begin select mode_report_id.nextval into :new.id from dual; end;
/

