create PROCEDURE bill_HotelBookDetail_SByBooki ( bookid1		integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for  select * from bill_HotelBookDetail where bookid=bookid1; end;


/

