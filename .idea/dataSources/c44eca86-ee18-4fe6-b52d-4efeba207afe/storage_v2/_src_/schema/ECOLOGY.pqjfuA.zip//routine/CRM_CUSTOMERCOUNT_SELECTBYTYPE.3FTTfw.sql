create PROCEDURE CRM_CustomerCount_SelectByType (city_1 integer, type_1 integer,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT count(id) as countid FROM CRM_CustomerInfo where city=city_1 and type=type_1; end;


/

