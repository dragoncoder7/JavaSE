create trigger T_ODOC_MODELSHARED_TRIGGER
    before insert
    on ODOC_MODELSHARED
    for each row
begin select t_odoc_modelshared_seq.nextval into:NEW.ID from dual; end;
/

