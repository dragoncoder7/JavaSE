create trigger SMS_TEMPLATE_TRI
    before insert
    on SMS_TEMPLATE
    for each row
begin select Sms_Template_id.nextval into :new.id from dual; end;
/

