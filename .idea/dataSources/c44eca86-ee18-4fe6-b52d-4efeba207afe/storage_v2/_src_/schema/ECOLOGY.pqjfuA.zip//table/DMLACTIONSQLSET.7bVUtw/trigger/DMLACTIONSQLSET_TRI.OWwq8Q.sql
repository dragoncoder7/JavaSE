create trigger DMLACTIONSQLSET_TRI
    before insert
    on DMLACTIONSQLSET
    for each row
begin select dmlactionsqlset_seq.nextval into :new.id from dual; end;
/

