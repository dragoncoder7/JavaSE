create trigger TR_SAP_INPARAMETER
    before insert
    on SAP_INPARAMETER
    for each row
begin select sq_sap_inParameter.nextval into :new.id from dual; end;
/

