create trigger WORKFLOW_CUSTOMDSP_TRIGGER
    before insert
    on WORKFLOW_CUSTOMDSPFIELD
    for each row
begin select Workflow_CustomDspField_seq.nextval into :new.id from dual; end;
/

