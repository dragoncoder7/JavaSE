create trigger ODOC_ODOCTYPE_TRIGGER
    before insert
    on ODOC_ODOCTYPE
    for each row
begin select seq_odoc_odoctype_ID.nextval into :new.id from dual;end;
/

