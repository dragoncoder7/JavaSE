create trigger LGCSTOCKMODE_TRIGGER
    before insert
    on LGCSTOCKMODE
    for each row
begin select LgcStockMode_id.nextval into :new.id from dual; end ;
/

