create trigger FNAINDICATORDETAIL_TRIGGER
    before insert
    on FNAINDICATORDETAIL
    for each row
begin select FnaIndicatordetail_id.nextval into :new.id from dual; end;
/

