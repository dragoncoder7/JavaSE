create trigger KQ_PROC_FIELDS_TRIGGER
    before insert
    on KQ_ATT_PROC_FIELDS
    for each row
begin select kq_ATT_PROC_FIELDS_id.nextval into :new.id from dual; end;
/

