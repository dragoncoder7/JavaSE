create trigger HRM_RP_SUB_TEP_CON_TRIGGER
    before insert
    on HRM_RP_SUB_TEMPLATE_CON
    for each row
begin select hrm_rp_sub_tmp_con_id.nextval into :new.id from dual; end;
/

