create trigger CARINFO_TRIGGER
    before insert
    on CARINFO
    for each row
begin select CarInfo_id.nextval into :new.id from dual; end ;
/

