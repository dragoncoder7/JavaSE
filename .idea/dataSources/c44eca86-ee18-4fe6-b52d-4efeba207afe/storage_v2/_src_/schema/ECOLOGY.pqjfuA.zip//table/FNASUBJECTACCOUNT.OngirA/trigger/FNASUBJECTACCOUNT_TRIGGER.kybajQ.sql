create trigger FNASUBJECTACCOUNT_TRIGGER
    before insert
    on FNASUBJECTACCOUNT
    for each row
begin select seq_fnaSubjectAccount.nextval into :new.id from dual; end;
/

