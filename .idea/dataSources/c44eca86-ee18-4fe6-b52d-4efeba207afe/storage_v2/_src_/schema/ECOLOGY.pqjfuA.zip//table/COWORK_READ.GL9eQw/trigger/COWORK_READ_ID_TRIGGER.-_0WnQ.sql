create trigger COWORK_READ_ID_TRIGGER
    before insert
    on COWORK_READ
    for each row
begin select cowork_read_id.nextval into:New.id from dual; end;
/

