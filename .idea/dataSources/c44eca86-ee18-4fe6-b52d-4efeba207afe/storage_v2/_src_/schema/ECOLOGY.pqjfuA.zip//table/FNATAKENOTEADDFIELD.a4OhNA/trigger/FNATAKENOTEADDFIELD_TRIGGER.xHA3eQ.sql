create trigger FNATAKENOTEADDFIELD_TRIGGER
    before insert
    on FNATAKENOTEADDFIELD
    for each row
begin select seq_fnaTakeNoteAddField.nextval into :new.id from dual; end;
/

