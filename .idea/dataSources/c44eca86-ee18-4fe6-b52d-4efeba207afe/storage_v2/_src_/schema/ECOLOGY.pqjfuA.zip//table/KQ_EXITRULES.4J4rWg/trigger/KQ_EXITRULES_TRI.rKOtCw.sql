create trigger KQ_EXITRULES_TRI
    before insert
    on KQ_EXITRULES
    for each row
begin select kq_ExitRules_id.nextval INTO :new.id from dual; end;
/

