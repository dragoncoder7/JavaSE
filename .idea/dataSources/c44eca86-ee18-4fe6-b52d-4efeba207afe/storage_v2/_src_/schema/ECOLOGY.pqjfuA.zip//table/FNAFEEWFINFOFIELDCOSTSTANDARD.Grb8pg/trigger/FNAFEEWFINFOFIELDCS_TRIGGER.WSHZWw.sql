create trigger FNAFEEWFINFOFIELDCS_TRIGGER
    before insert
    on FNAFEEWFINFOFIELDCOSTSTANDARD
    for each row
begin select seq_fnaFeeWfInfoFieldCs_id.nextval into :new.id from dual; end;
/

