create trigger WF_NODEHTMLLAYOUT_ID_TRI
    before insert
    on WORKFLOW_NODEHTMLLAYOUT
    for each row
begin select wf_nodehtmllayout_id.nextval into :new.id from dual; end;
/

