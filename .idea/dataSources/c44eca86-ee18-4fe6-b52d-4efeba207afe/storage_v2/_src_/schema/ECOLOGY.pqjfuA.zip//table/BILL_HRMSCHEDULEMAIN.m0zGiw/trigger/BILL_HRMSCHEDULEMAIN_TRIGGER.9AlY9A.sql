create trigger BILL_HRMSCHEDULEMAIN_TRIGGER
    before insert
    on BILL_HRMSCHEDULEMAIN
    for each row
begin select Bill_HrmScheduleMain_id.nextval into :new.id from dual; end;
/

