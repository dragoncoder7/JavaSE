create function convToCN(multilang in varchar2) return varchar2 is rst        varchar2(4000); v_index    int; v_endindex int; begin return convToMultiLang(multilang,7); end;


/

