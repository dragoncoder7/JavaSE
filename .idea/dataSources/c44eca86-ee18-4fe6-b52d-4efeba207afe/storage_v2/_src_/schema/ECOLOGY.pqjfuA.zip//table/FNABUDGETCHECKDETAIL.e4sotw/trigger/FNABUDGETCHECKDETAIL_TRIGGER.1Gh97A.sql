create trigger FNABUDGETCHECKDETAIL_TRIGGER
    before insert
    on FNABUDGETCHECKDETAIL
    for each row
begin select FnaBudgetCheckDetail_id.nextval into :new.id from dual; end;
/

