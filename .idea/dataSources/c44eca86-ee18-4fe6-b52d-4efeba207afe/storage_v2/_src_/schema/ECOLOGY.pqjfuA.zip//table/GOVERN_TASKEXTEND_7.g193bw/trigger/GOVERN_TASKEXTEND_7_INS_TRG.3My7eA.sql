create trigger GOVERN_TASKEXTEND_7_INS_TRG
    before insert
    on GOVERN_TASKEXTEND_7
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_taskextend_7_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

