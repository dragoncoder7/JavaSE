create PROCEDURE CRM_CustomerInfo_PortalPasswor (id_1 integer, portalloginid_1 varchar2, portalpassword_1 varchar2,flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerInfo  SET portalloginid = portalloginid_1 , portalpassword = portalpassword_1  WHERE ( id = id_1); end;


/

