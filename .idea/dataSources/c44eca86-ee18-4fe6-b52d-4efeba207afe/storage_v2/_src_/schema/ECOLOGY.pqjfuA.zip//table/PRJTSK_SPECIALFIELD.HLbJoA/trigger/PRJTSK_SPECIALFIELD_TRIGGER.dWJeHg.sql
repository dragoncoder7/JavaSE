create trigger PRJTSK_SPECIALFIELD_TRIGGER
    before insert
    on PRJTSK_SPECIALFIELD
    for each row
begin select prjtsk_specialfield_ID.nextval into :new.id from dual; end;
/

