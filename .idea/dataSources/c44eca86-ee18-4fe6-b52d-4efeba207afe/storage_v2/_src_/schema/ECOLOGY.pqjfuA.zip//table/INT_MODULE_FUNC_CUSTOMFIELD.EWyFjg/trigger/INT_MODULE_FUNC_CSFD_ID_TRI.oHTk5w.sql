create trigger INT_MODULE_FUNC_CSFD_ID_TRI
    before insert
    on INT_MODULE_FUNC_CUSTOMFIELD
    for each row
begin select Int_Module_Func_CustomField_id.nextval into :new.id from dual; end ;
/

