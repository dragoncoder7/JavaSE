create trigger WR_INDIVIDUALINFO_TAG_TRI
    before insert
    on WR_INDIVIDUALINFO_TAG
    for each row
begin select WR_IndividualInfo_Tag_SEQ.nextval into :new.id from dual; end;
/

