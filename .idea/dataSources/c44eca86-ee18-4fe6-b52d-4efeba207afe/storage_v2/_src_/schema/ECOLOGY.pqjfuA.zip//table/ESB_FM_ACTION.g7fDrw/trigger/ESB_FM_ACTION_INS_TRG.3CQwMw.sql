create trigger ESB_FM_ACTION_INS_TRG
    before insert
    on ESB_FM_ACTION
    for each row
    when (NEW.id IS NULL)
BEGIN SELECT esb_fm_action_id_SEQ.NEXTVAL INTO :NEW.id FROM DUAL; END;
/

