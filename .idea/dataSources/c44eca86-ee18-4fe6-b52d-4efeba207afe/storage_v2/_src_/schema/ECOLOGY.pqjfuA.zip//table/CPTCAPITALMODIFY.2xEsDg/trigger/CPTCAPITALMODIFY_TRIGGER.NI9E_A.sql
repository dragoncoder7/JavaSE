create trigger CPTCAPITALMODIFY_TRIGGER
    before insert
    on CPTCAPITALMODIFY
    for each row
begin select CptCapitalModify_id.nextval into :new.id from dual; end;
/

