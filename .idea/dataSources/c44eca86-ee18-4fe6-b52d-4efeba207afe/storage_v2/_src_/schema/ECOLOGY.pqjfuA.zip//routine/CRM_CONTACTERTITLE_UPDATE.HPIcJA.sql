create PROCEDURE CRM_ContacterTitle_Update (id_1 	integer, fullname_1 	varchar2, description_1 	varchar2, usetype_1 	char, language_1 	integer, abbrev_1 	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_ContacterTitle SET  fullname	 = fullname_1, description	 = description_1, usetype	 = usetype_1, language	 = language_1, abbrev	 = abbrev_1 WHERE ( id	 = id_1) ; end;


/

