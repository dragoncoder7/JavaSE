create trigger SMSTEMPLATEMAPPING_TRI
    before insert
    on SMSTEMPLATEMAPPING
    for each row
begin select smsTemplateMapping_seq.nextval into :new.id from dual; end;
/

