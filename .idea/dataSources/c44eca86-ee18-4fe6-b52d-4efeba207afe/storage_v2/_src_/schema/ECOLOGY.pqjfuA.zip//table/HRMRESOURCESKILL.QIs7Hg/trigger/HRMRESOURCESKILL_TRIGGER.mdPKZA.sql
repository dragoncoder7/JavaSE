create trigger HRMRESOURCESKILL_TRIGGER
    before insert
    on HRMRESOURCESKILL
    for each row
begin select HrmResourceSkill_id.nextval into :new.id from dual; end;
/

