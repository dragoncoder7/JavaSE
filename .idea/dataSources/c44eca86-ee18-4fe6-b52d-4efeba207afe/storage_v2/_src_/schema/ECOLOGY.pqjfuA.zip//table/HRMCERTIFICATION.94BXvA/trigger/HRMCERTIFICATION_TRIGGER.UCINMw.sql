create trigger HRMCERTIFICATION_TRIGGER
    before insert
    on HRMCERTIFICATION
    for each row
begin select HrmCertification_id.nextval into :new.id from dual; end;
/

