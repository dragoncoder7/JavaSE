create PROCEDURE CRM_ContractPayMethod_Update1 ( id_1 	integer , prjName_1  varchar2   , typeId_1  integer  , feetypeid_1 integer  , payPrice_1  number  , payDate_1  char    , qualification_1 varchar2 , isRemind_1  integer  , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin UPDATE CRM_ContractPayMethod SET prjName = prjName_1 , typeId = typeId_1, feetypeid = feetypeid_1, payPrice = payPrice_1, payDate = payDate_1, qualification = qualification_1 , isRemind = isRemind_1 where id = id_1 ; end;


/

