create PROCEDURE ContractShareDetail_Insert ( contractid_1 	integer, userid_2 	integer, usertype_3 	integer, sharelevel_4 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO ContractShareDetail (contractid, userid, usertype, sharelevel) VALUES(contractid_1, userid_2, usertype_3, sharelevel_4); end;


/

