create trigger MEETINGROOM_TYPE_TRIGGER
    before insert
    on MEETINGROOM_TYPE
    for each row
begin select MEETINGROOM_TYPE_ID.nextval into :new.id from dual; end ;
/

