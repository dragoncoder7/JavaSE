create package cux_create_doc_pkg3 is

  -- Author  : CEDAR
  -- Created : 2024/6/25 14:01:40
  -- Purpose : 用于后台创建单据

  g_request_id number;

  procedure get_begin_nodeid(p_workflow_id number,
                             x_node_id     out number,
                             x_node_type   out varchar2,
                             x_code        out varchar2,
                             x_msg         out varchar2);

  procedure get_nextnodeid(p_request_id     number,
                           p_workflow_id    number,
                           x_currentnode_id in out number,
                           x_nextnode_type  out varchar2,
                           x_nodelink_name  out varchar2,
                           x_code           out varchar2,
                           x_msg            out varchar2);

  function get_request_id return number;

  procedure main(p_request_id       number,
                 p_request_name     varchar2,
                 p_workflow_name    varchar2,
                 p_current_nodename varchar2,
                 p_create_user      varchar2,
                 p_create_date      date,
                 x_code             out varchar2,
                 x_msg              out varchar2);

  procedure get_approve_user(p_node_id     number,
                             x_user_ids    out varchar2,
                             x_groupdt_ids out varchar2,
                             x_usernames   out varchar2,
                             x_signtypes   out varchar2,
                             x_user_num    out number,
                             x_code        out varchar2,
                             x_msg         out varchar2);

  procedure test1(p_nodename varchar2);

end cux_create_doc_pkg3;
/

