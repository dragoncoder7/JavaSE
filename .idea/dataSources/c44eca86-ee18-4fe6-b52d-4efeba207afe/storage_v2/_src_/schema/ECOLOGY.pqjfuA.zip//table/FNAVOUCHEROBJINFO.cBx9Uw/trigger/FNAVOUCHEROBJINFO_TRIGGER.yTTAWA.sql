create trigger FNAVOUCHEROBJINFO_TRIGGER
    before insert
    on FNAVOUCHEROBJINFO
    for each row
begin select seq_fnaVoucherObjInfo.nextval into :new.id from dual; end;
/

