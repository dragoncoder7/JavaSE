create PROCEDURE CptCheckStockList_Insert (checkstockid_1 	integer, capitalid_2 	integer, theorynumber_3 	integer, realnumber_4 	integer, price_5 	decimal, remark_6 	varchar2, capitalimageid_2     integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  as begin insert into CptCheckStockList ( checkstockid, capitalid, theorynumber, realnumber, price, remark)  VALUES ( checkstockid_1, capitalid_2, theorynumber_3, realnumber_4, price_5, remark_6); end;


/

