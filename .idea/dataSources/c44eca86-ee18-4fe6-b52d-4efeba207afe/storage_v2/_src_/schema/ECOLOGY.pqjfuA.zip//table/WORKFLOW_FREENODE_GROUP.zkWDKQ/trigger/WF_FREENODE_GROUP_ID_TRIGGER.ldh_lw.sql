create trigger WF_FREENODE_GROUP_ID_TRIGGER
    before insert
    on WORKFLOW_FREENODE_GROUP
    for each row
BEGIN SELECT wf_freenode_group_Id.nextval INTO :new.id FROM dual; END;
/

