create trigger EDC_PATH_INS_TRG
    before insert
    on EDC_PATH
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_path_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

