create trigger CPTCHECKSTOCKLIST_TRIGGER
    before insert
    on CPTCHECKSTOCKLIST
    for each row
begin select CptCheckStockList_id.nextval into :new.id from dual; end;
/

