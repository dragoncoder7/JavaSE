create trigger FORMTABLE_MAIN_39_ID_TR
    before insert
    on FORMTABLE_MAIN_39
    for each row
begin select formtable_main_39_Id.nextval into :new.id from dual;  end;
/

