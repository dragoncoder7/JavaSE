create trigger MODEDATASHARE_20001_SET_TRI
    before insert
    on MODEDATASHARE_20001_SET
    for each row
begin   select modeDataShare_20001_set_id.nextval into :new.id from dual;   end;
/

