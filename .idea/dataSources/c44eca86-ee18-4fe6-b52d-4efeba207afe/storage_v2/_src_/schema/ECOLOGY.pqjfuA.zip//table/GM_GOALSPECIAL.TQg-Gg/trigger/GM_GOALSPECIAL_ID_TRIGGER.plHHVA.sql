create trigger GM_GOALSPECIAL_ID_TRIGGER
    before insert
    on GM_GOALSPECIAL
    for each row
begin select GM_GoalSpecial_id.nextval into :new.id from dual; end;
/

