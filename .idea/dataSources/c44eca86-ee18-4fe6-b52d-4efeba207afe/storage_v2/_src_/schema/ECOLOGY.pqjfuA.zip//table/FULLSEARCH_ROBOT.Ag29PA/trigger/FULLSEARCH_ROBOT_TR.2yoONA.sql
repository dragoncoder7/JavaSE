create trigger FULLSEARCH_ROBOT_TR
    before insert
    on FULLSEARCH_ROBOT
    for each row
begin select FullSearch_Robot_ID.nextval into :new.id from dual; end;
/

