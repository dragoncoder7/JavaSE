create trigger HPELEMENTS_COL_USE_T_TRIGGER
    before insert
    on HPELEMENTS_ORDER_COL_USE_T
    for each row
begin select hpelements_col_use_t_seq.nextval into :new.id from dual; end;
/

