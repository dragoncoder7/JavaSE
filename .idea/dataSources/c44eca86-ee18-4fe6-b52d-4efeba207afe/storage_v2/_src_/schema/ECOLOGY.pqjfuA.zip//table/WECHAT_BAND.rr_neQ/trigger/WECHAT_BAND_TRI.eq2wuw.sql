create trigger WECHAT_BAND_TRI
    before insert
    on WECHAT_BAND
    for each row
begin select wechat_band_id.nextval into :new.id from dual; end;
/

