create PROCEDURE CarDriverBasicinfo_Select (   flag out integer , msg out varchar2, thecursor in out cursor_define.weavercursor) AS begin open thecursor for select * from cardriverbasicinfo; end;


/

