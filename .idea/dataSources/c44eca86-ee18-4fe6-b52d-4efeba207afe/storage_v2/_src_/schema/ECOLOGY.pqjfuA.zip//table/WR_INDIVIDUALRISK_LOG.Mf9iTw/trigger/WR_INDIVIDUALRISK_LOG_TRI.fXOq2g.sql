create trigger WR_INDIVIDUALRISK_LOG_TRI
    before insert
    on WR_INDIVIDUALRISK_LOG
    for each row
begin select WR_IndividualRisk_Log_SEQ.nextval into :new.id from dual; end;
/

