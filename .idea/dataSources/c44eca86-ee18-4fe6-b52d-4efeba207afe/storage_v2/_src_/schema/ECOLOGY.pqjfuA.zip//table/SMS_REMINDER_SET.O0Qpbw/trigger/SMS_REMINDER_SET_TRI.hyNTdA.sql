create trigger SMS_REMINDER_SET_TRI
    before insert
    on SMS_REMINDER_SET
    for each row
begin select sms_reminder_set_id.nextval into :new.id from dual; end;
/

