create trigger FNAFEEWFINFONODECTRL_TRIGGER
    before insert
    on FNAFEEWFINFONODECTRL
    for each row
begin select seq_fnaFeeWfInfoNodeCtrl_ID.nextval into :new.id from dual; end;
/

