create trigger ODOC_REQUEST_ASSIGNREMARK_TRI
    before insert
    on ODOC_REQUEST_ASSIGNREMARK
    for each row
begin select odoc_request_assignremark_id.nextval into :new.id from dual; end;
/

