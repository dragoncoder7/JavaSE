create trigger SYSTEMLOG_TRIGGER
    before insert
    on SYSTEMLOG
    for each row
begin select SystemLog_id.nextval into :new.id from dual; end;
/

