create trigger MOBILEMODEUSERMECCONFIG_TRI
    before insert
    on MOBILEMODEUSERMECCONFIG
    for each row
begin select MobilemodeUserMecConfig_seq.nextval into :new.id from dual; end;
/

