create PROCEDURE bill_Approve_UpdateStatus ( id1		integer, status1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update Bill_Approve set status=status1 where id=id1; end;


/

