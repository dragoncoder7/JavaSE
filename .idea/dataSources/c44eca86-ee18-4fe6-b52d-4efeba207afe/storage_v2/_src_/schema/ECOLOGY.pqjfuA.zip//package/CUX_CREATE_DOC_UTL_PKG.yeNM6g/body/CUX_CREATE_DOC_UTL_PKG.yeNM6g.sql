create package body cux_create_doc_utl_pkg is

  procedure get_begin_nodeid(p_workflow_id number,
                             x_node_id     out number,
                             x_node_type   out varchar2,
                             x_code        out varchar2,
                             x_msg         out varchar2) is
  
  begin
    select a.nodeid, a.nodetype --0：创建 1：审批 2：提交 3：归档
      into x_node_id, x_node_type
      from workflow_flownode a --工作流节点表
     where 1 = 1
       and a.nodetype = 0 --0：创建 1：审批 2：提交 3：归档
       and a.workflowid = p_workflow_id;
  
    /*select a.nodeid, a.nodetype --0：创建 1：审批 2：提交 3：归档
     into x_node_id, x_node_type
     from workflow_flownode a, --工作流节点表
          workflow_nodebase b --节点基础信息表
    where a.nodeid = b.id
      and b.isstart = 1 --开始结点: 数据上有时nodetype=0 ,但isstart =0 , 不过数据不多.
      and a.workflowid = p_workflow_id;*/
  
  exception
    when others then
      x_code := 'E';
      x_msg  := '获取工作流开始节点出错' || substr(sqlerrm, 1, 1000);
  end;

  /*
  获得工作流指定节点的下一个节点信息
  */
  procedure get_nextnodeid(p_workflow_id    number,
                           p_request_id     number, --预留做以后条件出口的处理
                           p_currentnode_id in number,
                           x_nextnode_id    out number,
                           x_nextnode_type  out varchar2,
                           x_nodelink_name  out varchar2,
                           x_code           out varchar2,
                           x_msg            out varchar2) is
  
    cursor c is
      select a.id,
             a.linkname, --出口名称
             a.destnodeid,--下一节点id
             b.nodetype nextnode_type
        from workflow_nodelink a, --节点出口表
             workflow_flownode b --工作流节点信息表
       where 1 = 1
         and a.destnodeid = b.nodeid
         and a.workflowid = b.workflowid
            
         and a.workflowid = p_workflow_id
         and a.nodeid = p_currentnode_id;
  
    l_temp     varchar2(200);
    l_rowcount number := 0;
  
  begin
    for r in c loop
    
      --有出口条件的，以后再处理
      begin
        select a.id
          into l_temp
          from rule_maplist a --出口条件规则表,有值表示有条件限定
         where a.linkid = r.id --出口条件ID
           and rownum = 1;
      
        x_code := 'E';
        x_msg  := '此节点的出口有设定条件，本程序未考虑，待IT拓展';
        return;
      exception
        when others then
          null;
      end;
    
      x_nextnode_id   := r.destnodeid;
      x_nodelink_name := r.linkname; --出口名称
      x_nextnode_type := r.nextnode_type;
    
      l_rowcount := l_rowcount + 1;
    
    end loop;
  
    --有多个出口,先不处理 ,待出口条件处理后注释此段
    if l_rowcount > 1 then
      x_code := 'E';
      x_msg  := '此节点有多个出口';
      return;
    
    end if;
  
    if l_rowcount = 0 then
      x_code := 'F';
      x_msg  := '没有找到下一个节点';
      return;
    
    end if;
  
    x_code := 'S';
  end;
end cux_create_doc_utl_pkg;
/

