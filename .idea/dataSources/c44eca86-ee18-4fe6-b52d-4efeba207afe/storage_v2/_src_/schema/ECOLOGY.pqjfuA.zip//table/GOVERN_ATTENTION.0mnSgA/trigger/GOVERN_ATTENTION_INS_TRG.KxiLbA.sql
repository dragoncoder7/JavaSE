create trigger GOVERN_ATTENTION_INS_TRG
    before insert
    on GOVERN_ATTENTION
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_attention_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

