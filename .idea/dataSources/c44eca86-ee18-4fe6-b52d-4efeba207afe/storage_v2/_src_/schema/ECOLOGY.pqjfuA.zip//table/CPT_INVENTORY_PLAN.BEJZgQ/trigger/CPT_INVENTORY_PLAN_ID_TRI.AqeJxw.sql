create trigger CPT_INVENTORY_PLAN_ID_TRI
    before insert
    on CPT_INVENTORY_PLAN
    for each row
begin select cpt_inventory_plan_id.nextval into :new.id from dual; end;
/

