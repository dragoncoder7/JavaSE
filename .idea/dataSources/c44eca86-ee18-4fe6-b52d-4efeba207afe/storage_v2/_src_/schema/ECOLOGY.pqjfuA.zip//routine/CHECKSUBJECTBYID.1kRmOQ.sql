create FUNCTION checkSubjectById(pSupId    IN INTEGER, pBottomId IN INTEGER) RETURN VARCHAR2 IS pCnt INTEGER; BEGIN select count(*) into pCnt from FnaBudgetfeeType where id = pBottomId start with id = pSupId connect by prior id = supsubject; RETURN(pCnt); END;


/

