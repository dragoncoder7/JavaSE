create PROCEDURE cowork_types_insert (typename_1 	varchar2, departmentid_2 	integer, managerid_3 	varchar2, members_4 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO cowork_types (typename, departmentid, managerid, members) VALUES (typename_1, departmentid_2, managerid_3, members_4); end;


/

