create trigger FNAINVOICEENTERWAY_TRIGGER
    before insert
    on FNAINVOICEENTERWAY
    for each row
begin select seq_fnaInvoiceEnterWay.nextval into :new.id from dual; end;
/

