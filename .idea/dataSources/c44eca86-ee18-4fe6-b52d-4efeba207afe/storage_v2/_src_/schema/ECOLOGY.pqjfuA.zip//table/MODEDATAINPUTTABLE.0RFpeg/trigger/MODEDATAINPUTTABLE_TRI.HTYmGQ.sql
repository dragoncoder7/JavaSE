create trigger MODEDATAINPUTTABLE_TRI
    before insert
    on MODEDATAINPUTTABLE
    for each row
begin select modeDataInputtable_id.nextval into :new.id from dual; end;
/

