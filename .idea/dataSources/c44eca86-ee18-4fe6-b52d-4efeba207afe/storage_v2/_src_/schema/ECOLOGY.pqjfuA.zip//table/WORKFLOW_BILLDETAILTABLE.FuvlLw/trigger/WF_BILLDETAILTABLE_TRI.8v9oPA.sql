create trigger WF_BILLDETAILTABLE_TRI
    before insert
    on WORKFLOW_BILLDETAILTABLE
    for each row
begin select Workflow_billdetailtable_id.nextval into :new.id from dual; end;
/

