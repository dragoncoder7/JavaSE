create trigger WR_TEAMITEM_DETAIL_ID_TRI
    before insert
    on WR_TEAMITEM_DETAIL
    for each row
begin select WR_TeamItem_Detail_SEQ.nextval into :new.id from dual; end;
/

