create trigger T_FIELDITEM_TRIGGER
    before insert
    on T_FIELDITEM
    for each row
begin select T_fieldItem_itemid.nextval into :new.itemid from dual; end;
/

