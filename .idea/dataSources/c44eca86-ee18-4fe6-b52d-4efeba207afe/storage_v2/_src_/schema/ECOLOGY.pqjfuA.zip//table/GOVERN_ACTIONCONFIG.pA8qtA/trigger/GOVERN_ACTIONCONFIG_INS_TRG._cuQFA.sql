create trigger GOVERN_ACTIONCONFIG_INS_TRG
    before insert
    on GOVERN_ACTIONCONFIG
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_actionConfig_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

