create trigger PRJ_PROJECTINFO_TRIGGER
    before insert
    on PRJ_PROJECTINFO
    for each row
begin select Prj_ProjectInfo_id.nextval into :new.id from dual; end;
/

