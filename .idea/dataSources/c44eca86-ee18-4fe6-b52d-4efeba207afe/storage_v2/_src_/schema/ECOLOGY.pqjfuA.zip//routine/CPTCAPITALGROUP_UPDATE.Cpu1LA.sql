create PROCEDURE CptCapitalGroup_Update (id_1 	integer, name_1 	varchar2, description_1 	varchar2, parentid_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CptCapitalGroup SET  name	 = name_1, description	 = description_1, parentid	 = parentid_1 WHERE ( id	 = id_1); end;


/

