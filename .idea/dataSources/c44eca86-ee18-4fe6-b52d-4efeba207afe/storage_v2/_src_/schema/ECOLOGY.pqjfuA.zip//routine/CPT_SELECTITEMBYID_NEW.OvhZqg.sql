create PROCEDURE cpt_selectitembyid_new ( id_1                 VARCHAR2, isbill_1             VARCHAR2, flag        OUT      INTEGER, msg         OUT      VARCHAR2, thecursor   IN OUT   cursor_define.weavercursor ) AS BEGIN OPEN thecursor FOR SELECT   * FROM cpt_SelectItem WHERE fieldid = id_1 AND isbill = isbill_1 AND (cancel!='1' or cancel is null) ORDER BY listorder, ID; END;


/

