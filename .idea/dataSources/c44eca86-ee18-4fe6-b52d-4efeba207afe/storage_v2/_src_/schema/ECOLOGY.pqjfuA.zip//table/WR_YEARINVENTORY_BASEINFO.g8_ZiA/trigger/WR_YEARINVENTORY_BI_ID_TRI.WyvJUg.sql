create trigger WR_YEARINVENTORY_BI_ID_TRI
    before insert
    on WR_YEARINVENTORY_BASEINFO
    for each row
begin select WR_YearInventory_BI_SEQ.nextval into :new.id from dual; end;
/

