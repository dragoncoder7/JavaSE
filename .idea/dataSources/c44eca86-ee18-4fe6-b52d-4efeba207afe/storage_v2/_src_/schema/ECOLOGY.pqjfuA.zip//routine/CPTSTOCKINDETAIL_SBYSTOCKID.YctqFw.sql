create PROCEDURE CptStockInDetail_SByStockid ( cptstockinid_1 integer , flag	out integer, msg   out	varchar2, thecursor IN OUT cursor_define.weavercursor )  AS  begin open thecursor for select * from CptStockInDetail where cptstockinid = cptstockinid_1 order by id; end;


/

