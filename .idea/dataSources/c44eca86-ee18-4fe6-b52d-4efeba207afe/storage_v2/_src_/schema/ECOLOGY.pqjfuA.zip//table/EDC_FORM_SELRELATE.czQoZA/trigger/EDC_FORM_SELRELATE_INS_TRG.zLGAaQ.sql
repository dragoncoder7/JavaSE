create trigger EDC_FORM_SELRELATE_INS_TRG
    before insert
    on EDC_FORM_SELRELATE
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_form_selrelate_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

