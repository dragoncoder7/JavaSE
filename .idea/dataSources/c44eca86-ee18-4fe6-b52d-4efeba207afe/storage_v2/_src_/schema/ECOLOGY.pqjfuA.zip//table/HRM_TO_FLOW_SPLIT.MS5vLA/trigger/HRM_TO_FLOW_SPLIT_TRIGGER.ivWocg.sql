create trigger HRM_TO_FLOW_SPLIT_TRIGGER
    before insert
    on HRM_TO_FLOW_SPLIT
    for each row
begin select hrm_to_flow_split_ID.nextval INTO :new.id from dual; end;
/

