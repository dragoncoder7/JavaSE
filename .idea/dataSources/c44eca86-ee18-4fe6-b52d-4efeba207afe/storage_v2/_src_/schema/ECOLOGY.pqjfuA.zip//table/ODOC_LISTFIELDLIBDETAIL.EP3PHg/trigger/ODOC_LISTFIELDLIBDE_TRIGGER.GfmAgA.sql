create trigger ODOC_LISTFIELDLIBDE_TRIGGER
    before insert
    on ODOC_LISTFIELDLIBDETAIL
    for each row
begin select odoc_listfieldlibde_seq.nextval into :new.libid from dual; end;
/

