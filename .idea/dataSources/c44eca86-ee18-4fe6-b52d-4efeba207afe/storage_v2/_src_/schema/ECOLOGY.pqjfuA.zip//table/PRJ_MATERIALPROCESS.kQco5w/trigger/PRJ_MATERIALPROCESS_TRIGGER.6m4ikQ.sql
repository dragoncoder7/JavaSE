create trigger PRJ_MATERIALPROCESS_TRIGGER
    before insert
    on PRJ_MATERIALPROCESS
    for each row
begin select Prj_MaterialProcess_id.nextval into :new.id from dual; end ;
/

