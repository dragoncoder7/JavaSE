create PROCEDURE CRM_LoginLog_Insert ( id_1	integer, logindate_1	char, logintime_1	char, ipaddress_1	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin insert into CRM_loginLog (id, logindate, logintime, ipaddress) values(id_1, logindate_1, logintime_1, ipaddress_1); end;


/

