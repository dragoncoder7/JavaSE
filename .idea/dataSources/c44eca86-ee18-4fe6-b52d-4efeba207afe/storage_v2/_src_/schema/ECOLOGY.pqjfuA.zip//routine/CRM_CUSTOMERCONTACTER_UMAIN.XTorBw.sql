create PROCEDURE CRM_CustomerContacter_UMain (id_1	 	integer, main_1	  smallint,flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerContacter  SET	 main	 = main_1  WHERE ( id	 = id_1) ; end;


/

