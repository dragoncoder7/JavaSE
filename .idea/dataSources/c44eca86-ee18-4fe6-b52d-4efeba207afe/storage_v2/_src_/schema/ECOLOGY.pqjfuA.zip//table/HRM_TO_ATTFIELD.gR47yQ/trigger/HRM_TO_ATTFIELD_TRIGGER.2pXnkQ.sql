create trigger HRM_TO_ATTFIELD_TRIGGER
    before insert
    on HRM_TO_ATTFIELD
    for each row
begin select hrm_to_attfield_ID.nextval INTO :new.id from dual; end;
/

