create trigger ECOLOGY_BIZ_WORKBENCH_ID
    before insert
    on ECOLOGY_BIZ_WORKBENCH
    for each row
begin select ECOLOGY_BIZ_WORKBENCH_ID_seq.nextval into :new.id from dual; end;
/

