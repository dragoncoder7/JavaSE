create trigger CRM_COMMONLANGUAGE_SQ_TG
    before insert
    on CRM_COMMONLANGUAGE
    for each row
BEGIN SELECT CRM_COMMONLANGUAGE_SQ.nextval INTO:NEW.ID FROM dual;END;
/

