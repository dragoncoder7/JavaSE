create trigger ODOCREPORTRIGHT_TRIGGER
    before insert
    on ODOCREPORTRIGHT
    for each row
begin select OdocReportRight_seq.nextval into:NEW.ID from dual; end;
/

