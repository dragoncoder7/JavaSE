create trigger WR_NDPDM_DOCD_TRG
    before insert
    on WR_YEARINVENTORY_DOC_D
    for each row
begin select WR_NDPDM_DOCD_SEQ.nextval into :new.id from DUAL; END;
/

