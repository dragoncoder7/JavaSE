create trigger HBHREMINDMSG_TRIGGER
    before insert
    on HRMBIRTHREMINDMSG
    for each row
begin select HrmBirthRemindMsg_id.nextval into :new.id from dual; end;
/

