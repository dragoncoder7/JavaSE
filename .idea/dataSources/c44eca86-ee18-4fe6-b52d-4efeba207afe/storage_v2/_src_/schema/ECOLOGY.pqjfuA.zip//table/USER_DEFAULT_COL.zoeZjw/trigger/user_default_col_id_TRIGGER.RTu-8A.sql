create trigger "user_default_col_id_TRIGGER"
    before insert
    on USER_DEFAULT_COL
    for each row
begin select user_default_col_id.nextval into :new.id from dual; end;
/

