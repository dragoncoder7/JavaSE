create trigger KQ_ATT_RULE_FIELDS_TRIGGER
    before insert
    on KQ_ATT_CHECKRULE_FIELDS
    for each row
begin select kq_att_checkrule_fields_ID.nextval INTO :new.id from dual; end;
/

