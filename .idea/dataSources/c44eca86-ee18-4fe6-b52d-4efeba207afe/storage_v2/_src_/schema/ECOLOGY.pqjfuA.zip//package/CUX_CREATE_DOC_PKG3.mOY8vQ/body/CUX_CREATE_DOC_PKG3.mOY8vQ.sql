create package body cux_create_doc_pkg3 is

  /*
  使用此包获得request_id, 先把数据写入数据表. 再指定此审批流的信息
  
  局限： 因为审批人的设定有多种方式，目前还没有更细的研究，只能先做单据创建和单据创建直接归档
  
  1. 获得requestid
  2. 写入表单表 （业务信息）
  3. 创建流程主表 （当前节点）
  4. 写入流程审批记录 （节点信息）
  5. 写入流程待办 （审批人）
  
  
  ---方案二
  1。 获取开始节点， 
  2。 如果当前节点和参数节点不一致，一直做循环。
  3。 通过当前节点获得下一节点
  4。 对当前节点写表 ： 已审信息， 审批意义， 更新请求信息
  5。 把下一节点给到当前节点。 继续循环
  
  
  */

  procedure get_begin_nodeid(p_workflow_id number,
                             x_node_id     out number,
                             x_node_type   out varchar2,
                             x_code        out varchar2,
                             x_msg         out varchar2) is
  
  begin
    select a.nodeid, a.nodetype
      into x_node_id, x_node_type
      from workflow_flownode a, workflow_nodebase b
     where a.nodeid = b.id
       and b.isstart = 1
       and a.workflowid = p_workflow_id;
  
  exception
    when others then
      x_code := 'E';
      x_msg  := '获取工作流开始节点出错' || substr(sqlerrm, 1, 1000);
  end;

  procedure get_nextnodeid(p_request_id     number,
                           p_workflow_id    number,
                           x_currentnode_id in out number,
                           x_nextnode_type  out varchar2,
                           x_nodelink_name  out varchar2,
                           x_code           out varchar2,
                           x_msg            out varchar2) is
  
    cursor c is
      select a.*, b.nodetype nextnode_type
        from workflow_nodelink a, workflow_flownode b
       where 1 = 1
         and a.destnodeid = b.nodeid
         and a.workflowid = b.workflowid
         and a.workflowid = p_workflow_id
         and a.nodeid = x_currentnode_id;
  
    l_temp     varchar2(200);
    l_rowcount number := 0;
  
  begin
    for r in c loop
      --有出口条件的，以后再处理
      begin
        select a.id
          into l_temp
          from rule_maplist a
         where a.linkid = r.id
           and rownum = 1;
      
        x_code := 'E';
        x_msg  := '此节点的出口有设定条件，本程序未考虑，待IT拓展';
        return;
      exception
        when others then
          null;
      end;
    
      x_currentnode_id := r.destnodeid;
      x_nodelink_name  := r.linkname;
      x_nextnode_type  := r.nextnode_type;
    
      l_rowcount := l_rowcount + 1;
    
    end loop;
  
    --有多个出口,先不处理 ,待出口条件处理后注释此段
    if l_rowcount > 1 then
      x_code := 'E';
      x_msg  := '此节点有多个出口';
      return;
    
    end if;
  
    if l_rowcount = 0 then
      x_code := 'F';
      x_msg  := '没有找到下一个节点';
      return;
    
    end if;
  
    x_code := 'S';
  end;

  /*
  获得当前节点要审批的人
  */
  procedure get_approve_user(p_node_id     number,
                             x_user_ids    out varchar2,
                             x_groupdt_ids out varchar2,
                             x_usernames   out varchar2,
                             x_signtypes   out varchar2,
                             x_user_num    out number,
                             x_code        out varchar2,
                             x_msg         out varchar2) is
  
    cursor c is
      select b.id, b.type, b.signorder
        from workflow_nodegroup a, workflow_groupdetail b
       where a.id = b.groupid
         and a.nodeid = p_node_id;
  
    cursor c1(p_id number) is
      select a.objid, a.groupdetailid, b.lastname
        from workflow_hrmoperator a, hrmresource b
       where a.groupdetailid = p_id
         and a.objid = b.id;
  
  begin
    x_user_num := 0;
    for r in c loop
      --不是直接指定的人,暂时未处理 
      if r.type not in (3, 17) then
        x_code := 'E';
        x_msg  := '此节点的审批人不是直接指定人员的,目前程序未处理 ,待拓展';
        return;
      end if;
    
      --指定人的
      for r1 in c1(r.id) loop
        x_user_num    := x_user_num + 1;
        x_user_ids    := x_user_ids || r1.objid || ',';
        x_groupdt_ids := x_groupdt_ids || r1.groupdetailid || ',';
        x_usernames   := x_usernames || r1.lastname || ',';
        x_signtypes   := x_signtypes || r.signorder || ',';
      end loop;
    
      --指定创建者本人
      if r.type = 17 then
        x_user_num    := x_user_num + 1;
        x_user_ids    := x_user_ids || -1 || ',';
        x_groupdt_ids := x_groupdt_ids || r.id || ',';
        x_usernames   := x_usernames || '创建者本人' || ',';
        x_signtypes   := x_signtypes || r.signorder || ',';
      end if;
    
    end loop;
  
    x_code := 'S';
  end;

  function get_request_id return number is
  
  begin
    return cux_requestid_s.nextval;
  end;

  procedure main(p_request_id       number,
                 p_request_name     varchar2,
                 p_workflow_name    varchar2,
                 p_current_nodename varchar2,
                 p_create_user      varchar2,
                 p_create_date      date,
                 x_code             out varchar2,
                 x_msg              out varchar2) is
  
    l_user_id         number;
    l_user_name       varchar2(20);
    l_signtypes       varchar2(200);
    l_next_signtypes       varchar2(200);
    l_signtype        varchar2(200);
    l_create_date     date := nvl(p_create_date, sysdate);
    l_workflow_id     number;
    l_workflow_type   number;
    l_bill_table_name varchar2(200);
    l_sql             varchar2(2000);
  
    rec_workflow_nodebase workflow_nodebase%rowtype;
  
    rec_workflow_requestbase     workflow_requestbase%rowtype;  --流程信息表 
    rec_workflow_currentoperator workflow_currentoperator%rowtype; --已办待办信息
    rec_workflow_requestlog      workflow_requestlog%rowtype; --审批意见 
  
    l_temp              varchar2(1000);
    l_beginnode_id      number;
    l_currentnode_id    number; --审批节点
    l_currentnode_type  varchar2(20); --审批节点类型
    l_nextnode_id       number;
    l_nextnode_type     varchar2(2);
    l_nodelink_name     varchar2(200); --出口名称
    l_user_ids          varchar2(2000); --要审批的人 ， 多个人以“，”隔开
    l_user_num          number; --要审批的人数
    l_loop_user         number;
    l_loop_userid       number;
    l_groupdt_ids       varchar2(200);
    l_groupdt_id        number;
    l_currentnode_users varchar2(2000);
  
    l_next_nodegroupdt_ids varchar2(200);
    l_next_groupdt_id      number;
    l_nextnode_users       varchar2(2000);
  
    l_next_nodeuser_ids varchar2(2000);
    l_nextnode_user_num number;
    l_do_date           date := p_create_date;
  
    cursor c is
      select wnl.nodeid,
             wnl.destnodeid,
             wnb.isend,
             cur_node.nodetype  cur_node_type,
             next_node.nodetype next_node_type,
             wnl.linkname
        from workflow_nodelink wnl,
             workflow_nodebase wnb,
             workflow_flownode cur_node,
             workflow_flownode next_node
       where wnl.nodeid = wnb.id
         and wnl.nodeid = cur_node.nodeid
         and wnl.workflowid = cur_node.workflowid
         and wnl.destnodeid = next_node.nodeid
         and wnl.workflowid = next_node.workflowid
         and wnl.workflowid = l_workflow_id;
  
    cursor c_nodegroup(p_nodeid number) is
      select b.type, cc.objid
        from workflow_nodegroup   a,
             workflow_groupdetail b,
             workflow_hrmoperator cc
       where a.id = b.groupid
         and b.id = cc.groupdetailid
         and a.nodeid = p_nodeid;
  begin
  
    --1. 获得workflowid ;
    begin
    
      select wb.id, wbi.tablename, wb.workflowtype
        into l_workflow_id, l_bill_table_name, l_workflow_type
        from workflow_base wb, workflow_bill wbi
       where wb.formid = wbi.id
            
         and wb.workflowname = p_workflow_name --'货物出门证(广东长盈)'
         and wb.isvalid = 1 --有效
         and (wb.activeversionid is null or exists
              (select 1
                 from workflow_versioninfo wv
                where 1 = 1
                  and wb.id = wv.wfid
                  and wb.activeversionid = wv.wfversionid --活动版本
               ));
    exception
      when others then
      
        x_code := 'E';
        x_msg  := '无法找到表单：' || p_workflow_name;
        return;
    end;
  
    --2. 判断业务表是否已写入了requestid 
    l_sql := 'select 1 from ' || l_bill_table_name ||
             ' where requestid =  ' || p_request_id;
    begin
      execute immediate l_sql
        into l_temp;
    exception
      when others then
        x_code := 'E';
        x_msg  := '未找到此请求的表单数据：' || l_sql;
        return;
    end;
  
    --3。确保此请求ID还没有被使用
    begin
      select 1
        into l_temp
        from workflow_requestbase a
       where a.requestid = p_request_id;
    
      x_code := 'E';
      x_msg  := '此请求ID已被使用：' || p_request_id;
      return;
    
    exception
      when others then
        null;
    end;
  
    --4。 确保节点存在 
    begin
      select wn.*
        into rec_workflow_nodebase
        from workflow_flownode wf, workflow_nodebase wn
       where wf.nodeid = wn.id
            
         and wf.workflowid = l_workflow_id
            -- and wn.nodename = p_current_nodename
         and (wn.nodename like '%`7 ' || p_current_nodename || '`%' or
             wn.nodename = p_current_nodename);
    exception
      when others then
        x_code := 'E';
        x_msg  := '节点不在此流程中：' || p_current_nodename;
        return;
    end;
  
    --获得用户id
    begin
      select a.id, a.lastname
        into l_user_id, l_user_name
        from hrmresource a
       where a.workcode = p_create_user
          or a.lastname = p_create_user;
    exception
      when others then
        x_code := 'E';
        x_msg  := '不存在用户：' || p_create_user;
        return;
    end;
  
    --获得起始节点
    get_begin_nodeid(l_workflow_id,
                     l_currentnode_id,
                     l_currentnode_type,
                     x_code,
                     x_msg);
    l_beginnode_id := l_currentnode_id;
  
    loop
      if l_beginnode_id != l_currentnode_id then
        get_approve_user(l_currentnode_id,
                         l_user_ids,
                         l_groupdt_ids,
                         l_currentnode_users,
                         l_signtypes,
                         l_user_num,
                         x_code,
                         x_msg);
        l_user_ids          := replace(l_user_ids, '-1', l_user_id);
        l_currentnode_users := replace(l_currentnode_users,
                                       '创建者本人',
                                       l_user_name);
      else
        l_user_ids := l_user_id || ',';
        l_user_num := 1;
      end if;
    
      l_nextnode_id := l_currentnode_id;
      --获得下一节点id 
      get_nextnodeid(p_request_id,
                     l_workflow_id,
                     l_nextnode_id,
                     l_nextnode_type,
                     l_nodelink_name,
                     x_code,
                     x_msg);
      --在审批意见中显示下个节点的审批人
      get_approve_user(l_nextnode_id,
                       l_next_nodeuser_ids,
                       l_next_nodegroupdt_ids,
                       l_nextnode_users,
                       l_next_signtypes,
                       l_nextnode_user_num,
                       x_code,
                       x_msg);
      l_next_nodeuser_ids := replace(l_next_nodeuser_ids, '-1', l_user_id);
      l_nextnode_users    := replace(l_nextnode_users,
                                     '创建者本人',
                                     l_user_name);
    
      l_loop_user := 1;
      loop
        --如果此节点有多个审批人,接收人是下一个审批人,一直到最后一个审批才接收人才是下一个节点的审批人.
        exit when l_loop_user > l_user_num;
        l_do_date     := l_do_date + 1 / 24 / 60 / 60;
        l_loop_userid := regexp_substr(l_user_ids, '[^,]+', 1, l_loop_user);
        l_groupdt_id  := regexp_substr(l_groupdt_ids,
                                       '[^,]+',
                                       1,
                                       l_loop_user);
        l_signtype    := regexp_substr(l_signtypes, '[^,]+', 1, l_loop_user);
      
        --写入已审待审
        begin
          rec_workflow_currentoperator                    := null;
          rec_workflow_currentoperator.requestid          := p_request_id; --
          rec_workflow_currentoperator.userid             := l_loop_userid; --3363
          rec_workflow_currentoperator.groupid            := null; --2
          rec_workflow_currentoperator.workflowid         := l_workflow_id; --1991
          rec_workflow_currentoperator.workflowtype       := l_workflow_type; --29
          rec_workflow_currentoperator.isremark_tmp       := null; --
          rec_workflow_currentoperator.usertype           := 0; --0
          rec_workflow_currentoperator.nodeid             := l_currentnode_id; --11715
          rec_workflow_currentoperator.agentorbyagentid   := -1; ---不是代理
          rec_workflow_currentoperator.agenttype          := 0; --不是代理
          rec_workflow_currentoperator.showorder := case
                                                      when l_beginnode_id =
                                                           l_currentnode_id then
                                                       -1
                                                      else
                                                       0
                                                    end; -- -1 为第一次提交
          rec_workflow_currentoperator.receivedate        := to_char(l_do_date,
                                                                     'yyyy-mm-dd'); --44075
          rec_workflow_currentoperator.receivetime        := to_char(l_do_date,
                                                                     'hh24:mi:ss'); --0.548958333333333
          rec_workflow_currentoperator.viewtype           := -2; ---已查看
          rec_workflow_currentoperator.iscomplete := case
                                                       when rec_workflow_nodebase.isend = 1 then
                                                        1
                                                       else
                                                        0
                                                     end; --0:未归档，1:归档
          rec_workflow_currentoperator.islasttimes        := 1; --操作人最后一次操作记录
          rec_workflow_currentoperator.id                 := null; --自增
          rec_workflow_currentoperator.operatedate        := to_char(l_do_date,
                                                                     'yyyy-mm-dd'); --44075
          rec_workflow_currentoperator.operatetime        := to_char(l_do_date,
                                                                     'hh24:mi:ss'); --0.586840277777778
          rec_workflow_currentoperator.groupdetailid      := l_groupdt_id; --21246
          rec_workflow_currentoperator.isreminded         := null; --
          rec_workflow_currentoperator.isprocessed        := null; --
          rec_workflow_currentoperator.wfreminduser       := null; --
          rec_workflow_currentoperator.wfusertypes        := null; --
          rec_workflow_currentoperator.preisremark_tmp    := null; --
          rec_workflow_currentoperator.isreject           := 0; --是否退回
          rec_workflow_currentoperator.needwfback         := null; --0
          rec_workflow_currentoperator.lastisremark       := null; --
          rec_workflow_currentoperator.isreminded_csh     := null; --
          rec_workflow_currentoperator.wfreminduser_csh   := null; --
          rec_workflow_currentoperator.wfusertypes_csh    := null; --
          rec_workflow_currentoperator.handleforwardid    := null; --
          rec_workflow_currentoperator.takisremark        := null; --
          rec_workflow_currentoperator.lastreminddatetime := null; --
          rec_workflow_currentoperator.isprocessing       := null; --
          rec_workflow_currentoperator.opdatetime         := null; --
          rec_workflow_currentoperator.processuser        := l_loop_userid; --3363
          rec_workflow_currentoperator.isbereject         := null; --
          case
            when l_signtype = 3 then
              rec_workflow_currentoperator.isremark := 8;
            when l_signtype = 4 then
              rec_workflow_currentoperator.isremark := 9;
            else
              rec_workflow_currentoperator.isremark := case
                                                         when rec_workflow_nodebase.id =
                                                              l_nextnode_id and
                                                              rec_workflow_nodebase.isend = 1  then
                                                          4
                                                         when rec_workflow_nodebase.id =
                                                              l_currentnode_id  then
                                                          0
                                                         else
                                                          2
                                                       end; --0：未操作 1：转发 2：已操作 4：归档 5：超时 8：抄送(不需提交) 9：抄送(需提交) a: 意见征询 b: 回复 h: 转办 j: 转办提交
          end case ;
          rec_workflow_currentoperator.preisremark   := null; --0
          rec_workflow_currentoperator.overtime      := null; --
          rec_workflow_currentoperator.overworktime  := null; --
          rec_workflow_currentoperator.istakout      := null; --
          rec_workflow_currentoperator.takid         := null; --
          rec_workflow_currentoperator.multitaklevel := null; --
          rec_workflow_currentoperator.viewdate      := to_char(l_do_date,
                                                                'yyyy-mm-dd'); --44075
          rec_workflow_currentoperator.viewtime      := to_char(l_do_date,
                                                                'hh24:mi:ss'); --0.585358796296296
          rec_workflow_currentoperator.isinmultitak  := null; --
          rec_workflow_currentoperator.firstviewdate := to_char(l_do_date,
                                                                'yyyy-mm-dd'); --44075
          rec_workflow_currentoperator.firstviewtime := to_char(l_do_date,
                                                                'hh24:mi:ss'); --0.585358796296296
          rec_workflow_currentoperator.operatetype   := null; --
          rec_workflow_currentoperator.forkmark      := null; --
        
          if l_currentnode_id = l_beginnode_id and
             l_currentnode_id = rec_workflow_nodebase.id then
            rec_workflow_currentoperator.groupid := 0; --提交状态,要指定: 赋予每个操作人的标示，但是非会签会都一样是同一个值
          end if;
        
          insert into workflow_currentoperator
          values rec_workflow_currentoperator;
        end;
      
        --写入审批意见
        begin
          --if rec_workflow_nodebase.id != l_currentnode_id then
          rec_workflow_requestlog            := null;
          rec_workflow_requestlog.requestid  := p_request_id; --28660
          rec_workflow_requestlog.workflowid := l_workflow_id; --2020
          rec_workflow_requestlog.nodeid     := l_currentnode_id; --12089
          if l_signtype in (3, 4) then
            rec_workflow_requestlog.logtype := 't';
          else
            rec_workflow_requestlog.logtype := case
                                                 when l_currentnode_id =
                                                      l_beginnode_id and
                                                      l_currentnode_id <>
                                                      rec_workflow_nodebase.id then
                                                  2
                                                 when l_currentnode_id =
                                                      l_beginnode_id and
                                                      l_currentnode_id =
                                                      rec_workflow_nodebase.id then
                                                  1
                                                 else
                                                  0
                                               end; --0：批准 1：保存 2：提交 3：退回 4：重新打开 5：删除 6：激活 7：转发 9：批注 a：意见征询 b：意见征询回复 e：强制归档 h：转办 i：干预 j：转办反馈 s：督办 t：抄送  r:撤回 
          end if;
          rec_workflow_requestlog.operatedate       := to_char(l_do_date,
                                                               'yyyy-mm-dd'); --44075
          rec_workflow_requestlog.operatetime       := to_char(l_do_date,
                                                               'hh24:mi:ss'); --0.558576388888889
          rec_workflow_requestlog.operator          := l_loop_userid; --3341
          rec_workflow_requestlog.remark1           := null; --
          rec_workflow_requestlog.clientip          := null; --10.107.5.52
          rec_workflow_requestlog.operatortype      := 0; --0
          rec_workflow_requestlog.destnodeid := case
                                                  when l_currentnode_id =
                                                       l_beginnode_id and
                                                       l_currentnode_id =
                                                       rec_workflow_nodebase.id then
                                                   l_currentnode_id
                                                  when l_loop_user <> l_user_num then 
                                                    l_currentnode_id
                                                  else
                                                   l_nextnode_id
                                                end; --12016 
          rec_workflow_requestlog.receivedpersons_1 := null; --
          rec_workflow_requestlog.showorder := case
                                                 when l_currentnode_id =
                                                      l_beginnode_id then
                                                  -1
                                                 else
                                                  1
                                               end; --1
          rec_workflow_requestlog.agentorbyagentid  := -1; ---1
          rec_workflow_requestlog.agenttype         := 0; --0
          rec_workflow_requestlog.logid             := null; --25195
          rec_workflow_requestlog.annexdocids       := null; --
          rec_workflow_requestlog.requestlogid      := null; --0
          rec_workflow_requestlog.operatordept      := null; --775
          rec_workflow_requestlog.signdocids        := null; --
          rec_workflow_requestlog.signworkflowids   := null; --
          rec_workflow_requestlog.receivedpersons   := case when l_loop_user <> l_user_num  then regexp_substr(l_currentnode_users,'[^,]+',1,l_loop_user+1) else l_nextnode_users end ; -- 接收人中文显示
          rec_workflow_requestlog.receivedpersonids := case when l_loop_user <> l_user_num  then regexp_substr(l_user_ids,'[^,]+',1,l_loop_user+1) else l_next_nodeuser_ids end ; --接收人ID
          rec_workflow_requestlog.ismobile          := 'd'; --d
          rec_workflow_requestlog.handwrittensign   := null; --
          rec_workflow_requestlog.speechattachment  := 0; --0
        
          rec_workflow_requestlog.remarklocation     := null; --
          rec_workflow_requestlog.issubmitdirect     := null; --
          rec_workflow_requestlog.remarkquote        := null; --<clob>
          rec_workflow_requestlog.fulltextannotation := null; --
          rec_workflow_requestlog.speechattachmente9 := null; --0
          rec_workflow_requestlog.uuid               := null; --
          rec_workflow_requestlog.remark             := '后台自动写入'; --<clob>
          rec_workflow_requestlog.operatorsub        := null; --521
          rec_workflow_requestlog.operatorjob        := null; --21
          rec_workflow_requestlog.isrobotnode        := null; --
          rec_workflow_requestlog.seclevel           := null; --
        
          select a.subcompanyid1, a.jobtitle, a.departmentid
            into rec_workflow_requestlog.operatorsub,
                 rec_workflow_requestlog.operatorjob,
                 rec_workflow_requestlog.operatordept
            from hrmresource a
           where a.id = rec_workflow_requestlog.operator;
        
          if l_currentnode_id = l_beginnode_id and
             l_currentnode_id = rec_workflow_nodebase.id then
            rec_workflow_requestlog.remark := null;
          end if;
        
          insert into workflow_requestlog values rec_workflow_requestlog;
          -- end if;
        end;
      
        l_loop_user := l_loop_user + 1;
      
      end loop;
    
      --更新审批流程状态
      begin
        update workflow_requestbase a
           set a.lastnodeid      = a.currentnodeid,
               a.lastnodetype    = a.currentnodetype,
               a.currentnodeid   = l_currentnode_id,
               a.currentnodetype = l_currentnode_type,
               a.STATUS          = l_nodelink_name
         where a.requestid = p_request_id;
      
        if sql%rowcount = 0 then
          rec_workflow_requestbase                       := null;
          rec_workflow_requestbase.REQUESTID             := p_request_id;
          rec_workflow_requestbase.WORKFLOWID            := l_workflow_id;
          rec_workflow_requestbase.LASTNODEID            := l_currentnode_id; --上一节点
          rec_workflow_requestbase.LASTNODETYPE          := 0; -- l_currentnode_type; --上一节点
          rec_workflow_requestbase.CURRENTNODEID         := l_currentnode_id; --当前节点
          rec_workflow_requestbase.CURRENTNODETYPE       := 0; --l_currentnode_type; --当前节点
          rec_workflow_requestbase.STATUS                := NULL; --l_nodelink_name;
          rec_workflow_requestbase.PASSEDGROUPS          := '0'; --此节点已审了几个审批组
          rec_workflow_requestbase.TOTALGROUPS           := '0'; --此节点有几个审批组
          rec_workflow_requestbase.REQUESTNAME           := p_request_name;
          rec_workflow_requestbase.CREATER               := l_user_id;
          rec_workflow_requestbase.CREATEDATE            := to_char(l_do_date,
                                                                    'yyyy-mm-dd');
          rec_workflow_requestbase.CREATETIME            := to_char(l_do_date,
                                                                    'hh24:mi:ss');
          rec_workflow_requestbase.LASTOPERATOR          := l_user_id;
          rec_workflow_requestbase.LASTOPERATEDATE       := to_char(l_do_date,
                                                                    'yyyy-mm-dd');
          rec_workflow_requestbase.LASTOPERATETIME       := to_char(l_do_date,
                                                                    'hh24:mi:ss');
          rec_workflow_requestbase.DELETED               := '0';
          rec_workflow_requestbase.CREATERTYPE           := '0';
          rec_workflow_requestbase.LASTOPERATORTYPE      := '0';
          rec_workflow_requestbase.NODEPASSTIME          := '-1';
          rec_workflow_requestbase.NODELEFTTIME          := '-1';
          rec_workflow_requestbase.DOCIDS                := '';
          rec_workflow_requestbase.CRMIDS                := '';
          rec_workflow_requestbase.HRMIDS_TEMP           := '';
          rec_workflow_requestbase.PRJIDS                := '';
          rec_workflow_requestbase.CPTIDS                := '';
          rec_workflow_requestbase.REQUESTLEVEL          := '0';
          rec_workflow_requestbase.REQUESTMARK           := null; --请求说明
          rec_workflow_requestbase.MESSAGETYPE           := '0';
          rec_workflow_requestbase.MAINREQUESTID         := '';
          rec_workflow_requestbase.CURRENTSTATUS         := '';
          rec_workflow_requestbase.LASTSTATUS            := '';
          rec_workflow_requestbase.ISMULTIPRINT          := '0';
          rec_workflow_requestbase.CHATSTYPE             := '0';
          rec_workflow_requestbase.ECOLOGY_PINYIN_SEARCH := null;
          rec_workflow_requestbase.HRMIDS                := null; --相关人力资源,还不知道怎么处理
          rec_workflow_requestbase.REQUESTNAMENEW        := p_request_name;
          rec_workflow_requestbase.FORMSIGNATUREMD5      := '';
          rec_workflow_requestbase.DATAAGGREGATED        := '';
          rec_workflow_requestbase.SECLEVEL              := '';
          rec_workflow_requestbase.SECDOCID              := '';
          rec_workflow_requestbase.REMINDTYPES           := '';
          rec_workflow_requestbase.LASTFEEDBACKDATE      := '';
          rec_workflow_requestbase.LASTFEEDBACKTIME      := '';
          rec_workflow_requestbase.LASTFEEDBACKOPERATOR  := '';
          rec_workflow_requestbase.REQUESTNAMEHTMLNEW    := '';
          rec_workflow_requestbase.SECVALIDITY           := '';
          rec_workflow_requestbase.SECENCKEY             := '';
          rec_workflow_requestbase.SECCRC                := '';
        
          insert into workflow_requestbase values rec_workflow_requestbase;
        end if;
      end;
    
      exit when l_currentnode_id = rec_workflow_nodebase.id;
    
      l_currentnode_id := l_nextnode_id;
    
    end loop;
  
  end;

  /*
  test1 : 
  OA表单：销售出货报表需求单，物料产品类别和终端维护表名：CUX_NEW_ENERGY_ITEM_T
  */
  procedure test1(p_nodename varchar2) is
    l_request_id number := get_request_id;
    l_code       varchar2(2000);
    l_msg        varchar2(2000);
  begin
    insert into formtable_main_3493
      (id, requestid, lxdh, lcbh, fj, xqms, bbmc, xm, gh)
    values
      (null,
       l_request_id,
       '13312345678',
       null,
       null,
       '测试',
       0,
       '张三',
       'A001');
  
    main(p_request_id       => l_request_id,
         p_request_name     => '测试: ' || l_request_id || '--' ||
                               to_char(sysdate, 'yyyymmdd hh24:mi:ss'),
         p_workflow_name    => '销售出货报表需求单',
         p_current_nodename => nvl(p_nodename, '应用主管审批'),
         p_create_user      => 'A0091778', --'A0117856',
         p_create_date      => sysdate,
         x_code             => l_code,
         x_msg              => l_msg);
    dbms_output.put_line(l_request_id);
    dbms_output.put_line(l_code || ':' || l_msg);
  end;

end cux_create_doc_pkg3;
/

