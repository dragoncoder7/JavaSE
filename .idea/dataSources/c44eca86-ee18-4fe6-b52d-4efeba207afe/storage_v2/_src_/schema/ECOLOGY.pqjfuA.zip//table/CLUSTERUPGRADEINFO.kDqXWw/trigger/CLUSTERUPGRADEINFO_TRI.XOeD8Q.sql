create trigger CLUSTERUPGRADEINFO_TRI
    before insert
    on CLUSTERUPGRADEINFO
    for each row
begin select ClusterUpgradeInfo_SEQ.nextval into :new.id from dual; 
 end;
/

