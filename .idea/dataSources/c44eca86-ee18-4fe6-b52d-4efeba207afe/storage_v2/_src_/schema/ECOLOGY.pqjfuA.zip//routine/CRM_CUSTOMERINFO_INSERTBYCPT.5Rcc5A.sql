create PROCEDURE CRM_CustomerInfo_InsertByCpt ( name_1 	  		  varchar2, manager_1 		  integer, CreditAmount_1 	  number, CreditTime_1 	  integer, flag out  		  integer , msg out   		  varchar2, thecursor IN OUT cursor_define.weavercursor ) AS  begin INSERT INTO CRM_CustomerInfo ( name, engname, manager, CreditAmount, CreditTime, status, deleted, type) VALUES ( name_1, name_1, manager_1, CreditAmount_1, CreditTime_1, 1, 0, 2);  open thecursor for SELECT max(id) as id from CRM_CustomerInfo;  end;


/

