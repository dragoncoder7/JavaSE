create trigger FNATENPAYPRODUCTINFO_INS_TRG
    before insert
    on FNATENPAYPRODUCTINFO
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT fnaTenPayProductInfo_id_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

