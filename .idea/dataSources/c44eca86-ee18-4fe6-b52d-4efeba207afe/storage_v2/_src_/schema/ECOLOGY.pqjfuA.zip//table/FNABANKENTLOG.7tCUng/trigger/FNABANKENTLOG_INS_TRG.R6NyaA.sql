create trigger FNABANKENTLOG_INS_TRG
    before insert
    on FNABANKENTLOG
    for each row
    when (NEW.id IS NULL)
BEGIN SELECT fnaBankEntLog_Id_SEQ.NEXTVAL INTO :NEW.id FROM DUAL; END;
/

