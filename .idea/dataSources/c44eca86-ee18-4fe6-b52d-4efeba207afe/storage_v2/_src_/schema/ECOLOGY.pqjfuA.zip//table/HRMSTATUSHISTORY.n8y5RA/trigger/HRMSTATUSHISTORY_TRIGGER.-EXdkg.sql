create trigger HRMSTATUSHISTORY_TRIGGER
    before insert
    on HRMSTATUSHISTORY
    for each row
begin select HrmStatusHistory_id.nextval into :new.id from dual; end;
/

