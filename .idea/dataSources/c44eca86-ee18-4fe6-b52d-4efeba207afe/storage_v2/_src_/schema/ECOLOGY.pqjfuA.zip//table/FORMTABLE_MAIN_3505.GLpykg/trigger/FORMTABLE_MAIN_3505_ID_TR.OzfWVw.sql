create trigger FORMTABLE_MAIN_3505_ID_TR
    before insert
    on FORMTABLE_MAIN_3505
    for each row
begin select formtable_main_3505_Id.nextval into :new.id from dual; end;
/

