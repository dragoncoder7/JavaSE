create trigger TRI_U_HPELEMENT_NOTICE
    before insert
    on HPELEMENT_NOTICE
    for each row
    when (new.id is null)
begin select SEQ_hpElement_notice.nextval into:new.id from dual; end;
/

