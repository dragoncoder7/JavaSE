create trigger MODE_SEARCHROWCLICKRELATE_TRI
    before insert
    on MODE_SEARCHROWCLICKRELATE
    for each row
begin select mode_searchRowClickRelate_id.nextval into :new.id from dual; end;
/

