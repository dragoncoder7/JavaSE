create trigger FORMTABLE_MAIN_17_DT1_ID_TR
    before insert
    on FORMTABLE_MAIN_17_DT1
    for each row
begin select formtable_main_17_dt1_Id.nextval into :new.id from dual; end;
/

