create trigger HRMTRAINRECORD_TRIGGER
    before insert
    on HRMTRAINRECORD
    for each row
begin select HrmTrainRecord_id.nextval into :new.id from dual; end;
/

