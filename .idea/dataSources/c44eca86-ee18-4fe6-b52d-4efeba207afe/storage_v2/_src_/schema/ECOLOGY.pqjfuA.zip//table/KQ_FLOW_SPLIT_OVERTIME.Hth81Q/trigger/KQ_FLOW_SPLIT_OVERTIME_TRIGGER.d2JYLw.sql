create trigger KQ_FLOW_SPLIT_OVERTIME_TRIGGER
    before insert
    on KQ_FLOW_SPLIT_OVERTIME
    for each row
begin select kq_flow_split_overtime_ID.nextval INTO :new.id from dual; end;
/

