create PROCEDURE CptCapital_Delete (id_1 	integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS isdata_1 integer; begin select isdata into isdata_1 from CptCapital where id = id_1; if (isdata_1 = 1) then update CptCapitalAssortment set capitalcount = capitalcount-1 where id in (select capitalgroupid from CptCapital where id = id_1 ); end if; DELETE CptCapital WHERE ( id=id_1); open thecursor for select max(id) from CptCapital; end;


/

