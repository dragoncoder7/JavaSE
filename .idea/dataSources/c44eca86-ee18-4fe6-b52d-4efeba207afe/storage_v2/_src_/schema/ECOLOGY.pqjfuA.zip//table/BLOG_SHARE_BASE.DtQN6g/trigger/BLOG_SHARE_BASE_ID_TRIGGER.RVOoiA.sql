create trigger BLOG_SHARE_BASE_ID_TRIGGER
    before insert
    on BLOG_SHARE_BASE
    for each row
begin select blog_share_base_id_seq.nextval into :new.id from dual; end;
/

