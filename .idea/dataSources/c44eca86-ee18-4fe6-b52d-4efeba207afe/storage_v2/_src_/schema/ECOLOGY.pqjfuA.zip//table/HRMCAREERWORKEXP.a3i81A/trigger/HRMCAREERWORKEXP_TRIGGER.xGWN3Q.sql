create trigger HRMCAREERWORKEXP_TRIGGER
    before insert
    on HRMCAREERWORKEXP
    for each row
begin select HrmCareerWorkexp_id.nextval into :new.id from dual; end;
/

