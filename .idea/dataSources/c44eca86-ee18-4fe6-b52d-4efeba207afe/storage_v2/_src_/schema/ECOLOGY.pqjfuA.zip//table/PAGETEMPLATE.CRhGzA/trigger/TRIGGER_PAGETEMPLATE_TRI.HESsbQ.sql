create trigger TRIGGER_PAGETEMPLATE_TRI
    before insert
    on PAGETEMPLATE
    for each row
begin select pagetemplate_id.nextval into :new.id from dual; end;
/

