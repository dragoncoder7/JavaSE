create trigger PRAISE_INFO_TRIGGER
    before insert
    on PRAISE_INFO
    for each row
begin select PRAISE_INFO_SEQ.nextval into :new.id from dual; end ;
/

