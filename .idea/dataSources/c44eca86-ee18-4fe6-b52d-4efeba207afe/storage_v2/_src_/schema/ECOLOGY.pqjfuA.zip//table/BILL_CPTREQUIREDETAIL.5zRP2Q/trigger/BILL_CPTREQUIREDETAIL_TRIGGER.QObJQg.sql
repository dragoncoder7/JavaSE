create trigger BILL_CPTREQUIREDETAIL_TRIGGER
    before insert
    on BILL_CPTREQUIREDETAIL
    for each row
begin select bill_CptRequireDetail_id.nextval INTO :new.id from dual; end;
/

