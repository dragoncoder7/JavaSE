create trigger HRMCOSTCENTERSUBCATEGORY_TR
    before insert
    on HRMCOSTCENTERSUBCATEGORY
    for each row
begin select HrmCostcenterSubCategory_id.nextval into :new.id from dual; end;
/

