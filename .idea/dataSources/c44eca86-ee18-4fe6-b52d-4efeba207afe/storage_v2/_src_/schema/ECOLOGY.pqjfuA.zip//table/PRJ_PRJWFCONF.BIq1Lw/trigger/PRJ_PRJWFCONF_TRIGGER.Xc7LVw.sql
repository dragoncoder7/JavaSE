create trigger PRJ_PRJWFCONF_TRIGGER
    before insert
    on PRJ_PRJWFCONF
    for each row
begin select prj_prjwfconf_ID.nextval into :new.id from dual; end;
/

