create PROCEDURE CRM_CreditInfo_Insert ( fullname_1 	varchar2, creditamount_1 	varchar2, highamout_1  varchar2, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin INSERT INTO  CRM_CreditInfo ( fullname, creditamount,highamount) VALUES ( fullname_1, to_number(creditamount_1),to_number(highamout_1)); end;


/

