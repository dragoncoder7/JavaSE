create trigger EXCHANGE_LIMIT_TRI
    before insert
    on EXCHANGE_LIMIT
    for each row
begin select exchange_limit_seq.nextval into :new.id from dual; end ;
/

