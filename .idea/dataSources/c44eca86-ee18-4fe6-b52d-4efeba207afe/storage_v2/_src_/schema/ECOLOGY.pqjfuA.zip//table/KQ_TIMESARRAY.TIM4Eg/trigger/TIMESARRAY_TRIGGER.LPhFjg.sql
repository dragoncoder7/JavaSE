create trigger TIMESARRAY_TRIGGER
    before insert
    on KQ_TIMESARRAY
    for each row
begin select timesarray_ID.nextval INTO :new.id from dual; end;
/

