create PROCEDURE CRM_CustomerStatus_Update ( id_1 	integer, fullname_1 	varchar2, description_1 	varchar2, cnname_1 varchar2, usname_1 varchar2, twname_1 varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE CRM_CustomerStatus SET fullname	 = fullname_1, description	 = description_1 ,cnname=cnname_1,usname=usname_1,twname=twname_1 WHERE ( id	 = id_1); end;


/

