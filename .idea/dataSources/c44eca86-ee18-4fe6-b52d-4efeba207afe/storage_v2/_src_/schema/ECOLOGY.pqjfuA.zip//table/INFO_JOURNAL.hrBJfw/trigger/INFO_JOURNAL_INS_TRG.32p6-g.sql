create trigger INFO_JOURNAL_INS_TRG
    before insert
    on INFO_JOURNAL
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT info_journal_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

