create procedure WorkflowToEnd() is
declare
  -- Local variables here
  --获得要归档的所有流程信息
  cursor getWorkflowResult is
    select *
      from workflow_requestbase a
     where (a.deleted <> 1 or a.deleted is null or a.deleted = '')
       and a.workflowid in
           (select id from workflow_base where formid = -1977) --
       and currentnodetype != 3
       and a.createdate >= '2021-08-01'
       and a.createdate <= '2021-09-01'
     order by a.createdate, a.createtime, a.requestid desc;

  --根据流程的requestid来获得这个流程当前的待办数据 如一个requestid对应两条记录 说明现在这个节点有两个人需要审批 其他同理；
  cursor update_currentoperator(p_requestid INTEGER) is
    select *
      from workflow_currentoperator b
     where b.requestid = p_requestid
       and b.usertype = 0
       and ((b.isremark = '0' and --(a and (b or c) ) or d    
           (b.takisremark is null or b.takisremark = 0)) or
           b.isremark in ('1', '5', '8', '9', '7', '11'))
       and b.islasttimes = 1;
  requestid workflow_requestbase.requestid%TYPE;
  counts    varchar2(200) := null; --记录所以需要处理的流程总数
  counts1   INTEGER := 0; --记录已处理归档流程数量
  counts2   INTEGER := 0; --记录修改操作人状态条数
  nodeid1    INTEGER := 0; --根据流程requestbase的workflowid获得归档节点id 
  nodeid2    INTEGER := 0; --根据流程operator的workflowid获得归档节点id 
begin
  select count(*)
    into counts
    from workflow_requestbase a
   where (a.deleted <> 1 or a.deleted is null or a.deleted = '')
     and a.workflowid in
         (select id from workflow_base where formid = -1977) --
     and currentnodetype != 3
     and a.createdate >= '2021-08-01'
     and a.createdate <= '2021-09-01';
  DBMS_OUTPUT.PUT_LINE('需要修改为归档的总流程行数：' || counts); --

  -- Test statements here
  for c in getWorkflowResult loop
    --获得归档节点id
    /*select t.nodeid
      into nodeid
      from workflow_flownode t
     where t.workflowid = c.workflowid
       and t.nodetype = 3;*/
    requestid := c.requestid;   
    counts1 := counts1 + 1;
    select t.nodeid into nodeid1
              from workflow_flownode t
             where t.workflowid = c.workflowid
               and t.nodetype = 3;
    DBMS_OUTPUT.PUT_LINE('记录修改为归档的流程requestid：' || c.requestid);
    DBMS_OUTPUT.PUT_LINE('workflow_requestbase修改前的nodeid:' || c.currentnodeid);
    for cc in update_currentoperator(c.requestid) loop
      counts2 := counts2 + 1;
      DBMS_OUTPUT.PUT_LINE('workflow_currentoperator修改前的nodeid:' || cc.nodeid);
      select t.nodeid into nodeid2
                from workflow_flownode t
               where t.workflowid = cc.workflowid
                 and t.nodetype = 3;
      --更新操作人状态 
      update workflow_currentoperator a
         set a.isremark   = 4, -- 4 归档
             a.iscomplete = 1, -- 1 已归档
             a.nodeid    = nodeid2    --归档节点id
             
       where cc.id = a.id;
       
       --可能还需要插入一条归档日志 workflow_requestlog
       --以及当前这个节点的
       
      DBMS_OUTPUT.PUT_LINE('workflow_currentoperator修改后的nodeid:' || nodeid2);
    end loop;
    
    update workflow_requestbase tt
       set tt.currentnodetype = 3, --3 节点类型为归档
           tt.currentnodeid  = nodeid1    --归档节点id
           where tt.requestid = c.requestid
           ;
               
    DBMS_OUTPUT.PUT_LINE('workflow_requestbase修改后的nodeid:' || nodeid1);
       if counts1 >= 10 then return;
       end if;
       --外层循环了10条数据以上就停止循环
  end loop;
end WorkflowToEnd;
/

