create trigger EDC_OPERATE_LOG_INS_TRG
    before insert
    on EDC_OPERATE_LOG
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_operate_log_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

