create trigger WR_NDPDM_PVS_TRG
    before insert
    on WR_YEARINVENTORY_TMP_PAGE
    for each row
begin select WR_NDPDM_PVS_SEQ.nextval into :new.id from DUAL; END;
/

