create trigger TR_INT_BROWSERBASEINFO
    before insert
    on INT_BROWSERBASEINFO
    for each row
begin select sq_int_BrowserbaseInfo.nextval into :new.id from dual; end;
/

