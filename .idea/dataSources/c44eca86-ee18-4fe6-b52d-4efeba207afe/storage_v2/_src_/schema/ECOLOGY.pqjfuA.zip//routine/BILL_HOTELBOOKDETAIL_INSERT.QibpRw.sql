create PROCEDURE bill_HotelBookDetail_Insert ( bookid1		integer, hotelid1    integer, roomstyle1  varchar2, roomsum1    integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin insert into bill_HotelBookDetail (bookid,hotelid,roomstyle,roomsum) values (bookid1,hotelid1,roomstyle1,roomsum1); end;


/

