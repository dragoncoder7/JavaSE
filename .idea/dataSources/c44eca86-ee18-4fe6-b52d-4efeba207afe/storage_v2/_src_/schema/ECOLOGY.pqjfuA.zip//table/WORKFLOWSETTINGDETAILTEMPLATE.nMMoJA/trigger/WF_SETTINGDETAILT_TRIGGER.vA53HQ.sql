create trigger WF_SETTINGDETAILT_TRIGGER
    before insert
    on WORKFLOWSETTINGDETAILTEMPLATE
    for each row
    when (new.id is null)
begin select wf_settingdetailt_seq.nextval into:new.id from dual; end;
/

