create trigger HRM_SEARCHFIELD_TRIGGER
    before insert
    on HRM_SEARCHFIELD
    for each row
begin select hrm_searchfield_id.nextval into :new.fieldid from dual; end;
/

