create trigger WR_NDPD_TMP_TRG
    before insert
    on WR_YEAR_INVENTORY_TEMPLATE
    for each row
begin select WR_NDPD_TMP_SEQ.nextval into :new.id from DUAL; END;
/

