create trigger INT_OAUTH2_CFG_TRI
    before insert
    on INT_OAUTH2_CFG
    for each row
begin select Int_OAuth2_Cfg_id.nextval into :new.id from dual; end ;
/

