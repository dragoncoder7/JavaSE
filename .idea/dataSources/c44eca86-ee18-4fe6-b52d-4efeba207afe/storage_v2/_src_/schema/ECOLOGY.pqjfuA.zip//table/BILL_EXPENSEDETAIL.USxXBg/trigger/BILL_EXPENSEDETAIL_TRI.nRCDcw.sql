create trigger BILL_EXPENSEDETAIL_TRI
    before insert
    on BILL_EXPENSEDETAIL
    for each row
begin select Bill_ExpenseDetail_id.nextval into :new.id from dual; end;
/

