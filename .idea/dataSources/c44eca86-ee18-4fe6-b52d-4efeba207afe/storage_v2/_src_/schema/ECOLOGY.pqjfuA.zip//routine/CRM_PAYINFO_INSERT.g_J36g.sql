create PROCEDURE CRM_PayInfo_Insert (id_1		integer, factprice_1	number, factdate_1 char, creater_1 integer, formNum_1   varchar2 , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin insert into CRM_PayInfo (payid,factprice,factdate,creater,formNum) values (	id_1,factprice_1,	factdate_1 ,creater_1 ,formNum_1); end;


/

