create trigger HRMWELFARE_TRIGGER
    before insert
    on HRMWELFARE
    for each row
begin select HrmWelfare_id.nextval into :new.id from dual; end;
/

