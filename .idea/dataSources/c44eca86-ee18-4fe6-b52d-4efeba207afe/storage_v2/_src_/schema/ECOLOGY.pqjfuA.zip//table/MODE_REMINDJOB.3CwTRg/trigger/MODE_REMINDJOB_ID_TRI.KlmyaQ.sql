create trigger MODE_REMINDJOB_ID_TRI
    before insert
    on MODE_REMINDJOB
    for each row
begin select mode_remindjob_id.nextval into :new.id from dual; end;
/

