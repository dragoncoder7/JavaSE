create trigger INT_ELEMENT_SETTING_ID_TRI
    before insert
    on INT_ELEMENT_SETTING
    for each row
begin select Int_Element_Setting_id.nextval into :new.id from dual; end ;
/

