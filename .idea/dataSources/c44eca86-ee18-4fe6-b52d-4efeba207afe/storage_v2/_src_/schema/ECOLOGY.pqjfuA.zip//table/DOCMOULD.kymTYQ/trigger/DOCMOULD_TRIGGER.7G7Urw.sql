create trigger DOCMOULD_TRIGGER
    before insert
    on DOCMOULD
    for each row
begin select DocMould_id.nextval INTO :new.id from dual; end;
/

