create trigger FNACOSTCENTER_TRIGGER
    before insert
    on FNACOSTCENTER
    for each row
begin select seq_FnaCostCenter_id.nextval into :new.id from dual; end;
/

