create trigger HRMMESSAGERGROUPUSERS_TRIGGER
    before insert
    on HRMMESSAGERGROUPUSERS
    for each row
begin select HrmMessagerGroupUsers_seq.nextval into :new.id from dual; end;
/

