create trigger FORMTABLE_MAIN_105_ID_TR
    before insert
    on FORMTABLE_MAIN_105
    for each row
begin select formtable_main_105_Id.nextval into :new.id from dual;  end;
/

