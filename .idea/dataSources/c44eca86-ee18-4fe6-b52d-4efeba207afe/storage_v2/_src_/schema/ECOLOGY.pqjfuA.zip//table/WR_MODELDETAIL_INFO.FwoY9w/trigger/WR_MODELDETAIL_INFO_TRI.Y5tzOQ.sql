create trigger WR_MODELDETAIL_INFO_TRI
    before insert
    on WR_MODELDETAIL_INFO
    for each row
begin select WR_ModelDetail_Info_SEQ.nextval into :new.id from dual; end;
/

