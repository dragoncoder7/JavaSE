create package cux_create_doc_pkg is

  -- Author  : CEDAR
  -- Created : 2024/6/25 14:01:40
  -- Purpose : 用于后台创建单据

  --请求信息
  g_request_id       number;
  g_request_name     varchar2(200);
  g_transaction_date date;

  --流程表单参数
  g_workflow_id        number;
  g_workflow_type      number;
  g_workflow_tablename varchar2(200);
  g_workflow_name      varchar2(200);

  --开始节点
  g_start_node_id number;
  g_end_node_id   number;

  --指定节点的基础信息
  g_rec_nodebase workflow_nodebase%rowtype;
  g_out_node_id  number := 0; --用于标识当前已是指定节点的下一节点了. 

  --过滤参数,不使用于具体流程 
  g_temp varchar2(200);

  --操作用户信息
  g_user_id   number;
  g_user_name varchar2(200);
  /*
  获取请求id
  */
  function get_request_id return number;

  /*
  获得工作流的开始节点
  */
  procedure get_start_node_id(x_code out varchar2, x_msg out varchar2);

  /*
  执行审批
  */
  procedure p_approve(p_workflow_id   number,
                      p_node_id       number,
                      p_nodelink_name varchar2, --p_node_id 与下一个节点的出口名称
                      p_last_node_id  number, --上一节点ID
                      x_code          out varchar2,
                      x_msg           out varchar2);

  procedure main(p_workflow_name    varchar2, --流程表单名称
                 p_request_id       number, --流程请求ID
                 p_request_name     varchar2, --请求名称
                 p_current_nodename varchar2, --当前节点名称
                 p_user_name        varchar2, --操作用户
                 p_transaction_date date, --操作时间 
                 x_code             out varchar2, --返回代码
                 x_msg              out varchar2 --返回信息
                 );

  procedure test1(p_nodename varchar2);

end cux_create_doc_pkg;
/

