create PROCEDURE bill_Discuss_UpdateStatus ( id1		integer, status1	 char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin update bill_Discuss set status=status where id=id1 ; end;


/

