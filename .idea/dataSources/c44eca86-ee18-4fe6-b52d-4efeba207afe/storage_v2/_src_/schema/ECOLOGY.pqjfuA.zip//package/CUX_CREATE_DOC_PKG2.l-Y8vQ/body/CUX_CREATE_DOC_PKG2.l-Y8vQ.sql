create package body cux_create_doc_pkg2 is

  procedure check_workflow_info(x_code out varchar2, x_msg out varchar2) is
  
  begin
    select wb.id, wbi.tablename, wb.workflowtype
      into g_workflow_id, g_workflow_tablename, g_workflow_type
      from workflow_base wb, workflow_bill wbi
     where wb.formid = wbi.id
          
       and wb.workflowname = g_workflow_name --'货物出门证(广东长盈)'
       and wb.isvalid = 1 --有效
       and (wb.activeversionid is null or exists
            (select 1
               from workflow_versioninfo wv
              where 1 = 1
                and wb.id = wv.wfid
                and wb.activeversionid = wv.wfversionid --活动版本
             ));
  exception
    when others then
    
      x_code := 'E';
      x_msg  := '无法找到表单：' || g_workflow_name;
  end;

  procedure check_billtable_info(x_code out varchar2, x_msg out varchar2) is
    l_sql  varchar2(2000);
    l_temp varchar2(2000);
  begin
    --2. 判断业务表是否已写入了requestid 
    l_sql := 'select 1 from ' || g_workflow_tablename ||
             ' where requestid =  ' || g_request_id;
  
    execute immediate l_sql
      into l_temp;
  exception
    when others then
      x_code := 'E';
      x_msg  := '未找到此请求的表单数据：' || l_sql;
      return;
  end;

  /*
  给g_rec_nodebase赋值
  */
  procedure get_nodeinfo(p_nodename varchar2,
                         x_code     out varchar2,
                         x_msg      out varchar2) is
  
  begin
    select wn.*
      into g_rec_nodebase
      from workflow_flownode wf, workflow_nodebase wn
     where wf.nodeid = wn.id
          
       and wf.workflowid = g_workflow_id
          -- and wn.nodename = p_current_nodename
       and (wn.nodename like '%`7 ' || p_nodename || '`%' or
           wn.nodename = p_nodename);
  exception
    when others then
      x_code := 'E';
      x_msg  := '节点不在此流程中：' || p_nodename;
    
  end;

  /*
  判断是否满足出口条件 
  */
  procedure check_nodelink(p_nodelink_id number,
                           x_pass_flag   out varchar2,
                           x_code        out varchar2,
                           x_msg         out varchar2) is
  
  begin
    null;
  end;

  /*
  处理流程请求基础信息
  */
  procedure process_requestbase(p_node_id       number,
                                p_node_linkname varchar2, --在开始节点时,不传值
                                x_code          out varchar2,
                                x_msg           out varchar2) is
    l_currentnode_type       number;
    rec_workflow_requestbase workflow_requestbase%rowtype;
  begin
    if p_node_linkname is not null then
      update workflow_requestbase a
         set a.lastnodeid      = a.currentnodeid,
             a.lastnodetype    = a.currentnodetype,
             a.currentnodeid   = p_node_id,
             a.currentnodetype = l_currentnode_type,
             a.STATUS          = p_node_linkname --currentnodeid指向下一个节点对应的出口条件
       where a.requestid = g_request_id
         and p_node_linkname is not null
         and a.currentnodeid <> p_node_id;
    end if;
  
    if p_node_linkname is null then
      delete from workflow_requestbase a where a.requestid = g_request_id; --有可能开始节点下有多个出口
    
      rec_workflow_requestbase                       := null;
      rec_workflow_requestbase.REQUESTID             := g_request_id;
      rec_workflow_requestbase.WORKFLOWID            := g_workflow_id;
      rec_workflow_requestbase.LASTNODEID            := p_node_id; --上一节点
      rec_workflow_requestbase.LASTNODETYPE          := 0; -- l_currentnode_type; --上一节点
      rec_workflow_requestbase.CURRENTNODEID         := p_node_id; --当前节点
      rec_workflow_requestbase.CURRENTNODETYPE       := 0; --l_currentnode_type; --当前节点
      rec_workflow_requestbase.STATUS                := NULL; --l_nodelink_name;
      rec_workflow_requestbase.PASSEDGROUPS          := '0'; --此节点已审了几个审批组
      rec_workflow_requestbase.TOTALGROUPS           := '0'; --此节点有几个审批组
      rec_workflow_requestbase.REQUESTNAME           := g_request_name;
      rec_workflow_requestbase.CREATER               := g_user_id;
      rec_workflow_requestbase.CREATEDATE            := to_char(g_transaction_date,
                                                                'yyyy-mm-dd');
      rec_workflow_requestbase.CREATETIME            := to_char(g_transaction_date,
                                                                'hh24:mi:ss');
      rec_workflow_requestbase.LASTOPERATOR          := g_user_id;
      rec_workflow_requestbase.LASTOPERATEDATE       := to_char(g_transaction_date,
                                                                'yyyy-mm-dd');
      rec_workflow_requestbase.LASTOPERATETIME       := to_char(g_transaction_date,
                                                                'hh24:mi:ss');
      rec_workflow_requestbase.DELETED               := '0';
      rec_workflow_requestbase.CREATERTYPE           := '0';
      rec_workflow_requestbase.LASTOPERATORTYPE      := '0';
      rec_workflow_requestbase.NODEPASSTIME          := '-1';
      rec_workflow_requestbase.NODELEFTTIME          := '-1';
      rec_workflow_requestbase.DOCIDS                := '';
      rec_workflow_requestbase.CRMIDS                := '';
      rec_workflow_requestbase.HRMIDS_TEMP           := '';
      rec_workflow_requestbase.PRJIDS                := '';
      rec_workflow_requestbase.CPTIDS                := '';
      rec_workflow_requestbase.REQUESTLEVEL          := '0';
      rec_workflow_requestbase.REQUESTMARK           := null; --请求说明
      rec_workflow_requestbase.MESSAGETYPE           := '0';
      rec_workflow_requestbase.MAINREQUESTID         := '';
      rec_workflow_requestbase.CURRENTSTATUS         := '';
      rec_workflow_requestbase.LASTSTATUS            := '';
      rec_workflow_requestbase.ISMULTIPRINT          := '0';
      rec_workflow_requestbase.CHATSTYPE             := '0';
      rec_workflow_requestbase.ECOLOGY_PINYIN_SEARCH := null;
      rec_workflow_requestbase.HRMIDS                := null; --相关人力资源,还不知道怎么处理
      rec_workflow_requestbase.REQUESTNAMENEW        := g_request_name;
      rec_workflow_requestbase.FORMSIGNATUREMD5      := '';
      rec_workflow_requestbase.DATAAGGREGATED        := '';
      rec_workflow_requestbase.SECLEVEL              := '';
      rec_workflow_requestbase.SECDOCID              := '';
      rec_workflow_requestbase.REMINDTYPES           := '';
      rec_workflow_requestbase.LASTFEEDBACKDATE      := '';
      rec_workflow_requestbase.LASTFEEDBACKTIME      := '';
      rec_workflow_requestbase.LASTFEEDBACKOPERATOR  := '';
      rec_workflow_requestbase.REQUESTNAMEHTMLNEW    := '';
      rec_workflow_requestbase.SECVALIDITY           := '';
      rec_workflow_requestbase.SECENCKEY             := '';
      rec_workflow_requestbase.SECCRC                := '';
    
      insert into workflow_requestbase values rec_workflow_requestbase;
    end if;
  exception
    when others then
      x_code := 'E';
      X_MSG  := '写入流程请求基础信息出错';
  end;

  procedure insert_wf_currentoperator(p_node_id         number,
                                      p_last_node_id    number,
                                      p_user_id         number,
                                      p_signorder       number, --
                                      p_nodegroup_dt_id number,
                                      x_code            out varchar2,
                                      x_msg             out varchar2) is
    rec_workflow_currentoperator workflow_currentoperator%rowtype;
    
    cursor c is select * from workflow_currentoperator a where a.requestid = g_request_id and a.nodeid =p_last_node_id 
    and a.isremark not in (8,9)
    and p_signorder in (3,4)
    order by a.operatedate desc , a.operatetime desc 
    ;
  
    --写入已审待审
  begin
    rec_workflow_currentoperator := null;
    --不需要处理字段
    begin
      rec_workflow_currentoperator.id                 := null; --自增
      rec_workflow_currentoperator.groupid            := null; --2
      rec_workflow_currentoperator.isremark_tmp       := null; --
      rec_workflow_currentoperator.isreminded         := null; --
      rec_workflow_currentoperator.isprocessed        := null; --
      rec_workflow_currentoperator.wfreminduser       := null; --
      rec_workflow_currentoperator.wfusertypes        := null; --
      rec_workflow_currentoperator.preisremark_tmp    := null; --
      rec_workflow_currentoperator.needwfback         := null; --0
      rec_workflow_currentoperator.lastisremark       := null; --
      rec_workflow_currentoperator.isreminded_csh     := null; --
      rec_workflow_currentoperator.wfreminduser_csh   := null; --
      rec_workflow_currentoperator.wfusertypes_csh    := null; --
      rec_workflow_currentoperator.handleforwardid    := null; --
      rec_workflow_currentoperator.takisremark        := null; --
      rec_workflow_currentoperator.lastreminddatetime := null; --
      rec_workflow_currentoperator.isprocessing       := null; --
      rec_workflow_currentoperator.opdatetime         := null; --
      rec_workflow_currentoperator.isbereject         := null; --
      rec_workflow_currentoperator.preisremark        := null; --0
      rec_workflow_currentoperator.overtime           := null; --
      rec_workflow_currentoperator.overworktime       := null; --
      rec_workflow_currentoperator.istakout           := null; --
      rec_workflow_currentoperator.takid              := null; --
      rec_workflow_currentoperator.multitaklevel      := null; --      
      rec_workflow_currentoperator.isinmultitak       := null; --
      rec_workflow_currentoperator.operatetype        := null; --
      rec_workflow_currentoperator.forkmark           := null; --
    end;
    
    --日期处理 
    BEGIN
      --NOFORMAT START
      rec_workflow_currentoperator.receivedate   := to_char(g_transaction_date,  'yyyy-mm-dd'); --接收时间
      rec_workflow_currentoperator.receivetime   := to_char(g_transaction_date, 'hh24:mi:ss'); --
      rec_workflow_currentoperator.operatedate   := to_char(g_transaction_date,   'yyyy-mm-dd'); --操作时间 
      rec_workflow_currentoperator.operatetime   := to_char(g_transaction_date, 'hh24:mi:ss'); --
      rec_workflow_currentoperator.viewdate      := to_char(g_transaction_date,  'yyyy-mm-dd'); --最后查看时间
      rec_workflow_currentoperator.viewtime      := to_char(g_transaction_date,  'hh24:mi:ss'); --
      rec_workflow_currentoperator.firstviewdate := to_char(g_transaction_date,  'yyyy-mm-dd'); --第一次查看时间 
      rec_workflow_currentoperator.firstviewtime := to_char(g_transaction_date, 'hh24:mi:ss');
      -- NOFORMAT END 
    END;
  
    --NOFORMAT START
    --工作流
    rec_workflow_currentoperator.requestid    := g_request_id; --
    rec_workflow_currentoperator.workflowid   := g_workflow_id; --1991
    rec_workflow_currentoperator.workflowtype := g_workflow_type; --29
    
    --审批人
    rec_workflow_currentoperator.userid        := p_user_id; --3363
    rec_workflow_currentoperator.usertype      := 0; --0
    rec_workflow_currentoperator.processuser   := p_user_id; --处理人 : 归档时,是由上一节点的人来处理的
    rec_workflow_currentoperator.groupdetailid := p_nodegroup_dt_id; --审批组行ID
    --代理
    rec_workflow_currentoperator.agentorbyagentid := -1; ---不是代理
    rec_workflow_currentoperator.agenttype        := 0; --不是代理
    
    --节点
    rec_workflow_currentoperator.nodeid    := p_node_id; --11715
    rec_workflow_currentoperator.showorder := 0; -- -1 为第一次提交
    
    --状态
    rec_workflow_currentoperator.viewtype    := -2; ---已查看
    rec_workflow_currentoperator.iscomplete := case
                                                 when g_rec_nodebase.isend = 1 then
                                                  1 --1:归档
                                                 else
                                                  0 --0:未归档，
                                               end; 
    rec_workflow_currentoperator.islasttimes := 1; --操作人最后一次操作记录
    rec_workflow_currentoperator.isreject    := 0; --是否退回
    
    --0：未操作 1：转发 2：已操作 4：归档 5：超时 8：抄送(不需提交) 9：抄送(需提交) a: 意见征询 b: 回复 h: 转办 j: 转办提交
    case
      when p_signorder = 3 then
        rec_workflow_currentoperator.isremark := 8;
           when p_signorder = 4 then
        rec_workflow_currentoperator.isremark := 9;
          
      else
        rec_workflow_currentoperator.isremark := case
                                                   when g_rec_nodebase.id =
                                                        p_node_id and
                                                        p_node_id =
                                                        g_start_node_id AND
                                                        p_signorder not in (3, 4) then
                                                    0
                                                   else
                                                    2
                                                 end;
    end case;
    
    --抄送的处理人是上一节点的人 
    for r in c loop 
      rec_workflow_currentoperator.operatedate := r.operatedate;
      rec_workflow_currentoperator.operatetime := r.operatetime;
      rec_workflow_currentoperator.processuser := r.processuser ;
    end loop ;
    
    
    --提交记录处理 
    if p_node_id = g_start_node_id then
      rec_workflow_currentoperator.showorder := -1; ---1 为第一次提交
    end if;
    
    --指定审到开始节点
    if p_node_id = g_start_node_id and p_node_id = g_rec_nodebase.id then
      rec_workflow_currentoperator.groupid := 0; --提交状态,要指定: 赋予每个操作人的标示，但是非会签会都一样是同一个值:这个决定着提交时,会不会更新第一个节点是否已审批,一定要加上.
    
    end if;
    --NOFORMAT END
  
    
  
    insert into workflow_currentoperator
    values rec_workflow_currentoperator;
  
  end;

  procedure update_requestlog(p_request_id number,
                              p_node_id    number,
                              p_user_id    number,
                              
                              x_code out varchar2,
                              x_msg  out varchar2) is
  
  begin
    update workflow_requestlog a
       set a.destnodeid        = p_node_id,
           a.receivedpersons  =
           (select max(b.lastname) from hrmresource b where b.id = p_user_id),
           a.receivedpersonids = p_user_id
     where a.requestid = p_request_id
       and a.destnodeid is null;
  end;

  procedure insert_wf_requestlog(p_node_id         number,
                                 p_last_node_id    number,
                                 p_user_id         number,
                                 p_signorder       number, --
                                 p_nodegroup_dt_id number,
                                 x_code            out varchar2,
                                 x_msg             out varchar2) is
    rec_workflow_requestlog workflow_requestlog%rowtype;
  
    cursor c is
      select *
        from workflow_requestlog a
       where a.requestid = g_request_id
         and a.nodeid = p_last_node_id
         and a.logtype not in ('t')
       order by a.operatedate desc, a.operatetime desc;
  begin
    if p_node_id = g_end_node_id then 
      update_requestlog(g_request_id, p_node_id, g_user_id, x_code, x_msg);
    else 
      update_requestlog(g_request_id, p_node_id, p_user_id, x_code, x_msg);
    end if;
  
    --写入审批意见
    rec_workflow_requestlog := null;
    --不需要处理 
    begin
      rec_workflow_requestlog.remark1            := null; --
      rec_workflow_requestlog.clientip           := null; --10.107.5.52
      rec_workflow_requestlog.logid              := null; --25195
      rec_workflow_requestlog.annexdocids        := null; --
      rec_workflow_requestlog.requestlogid       := null; --0
      rec_workflow_requestlog.operatordept       := null; --775
      rec_workflow_requestlog.signdocids         := null; --
      rec_workflow_requestlog.signworkflowids    := null; --
      rec_workflow_requestlog.handwrittensign    := null; --
      rec_workflow_requestlog.remarklocation     := null; --
      rec_workflow_requestlog.issubmitdirect     := null; --
      rec_workflow_requestlog.remarkquote        := null; --<clob>
      rec_workflow_requestlog.fulltextannotation := null; --
      rec_workflow_requestlog.speechattachmente9 := null; --0
      rec_workflow_requestlog.uuid               := null; --
      rec_workflow_requestlog.operatorsub        := null; --521
      rec_workflow_requestlog.operatorjob        := null; --21
      rec_workflow_requestlog.isrobotnode        := null; --
      rec_workflow_requestlog.seclevel           := null; --
      rec_workflow_requestlog.receivedpersons_1  := null; --
      --是否是代理                                     
      rec_workflow_requestlog.agentorbyagentid := -1; ---1
      rec_workflow_requestlog.agenttype        := 0; --0
    
      rec_workflow_requestlog.ismobile         := 'd'; --d
      rec_workflow_requestlog.speechattachment := 0; --语音附件
    end;
  
    --审批流
    rec_workflow_requestlog.requestid  := g_request_id; --28660
    rec_workflow_requestlog.workflowid := g_workflow_id; --2020
    rec_workflow_requestlog.nodeid     := p_node_id; --12089
  
    --人员
    rec_workflow_requestlog.operator     := p_user_id; --3341
    rec_workflow_requestlog.operatortype := 0; --0
  
    --日期
    rec_workflow_requestlog.operatedate := to_char(g_transaction_date,
                                                   'yyyy-mm-dd'); --44075
    rec_workflow_requestlog.operatetime := to_char(g_transaction_date,
                                                   'hh24:mi:ss'); --0.558576388888889
  
    --0：批准 1：保存 2：提交 3：退回 4：重新打开 5：删除 6：激活 7：转发 9：批注 a：意见征询 b：意见征询回复 e：强制归档 h：转办 i：干预 j：转办反馈 s：督办 t：抄送  r:撤回 
    if p_signorder in (3, 4) then
      rec_workflow_requestlog.logtype    := 't';
      rec_workflow_requestlog.nodeid     := p_last_node_id; --上一节点发起
      rec_workflow_requestlog.destnodeid := p_node_id; --本节点收到
      rec_workflow_requestlog.operator   := null; -- 上一节点的人操作的
    
      --抄送由上一节点的人做 
      for r in c loop
        rec_workflow_requestlog.operator    := r.operator;
        rec_workflow_requestlog.operatedate := r.operatedate;
        rec_workflow_requestlog.operatetime := r.operatetime;
        rec_workflow_requestlog.receivedpersonids := p_user_id ||'';
        
        select max(a.lastname) into rec_workflow_requestlog.receivedpersons from hrmresource a where a.id = p_user_id ;
      
        exit;
      end loop;
    
    else
      rec_workflow_requestlog.logtype := case
                                           when p_node_id = g_start_node_id and
                                                p_node_id <> g_rec_nodebase.id then
                                            2
                                           when p_node_id = g_start_node_id and
                                                p_node_id = g_rec_nodebase.id then
                                            1
                                           else
                                            0
                                         end;
    end if;
    rec_workflow_requestlog.showorder := case
                                           when p_node_id = g_start_node_id then
                                            -1
                                           else
                                            1
                                         end; --1
  
    --出口节点,待处理 
    begin
      null; --通过找到出口条件后做更新 
      /* rec_workflow_requestlog.destnodeid := case
                                              when p_node_id =
                                                   g_start_node_id and
                                                   p_node_id =
                                                   rec_workflow_nodebase.id then
                                               p_node_id
                                              when l_loop_user <> l_user_num then
                                               p_node_id
                                              else
                                               null ; -- l_nextnode_id
                                            end; --12016 
      rec_workflow_requestlog.receivedpersons := case
                                                   when l_loop_user <>
                                                        l_user_num then
                                                    regexp_substr(l_currentnode_users,
                                                                  '[^,]+',
                                                                  1,
                                                                  l_loop_user + 1)
                                                   else
                                                    l_nextnode_users
                                                 end; -- 接收人中文显示
      rec_workflow_requestlog.receivedpersonids := case
                                                     when l_loop_user <>
                                                          l_user_num then
                                                      regexp_substr(l_user_ids,
                                                                    '[^,]+',
                                                                    1,
                                                                    l_loop_user + 1)
                                                     else
                                                      l_next_nodeuser_ids
                                                   end; --接收人ID*/
      null;
    end;
  
    rec_workflow_requestlog.remark := '后台自动写入'; --<clob>
  
    select a.subcompanyid1, a.jobtitle, a.departmentid
      into rec_workflow_requestlog.operatorsub,
           rec_workflow_requestlog.operatorjob,
           rec_workflow_requestlog.operatordept
      from hrmresource a
     where a.id = rec_workflow_requestlog.operator
    
    ;
  
    --指定到开始节点时,还没审批
    if p_node_id = g_start_node_id and p_node_id = g_rec_nodebase.id then
      rec_workflow_requestlog.remark := null;
    end if;
  
    insert into workflow_requestlog values rec_workflow_requestlog;
    -- end if;
  
  end;
  procedure approve_by_user(p_node_id         number,
                            p_last_node_id    number,
                            p_user_id         number,
                            p_signorder       number, --
                            p_nodegroup_dt_id number,
                            x_code            out varchar2,
                            x_msg             out varchar2) is
  begin
    insert_wf_currentoperator(p_node_id,
                              p_last_node_id,
                              p_user_id,
                              p_signorder, --
                              p_nodegroup_dt_id,
                              x_code,
                              x_msg);
  
    insert_wf_requestlog(p_node_id,
                         p_last_node_id,
                         p_user_id,
                         p_signorder, --
                         p_nodegroup_dt_id,
                         x_code,
                         x_msg);
  
  end;

  /*
  节点审批人组进行审批操作
  
  如果是汇合节点,后边再添加判断,最后汇合时再做审批即可
  */
  procedure approve_by_user(p_node_id      number,
                            p_last_node_id number,
                            x_code         out varchar2,
                            x_msg          out varchar2) is
    cursor c is
      select b.id, b.type, b.signorder
        from workflow_nodegroup a, workflow_groupdetail b
       where a.id = b.groupid
         and a.nodeid = p_node_id;
  
    cursor c1(p_id number) is
      select a.objid, a.groupdetailid, b.lastname
        from workflow_hrmoperator a, hrmresource b
       where a.groupdetailid = p_id
         and a.objid = b.id;
  begin
    if p_node_id = g_start_node_id then
      approve_by_user(p_node_id,
                      p_last_node_id,
                      g_user_id,
                      null,
                      null,
                      x_code,
                      x_msg);
      return;
    end if;
  
    for r in c loop
      g_transaction_date := g_transaction_date + 1 / 24 / 60 / 60;
      --不是直接指定的人,暂时未处理 
      if r.type not in (3, 17) then
        -- x_code := 'E';
        -- x_msg  := '此节点的审批人不是直接指定人员的,目前程序未处理 ,待拓展';
        -- return;
        continue;
      end if;
    
      --指定人的
      for r1 in c1(r.id) loop
        --已到了指定节点的下一节点,只用更改指定节点的下一节点和接收人即可.
        if p_node_id = g_out_node_id then
          update_requestlog(g_request_id,
                            p_node_id,
                            r1.objid,
                            x_code,
                            x_msg);
          return;
        end if;
      
        approve_by_user(p_node_id,
                        p_last_node_id,
                        r1.objid,
                        r.signorder,
                        r.id,
                        x_code,
                        x_msg);
      
        if x_code = 'E' then
          return;
        end if;
      
      end loop;
    
      --指定创建者本人
      if r.type = 17 then
        /*x_user_num    := x_user_num + 1;
        x_user_ids    := x_user_ids || -1 || ',';
        x_groupdt_ids := x_groupdt_ids || r.id || ',';
        x_usernames   := x_usernames || '创建者本人' || ',';
        x_signtypes   := x_signtypes || r.signorder || ',';*/
        --已到了指定节点的下一节点,只用更改指定节点的下一节点和接收人即可.
        if p_node_id = g_out_node_id then
          update_requestlog(g_request_id,
                            p_node_id,
                            g_user_id,
                            x_code,
                            x_msg);
          return;
        end if;
      
        approve_by_user(p_node_id,
                        p_last_node_id,
                        g_user_id,
                        r.signorder,
                        r.id,
                        x_code,
                        x_msg);
        null;
      end if;
    
    end loop;
  end;

  /*
  通过指定节点,开始递归审批
  
  如果有两个节点A,B都审批了以后才能到C的, 这个情况还没有处理 ,以后发生了再对C进行处理 ,
  处理方法 : 从开始节点写入LOG后, 以后每次循环LOG表,找到下一节点(目标节点为空的),一直到目标节点
  */
  procedure p_approve(p_workflow_id   number,
                      p_node_id       number,
                      p_nodelink_name varchar2,
                      p_last_node_id  number, --上一节点ID
                      x_code          out varchar2,
                      x_msg           out varchar2) is
  
    cursor c is
      select a.id, a.destnodeid, a.linkname
        from workflow_nodelink a
       where a.nodeid = p_node_id
         and a.workflowid = p_workflow_id;
  
    l_pass_flag varchar2(2) := 'N'; --是否满足出口条件
  begin
  
    approve_by_user(p_node_id, p_last_node_id, x_code, x_msg);
    if x_code = 'E' then
      return;
    end if;
  
    for r in c loop
      --是否满足出口条件
      check_nodelink(r.id, l_pass_flag, x_code, x_msg);
      if l_pass_flag = 'N' then
        continue;
      end if;
      if x_code = 'E' then
        return;
      end if;
    
      --更新流程请求表信息数据
      process_requestbase(p_node_id, p_nodelink_name, x_code, x_msg);
      if x_code = 'E' then
        return;
      end if;
    
      dbms_output.put_line(p_node_id || '-->' || r.destnodeid);
      p_approve(p_workflow_id,
                r.destnodeid,
                r.linkname,
                p_node_id,
                x_code,
                x_msg);
    
      if x_code = 'E' then
        return;
      end if;
    
      --到了指定节点
      if p_node_id = g_rec_nodebase.id and g_out_node_id = 0 then
        g_out_node_id := r.destnodeid;
      end if;
    
    end loop;
  
  end;

  /*
  获得工作流的开始节点
  */
  procedure get_start_node_id(x_code out varchar2, x_msg out varchar2) is
  
  begin
    select a.nodeid
      into g_start_node_id
      from workflow_flownode a, workflow_nodebase b
     where a.nodeid = b.id
       and b.isstart = 1
       and a.workflowid = g_workflow_id;
  
  exception
    when others then
      x_code := 'E';
      x_msg  := '获取工作流开始节点出错' || substr(sqlerrm, 1, 1000);
  end;
  
  /*
  获得工作流的开始节点
  */
  procedure get_end_node_id(x_code out varchar2, x_msg out varchar2) is
  
  begin
    select a.nodeid
      into g_end_node_id
      from workflow_flownode a, workflow_nodebase b
     where a.nodeid = b.id
       and b.isend = 1
       and a.workflowid = g_workflow_id;
  
  exception
    when others then
      x_code := 'E';
      x_msg  := '获取工作流开始节点出错' || substr(sqlerrm, 1, 1000);
  end;

  /*
    
      Start
        |
        
    p_approve
        |
        
  approve_by_user
     /      \
            
  insert_wf_currentoperator    insert_wf_requestlog
          |                       |
                                 
   Insert operation      update_requestlog
                              |
                              
                      Insert log record  
    */
  procedure main(p_workflow_name    varchar2, --流程表单名称
                 p_request_id       number, --流程请求ID
                 p_request_name     varchar2, --请求名称
                 p_current_nodename varchar2, --当前节点名称
                 p_user_name        varchar2, --操作用户
                 p_transaction_date date, --操作时间 
                 x_code             out varchar2, --返回代码
                 x_msg              out varchar2 --返回信息
                 ) is
  
    --出口条件
    cursor c is
      select * from workflow_nodelink a where a.workflowid = g_workflow_id;
  
  begin
    g_workflow_name    := p_workflow_name;
    g_request_id       := p_request_id;
    g_request_name     := p_request_name;
    g_transaction_date := p_transaction_date;
  
    --1. 数据校验
    begin
      --1.1 确认流程表单的有效性
      begin
        check_workflow_info(x_code, x_msg);
        if x_code = 'E' then
          return;
        end if;
      
      end;
    
      --1.2 确认表单数据已写入
      begin
        check_billtable_info(x_code, x_msg);
        if x_code = 'E' then
          return;
        end if;
      
      end;
    
      --1.3 确认流水号没有被使用
      begin
        select 1
          into g_temp
          from workflow_requestbase a
         where a.requestid = p_request_id;
      
        x_code := 'E';
        x_msg  := '此请求ID已被使用：' || p_request_id;
        return;
      
      exception
        when others then
          null;
        
      end;
    
      --1.4 确认节点存在
      begin
        get_nodeinfo(p_current_nodename, x_code, x_msg);
      
        if x_code = 'E' then
          return;
        end if;
      end;
    
      --1.5 获得用户id
      begin
        select a.id, a.lastname
          into g_user_id, g_user_name
          from hrmresource a
         where a.workcode = p_user_name
            or a.lastname = p_user_name;
      exception
        when others then
          x_code := 'E';
          x_msg  := '不存在用户：' || p_user_name;
          return;
      end;
    end;
  
    --3 获得开始节点
    begin
      get_start_node_id(x_code, x_msg);
      if x_code = 'E' then
        return;
      end if;
    end;
    
    begin
      get_end_node_id(x_code, x_msg);
      if x_code = 'E' then
        return;
      end if;
    end;
  
    --2. 执行审批
    p_approve(g_workflow_id, g_start_node_id, '', '', x_code, x_msg);
  
    --3. 提交或回滚事务
    if x_code = 'E' then
      rollback;
    end if;
  
  end;

  function get_request_id return number is
  
  begin
    return cux_requestid_s.nextval;
  end;

  /*
  test1 : 
  OA表单：销售出货报表需求单，物料产品类别和终端维护表名：CUX_NEW_ENERGY_ITEM_T
  */
  procedure test1(p_nodename varchar2) is
    l_request_id number := get_request_id;
    l_code       varchar2(2000);
    l_msg        varchar2(2000);
  begin
    insert into formtable_main_3493
      (id, requestid, lxdh, lcbh, fj, xqms, bbmc, xm, gh)
    values
      (null,
       l_request_id,
       '13312345678',
       null,
       null,
       '测试',
       0,
       '张三',
       'A001');
  
    main(p_workflow_name    => '销售出货报表需求单', --流程表单名称
         p_request_id       => l_request_id, --流程请求ID
         p_request_name     => '测试: ' || l_request_id || '--' ||
                               to_char(sysdate, 'yyyymmdd hh24:mi:ss'), --请求名称
         p_current_nodename => nvl(p_nodename, '应用主管审批'), --当前节点名称
         p_user_name        => 'A0091778', --操作用户
         p_transaction_date => sysdate, --操作时间 
         x_code             => l_code, --返回代码
         x_msg              => l_msg --返回信息
         );
  
    dbms_output.put_line(l_request_id);
    dbms_output.put_line(l_code || ':' || l_msg);
  end;

end cux_create_doc_pkg2;
/

