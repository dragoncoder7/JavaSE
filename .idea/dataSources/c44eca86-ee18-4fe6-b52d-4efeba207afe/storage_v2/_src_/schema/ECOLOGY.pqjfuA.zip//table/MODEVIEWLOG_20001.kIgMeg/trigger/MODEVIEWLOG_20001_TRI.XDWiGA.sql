create trigger MODEVIEWLOG_20001_TRI
    before insert
    on MODEVIEWLOG_20001
    for each row
begin   select ModeViewLog_20001_id.nextval into :new.id from dual;   end;
/

