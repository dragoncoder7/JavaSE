create trigger DESK_TOP_TRI
    before insert
    on USERCOMMONMENUDESKTOP
    for each row
begin select Desk_Top_id.nextval into :new.id from dual; end;
/

