create trigger DOCHTMLHIS_ID_TRIGGER
    before insert
    on DOCPREVIEWHTMLHISTORY
    for each row
begin select DocHtmlHis_id.nextval into :new.id from dual; end;
/

