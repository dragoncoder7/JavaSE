create trigger PRJ_TSKCARDTAB_TRIGGER
    before insert
    on PRJ_TSKCARDTAB
    for each row
begin select prj_tskcardtab_ID.nextval into :new.id from dual; end;
/

