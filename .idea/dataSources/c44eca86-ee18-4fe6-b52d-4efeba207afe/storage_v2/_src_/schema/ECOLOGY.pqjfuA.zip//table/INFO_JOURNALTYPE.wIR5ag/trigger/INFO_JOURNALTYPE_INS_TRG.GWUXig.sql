create trigger INFO_JOURNALTYPE_INS_TRG
    before insert
    on INFO_JOURNALTYPE
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT info_journaltype_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

