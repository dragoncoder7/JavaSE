create PROCEDURE CptCapital_HandBackSelect ( resourceid_1	integer, managerid_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select * from CptCapital where isdata = '2' and resourceid = resourceid_1 and datatype in (select id from CptCapital where isdata = '1' and resourceid = managerid_1); end;


/

