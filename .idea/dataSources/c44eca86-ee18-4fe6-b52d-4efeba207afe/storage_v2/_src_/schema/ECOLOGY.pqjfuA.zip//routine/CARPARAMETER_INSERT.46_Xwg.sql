create PROCEDURE CarParameter_Insert (name_1 		varchar2, paravalue_2     number, description_3   varchar2, flag out integer , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor	) AS begin insert into CarParameter(name,description,paravalue) values (name_1,description_3,paravalue_2); end;


/

