create trigger WORKFLOW_MGMS_TRI
    before insert
    on WORKFLOW_MGMS
    for each row
begin select workflow_mgms_id.nextval into :new.id from dual; end;
/

