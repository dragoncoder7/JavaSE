create trigger MEETING_TRIGGER
    before insert
    on MEETING
    for each row
begin select Meeting_id.nextval into :new.id from dual; end ;
/

