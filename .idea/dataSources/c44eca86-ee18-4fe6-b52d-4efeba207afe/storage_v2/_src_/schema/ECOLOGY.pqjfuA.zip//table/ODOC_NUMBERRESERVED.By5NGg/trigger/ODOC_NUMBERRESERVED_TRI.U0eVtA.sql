create trigger ODOC_NUMBERRESERVED_TRI
    before insert
    on ODOC_NUMBERRESERVED
    for each row
begin select odoc_numberReserved_id.nextval into:new.id from dual; end;
/

