create trigger MODE_REMINDDATA_LOG_ID_TRI
    before insert
    on MODE_REMINDDATA_LOG
    for each row
begin select mode_reminddata_log_id.nextval into :new.id from dual; end;
/

