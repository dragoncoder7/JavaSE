create trigger BILL_HRMHIRE_TRIGGER
    before insert
    on BILL_HRMHIRE
    for each row
begin select Bill_HrmHire_id.nextval INTO :new.id from dual; end;
/

