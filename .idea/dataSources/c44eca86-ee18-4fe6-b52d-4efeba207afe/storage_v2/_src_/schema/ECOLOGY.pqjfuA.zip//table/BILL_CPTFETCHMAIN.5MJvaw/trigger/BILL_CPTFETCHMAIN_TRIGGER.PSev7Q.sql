create trigger BILL_CPTFETCHMAIN_TRIGGER
    before insert
    on BILL_CPTFETCHMAIN
    for each row
begin select bill_CptFetchMain_id.nextval INTO :new.id from dual; end;
/

