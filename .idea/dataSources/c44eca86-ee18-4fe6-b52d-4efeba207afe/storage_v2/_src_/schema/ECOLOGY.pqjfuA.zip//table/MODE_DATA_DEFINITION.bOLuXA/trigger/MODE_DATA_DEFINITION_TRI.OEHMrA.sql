create trigger MODE_DATA_DEFINITION_TRI
    before insert
    on MODE_DATA_DEFINITION
    for each row
begin   select mode_data_definition_id.nextval into :new.id from dual; end;
/

