create trigger HRMTRAINPLANDAY_TRIGGER
    before insert
    on HRMTRAINPLANDAY
    for each row
begin select HrmTrainPlanDay_id.nextval into :new.id from dual; end;
/

