create PROCEDURE CRM_CustomerAddress_Select (tid_1 	integer, cid_1 	integer,  flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT * FROM CRM_CustomerAddress WHERE (typeid = tid_1) AND (customerid = cid_1); end;


/

