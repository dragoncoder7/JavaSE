create trigger MODE_STARTCODE_TRI
    before insert
    on MODE_STARTCODE
    for each row
begin   select mode_startcode_id.nextval into :new.id from dual; end;
/

