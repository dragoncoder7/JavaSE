create PROCEDURE CRM_Find_CustomerContacter (id_1	int, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT id,title,fullname,jobtitle FROM CRM_CustomerContacter WHERE (customerid = id_1) ORDER BY main DESC,fullname ASC ; end;


/

