create PROCEDURE bill_HrmFinance_UpdateStatus (id1		integer, status1	char , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin update bill_hrmfinance set status=status1 where id=id1; end;


/

