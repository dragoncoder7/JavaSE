create trigger MODE_EXPANGROUP_ID_TRI
    before insert
    on MODE_EXPANGROUP
    for each row
begin select mode_expangroup_id.nextval into :new.id from dual; end;
/

