create trigger FNAINVOICECT_TRI
    before insert
    on FNAINVOICEFIELDCONSTTYPE
    for each row
begin select seq_fnaInvoiceFieldConstType.nextval into :new.id from dual; end;
/

