create PROCEDURE bill_CptRequireDetail_Select (cptrequireid1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin open thecursor for SELECT * from  bill_CptRequireDetail WHERE ( cptrequireid	 = cptrequireid1); end;


/

