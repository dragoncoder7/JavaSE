create trigger CRM_CONTRACT_EXCHANGE_TRIGGER
    before insert
    on CRM_CONTRACT_EXCHANGE
    for each row
begin select CRM_Contract_Exchange_id.nextval into :new.id from dual; end;
/

