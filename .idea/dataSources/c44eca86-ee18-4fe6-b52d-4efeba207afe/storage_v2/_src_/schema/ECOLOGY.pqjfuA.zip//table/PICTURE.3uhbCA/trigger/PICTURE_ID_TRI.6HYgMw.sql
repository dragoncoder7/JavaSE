create trigger PICTURE_ID_TRI
    before insert
    on PICTURE
    for each row
begin select picture_Id.nextval into :new.id from dual; end;
/

