create trigger COWORKBASESET_TRIGGER
    before insert
    on COWORK_BASE_SET
    for each row
begin select coworkbaseset_seq.nextval into:new.id from sys.dual; end;
/

