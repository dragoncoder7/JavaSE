create trigger DOCSECCATEGORYCODERSEQ_TRI
    before insert
    on DOCSECCATEGORYCODERSEQ
    for each row
begin select DocSecCategoryCoderSeq_Id.nextval into :new.id from dual; end;
/

