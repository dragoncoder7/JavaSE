create trigger WR_YEARINVENTORY_DLOG_TRI
    before insert
    on WR_YEARINVENTORY_DETAILLOG
    for each row
begin select WR_YearInventory_DLog_SEQ.nextval into :new.id from dual; end;
/

