create trigger BILL_DISCARD_DETAIL_ID_TRIGGER
    before insert
    on BILL_DISCARD_DETAIL
    for each row
begin select bill_Discard_Detail_Id.nextval into :new.id from dual; end;
/

