create trigger PRJ_FEEDBACK_TRIGGER
    before insert
    on PRJ_FEEDBACK
    for each row
begin select prj_feedback_SEQ.nextval into :new.id from dual; end ;
/

