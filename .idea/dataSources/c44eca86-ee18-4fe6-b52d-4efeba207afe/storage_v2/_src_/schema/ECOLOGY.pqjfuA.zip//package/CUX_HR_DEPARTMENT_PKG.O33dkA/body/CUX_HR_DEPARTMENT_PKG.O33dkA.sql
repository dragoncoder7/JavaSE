create package body cux_hr_department_PKG is

  /*
  当表hrmdepartment有新增或修改时，调用此存储过程，把部门上下级结构完成展开
  */
  procedure do_change(p_type    varchar2,
                      p_new_rec hrmdepartment%rowtype,
                      p_old_rec hrmdepartment%rowtype) is
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_old_name_path varchar2(2000);
    l_old_id_path   varchar2(2000);
    l_new_name_path varchar2(2000);
    l_new_id_path   varchar2(2000);
  begin
    --新增 
    if p_type = 'NEW' then
      insert into cux_hr_department_t(department_id,
                                      department_id_path,
                                      department_name_path,
                                      subcompanyid1,
                                      departmentcode,
                                      departmentname)
        SELECT dep.id,
               SYS_CONNECT_BY_PATH(id, ',') id_path,
               SYS_CONNECT_BY_PATH(dep.departmentname, ',') name_path,
               p_new_rec.subcompanyid1,
               p_new_rec.departmentcode,
               p_new_rec.departmentname
          FROM hrmdepartment DEP
         where DEP.id = p_new_rec.Id
         START WITH DEP.supdepid = 0
        CONNECT BY PRIOR DEP.id = DEP.supdepid;
    end if;
  
    --修改
    if p_type = 'MOD' AND P_NEW_REC.SUPDEPID <> p_new_rec.Supdepid then
      --找到父级路径
      select max(case
                   when a.department_id = p_old_rec.supdepid then
                    a.department_name_path
                   else
                    null
                 end) || ',' || p_old_rec.departmentname,
             max(case
                   when a.department_id = p_old_rec.supdepid then
                    a.department_id_path
                   else
                    null
                 end) || ',' || p_new_rec.id,
             max(case
                   when a.department_id = p_new_rec.supdepid then
                    a.department_name_path
                   else
                    null
                 end) || ',' || p_new_rec.departmentname,
             max(case
                   when a.department_id = p_new_rec.supdepid then
                    a.department_id_path
                   else
                    null
                 end) || ',' || p_new_rec.id
        into l_old_name_path, l_old_id_path, l_new_name_path, l_new_id_path
        from cux_hr_department_t a
       where a.department_id in (p_old_rec.SUPDEPID, p_new_rec.Supdepid);
    
      --把所以旧路径改为新路径
      update cux_hr_department_t a
         set a.department_id_path   = replace(a.department_id_path,
                                              l_old_id_path,
                                              l_new_id_path),
             a.department_name_path = replace(a.department_name_path,
                                              l_old_name_path,
                                              l_new_name_path)
       where a.department_id_path like l_old_id_path || '%';
    
    end if;
  
    commit;
  exception
    when others then
      rollback;
  end;
end cux_hr_department_PKG;
/

