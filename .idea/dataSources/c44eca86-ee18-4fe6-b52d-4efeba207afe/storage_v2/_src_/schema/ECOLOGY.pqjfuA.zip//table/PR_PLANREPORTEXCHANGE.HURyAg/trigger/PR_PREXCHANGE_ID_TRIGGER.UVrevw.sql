create trigger PR_PREXCHANGE_ID_TRIGGER
    before insert
    on PR_PLANREPORTEXCHANGE
    for each row
begin select PR_PlanReportExchange_id.nextval into :new.id from dual; end;
/

