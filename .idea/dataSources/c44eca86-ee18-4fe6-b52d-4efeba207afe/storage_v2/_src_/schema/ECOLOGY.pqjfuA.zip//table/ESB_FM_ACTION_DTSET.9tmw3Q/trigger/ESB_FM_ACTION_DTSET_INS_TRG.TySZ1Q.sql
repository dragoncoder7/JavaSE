create trigger ESB_FM_ACTION_DTSET_INS_TRG
    before insert
    on ESB_FM_ACTION_DTSET
    for each row
    when (NEW.id IS NULL)
BEGIN SELECT esb_fm_action_dtset_id_SEQ.NEXTVAL INTO :NEW.id FROM DUAL; END;
/

