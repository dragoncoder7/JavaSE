create trigger HRMLANGUAGEABILITY_TRIGGER
    before insert
    on HRMLANGUAGEABILITY
    for each row
begin select HrmLanguageAbility_id.nextval into :new.id from dual; end;
/

