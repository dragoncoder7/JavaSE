create trigger INFO_REWARD_DETAIL_INS_TRG
    before insert
    on INFO_REWARD_DETAIL
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT info_reward_detail_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

