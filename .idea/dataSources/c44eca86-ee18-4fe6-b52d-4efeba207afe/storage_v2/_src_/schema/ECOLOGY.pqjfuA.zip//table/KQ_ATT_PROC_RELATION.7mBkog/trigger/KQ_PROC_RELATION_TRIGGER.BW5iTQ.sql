create trigger KQ_PROC_RELATION_TRIGGER
    before insert
    on KQ_ATT_PROC_RELATION
    for each row
begin select kq_att_proc_relation_id.nextval into :new.id from dual; end;
/

