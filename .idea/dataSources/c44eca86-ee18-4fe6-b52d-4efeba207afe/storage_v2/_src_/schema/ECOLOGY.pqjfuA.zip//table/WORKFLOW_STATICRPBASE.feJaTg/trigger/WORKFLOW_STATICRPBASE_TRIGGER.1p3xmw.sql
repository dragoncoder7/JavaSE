create trigger WORKFLOW_STATICRPBASE_TRIGGER
    before insert
    on WORKFLOW_STATICRPBASE
    for each row
begin select workflow_StaticRpbase_id.nextval INTO :new.id from dual; end;
/

