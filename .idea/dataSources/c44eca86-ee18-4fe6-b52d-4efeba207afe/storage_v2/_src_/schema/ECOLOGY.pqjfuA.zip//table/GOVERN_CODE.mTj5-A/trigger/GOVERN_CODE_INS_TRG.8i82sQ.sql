create trigger GOVERN_CODE_INS_TRG
    before insert
    on GOVERN_CODE
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT govern_code_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

