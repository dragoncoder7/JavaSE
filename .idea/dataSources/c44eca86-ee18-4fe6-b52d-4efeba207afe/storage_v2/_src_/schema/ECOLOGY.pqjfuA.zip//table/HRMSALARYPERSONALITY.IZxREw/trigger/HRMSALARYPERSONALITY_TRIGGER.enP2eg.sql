create trigger HRMSALARYPERSONALITY_TRIGGER
    before insert
    on HRMSALARYPERSONALITY
    for each row
begin select HrmSalaryPersonality_id.nextval into :new.id from dual; end;
/

