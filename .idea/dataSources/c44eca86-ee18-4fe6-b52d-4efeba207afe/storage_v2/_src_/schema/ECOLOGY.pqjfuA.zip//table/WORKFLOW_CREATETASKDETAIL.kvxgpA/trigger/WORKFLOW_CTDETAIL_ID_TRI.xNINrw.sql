create trigger WORKFLOW_CTDETAIL_ID_TRI
    before insert
    on WORKFLOW_CREATETASKDETAIL
    for each row
begin select workflow_createtaskdetail_id.nextval into :new.id from dual; end;
/

