create trigger DATACENTERUSER_ID_TRIGGER
    before insert
    on T_DATACENTERUSER
    for each row
begin select datacenterUser_Id.nextval into :new.id from dual; end;
/

