create PROCEDURE CptStockInDetail_Update ( id_1 integer , innumber_1 number, flag	out integer, msg   out	varchar2, thecursor IN OUT cursor_define.weavercursor )  AS begin update CptStockInDetail set  innumber=innumber_1  where id = id_1; end;


/

