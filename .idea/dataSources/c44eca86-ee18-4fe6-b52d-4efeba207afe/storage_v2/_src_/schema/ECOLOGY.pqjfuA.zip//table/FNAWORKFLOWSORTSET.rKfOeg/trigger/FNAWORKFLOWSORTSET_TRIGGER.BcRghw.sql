create trigger FNAWORKFLOWSORTSET_TRIGGER
    before insert
    on FNAWORKFLOWSORTSET
    for each row
begin select seq_fnaWorkflowSortSet.nextval into :new.id from dual; end;
/

