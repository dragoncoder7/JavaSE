create trigger FORMTABLE_MAIN_3510_ID_TR
    before insert
    on FORMTABLE_MAIN_3510
    for each row
begin select formtable_main_3510_Id.nextval into :new.id from dual;  end;
/

