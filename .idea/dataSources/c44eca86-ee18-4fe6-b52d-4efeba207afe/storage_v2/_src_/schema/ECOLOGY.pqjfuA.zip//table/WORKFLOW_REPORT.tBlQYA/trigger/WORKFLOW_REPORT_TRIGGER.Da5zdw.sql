create trigger WORKFLOW_REPORT_TRIGGER
    before insert
    on WORKFLOW_REPORT
    for each row
begin select Workflow_Report_id.nextval INTO :new.id from dual; end;
/

