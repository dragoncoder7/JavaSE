create PROCEDURE Bill_ExpenseDetail_Delete (expenseid_1 	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE Bill_ExpenseDetail  WHERE ( expenseid	 = expenseid_1) ; end;


/

