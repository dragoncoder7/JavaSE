create trigger ODOC_SUPERVISEDELAY_TRIGGER
    before insert
    on ODOC_SUPERVISEDELAY
    for each row
begin select odoc_supervisedelay_seq.nextval into :new.id from dual; end;
/

