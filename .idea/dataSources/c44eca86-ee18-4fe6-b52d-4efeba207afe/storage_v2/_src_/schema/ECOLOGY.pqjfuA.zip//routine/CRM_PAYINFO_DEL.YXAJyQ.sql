create PROCEDURE CRM_PayInfo_del ( id_1		integer, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin delete from CRM_PayInfo WHERE id =id_1; end;


/

