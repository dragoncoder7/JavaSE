create trigger HRMSALARYTAXBENCH_TRIGGER
    before insert
    on HRMSALARYTAXBENCH
    for each row
begin select HrmSalaryTaxbench_id.nextval into :new.id from dual; end;
/

