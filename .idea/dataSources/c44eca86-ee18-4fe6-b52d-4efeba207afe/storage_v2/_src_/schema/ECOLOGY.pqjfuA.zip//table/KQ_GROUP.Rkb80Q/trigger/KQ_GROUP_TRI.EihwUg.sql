create trigger KQ_GROUP_TRI
    before insert
    on KQ_GROUP
    for each row
begin select kq_group_id.nextval into :new.id from dual; end;
/

