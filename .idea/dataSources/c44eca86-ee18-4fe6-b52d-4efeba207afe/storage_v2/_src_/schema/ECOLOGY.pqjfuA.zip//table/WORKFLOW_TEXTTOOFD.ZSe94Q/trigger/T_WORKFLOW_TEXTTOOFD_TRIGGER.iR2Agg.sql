create trigger T_WORKFLOW_TEXTTOOFD_TRIGGER
    before insert
    on WORKFLOW_TEXTTOOFD
    for each row
begin select t_workflow_texttoofd_seq.nextval into:NEW.ID from dual; end;
/

