create trigger ODOC_NODE_CONFIG_INSERT
    before insert
    on ODOC_NODE_CONFIG
    for each row
declare begin select odoc_node_config_id_seq.nextval into :new.ID from dual; end odoc_node_config_insert;
/

