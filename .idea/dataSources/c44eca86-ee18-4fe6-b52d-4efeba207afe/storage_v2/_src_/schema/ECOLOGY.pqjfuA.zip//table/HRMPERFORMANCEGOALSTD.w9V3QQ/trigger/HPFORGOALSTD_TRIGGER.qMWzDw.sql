create trigger HPFORGOALSTD_TRIGGER
    before insert
    on HRMPERFORMANCEGOALSTD
    for each row
begin select HPforGoalStd_id.nextval into :new.id from dual; end;
/

