create trigger APPFORMUI_TRI
    before insert
    on APPFORMUI
    for each row
begin select AppFormUI_id.nextval into :new.id from dual; end;
/

