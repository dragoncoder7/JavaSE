create trigger PRJDEFINEFIELD_TRIGGER
    before insert
    on PRJDEFINEFIELD
    for each row
begin select prjDefineField_ID.nextval into :new.id from dual; end;
/

