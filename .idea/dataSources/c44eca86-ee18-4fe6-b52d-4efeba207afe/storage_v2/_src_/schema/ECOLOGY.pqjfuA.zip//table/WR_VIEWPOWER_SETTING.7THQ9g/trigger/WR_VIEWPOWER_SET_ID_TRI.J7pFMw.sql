create trigger WR_VIEWPOWER_SET_ID_TRI
    before insert
    on WR_VIEWPOWER_SETTING
    for each row
begin select WR_ViewPower_Setting_SEQ.nextval into :new.id from dual; end;
/

