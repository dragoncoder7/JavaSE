create trigger WORKFLOWFWOPERADVANCED_ID_TRI
    before insert
    on WORKFLOW_FWOPERADVANCED
    for each row
begin select workflowFwOperAdvanced_id.nextval into :new.id from dual; end ;
/

