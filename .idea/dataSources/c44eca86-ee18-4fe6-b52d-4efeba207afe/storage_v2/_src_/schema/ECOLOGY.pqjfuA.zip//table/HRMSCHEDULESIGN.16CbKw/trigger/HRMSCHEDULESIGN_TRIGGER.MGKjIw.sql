create trigger HRMSCHEDULESIGN_TRIGGER
    before insert
    on HRMSCHEDULESIGN
    for each row
begin select HrmScheduleSign_id.nextval into :new.id from dual; end;
/

