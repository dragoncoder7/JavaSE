create trigger WORKFLOW_HQSEALDOC_ID_TRI
    before insert
    on WORKFLOW_HQSEALDOC
    for each row
begin select workflow_hqsealdoc_id.nextval into :new.id from dual; end;
/

