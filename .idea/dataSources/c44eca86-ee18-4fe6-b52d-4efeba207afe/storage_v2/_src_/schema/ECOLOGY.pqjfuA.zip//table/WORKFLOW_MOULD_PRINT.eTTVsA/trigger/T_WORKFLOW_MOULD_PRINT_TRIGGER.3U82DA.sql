create trigger T_WORKFLOW_MOULD_PRINT_TRIGGER
    before insert
    on WORKFLOW_MOULD_PRINT
    for each row
begin select t_WORKFLOW_MOULD_PRINT_seq.nextval into:NEW.ID from dual; end;
/

