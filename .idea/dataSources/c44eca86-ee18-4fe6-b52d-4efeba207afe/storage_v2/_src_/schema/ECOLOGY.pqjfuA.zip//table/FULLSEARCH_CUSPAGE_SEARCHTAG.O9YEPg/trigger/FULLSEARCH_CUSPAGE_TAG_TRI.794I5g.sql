create trigger FULLSEARCH_CUSPAGE_TAG_TRI
    before insert
    on FULLSEARCH_CUSPAGE_SEARCHTAG
    for each row
begin select fullsearch_cuspage_Tag_ID.nextval into :new.id from dual; end;
/

