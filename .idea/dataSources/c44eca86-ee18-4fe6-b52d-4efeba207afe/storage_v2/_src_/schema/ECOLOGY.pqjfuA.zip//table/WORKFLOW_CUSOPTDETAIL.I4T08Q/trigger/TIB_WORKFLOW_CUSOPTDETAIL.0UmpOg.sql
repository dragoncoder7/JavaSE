create trigger TIB_WORKFLOW_CUSOPTDETAIL
    before insert
    on WORKFLOW_CUSOPTDETAIL
    for each row
declare integrity_error  exception; errno            integer; errmsg           char(200); dummy            integer; found            boolean;  begin select workflow_cusoptdetail_seq.NEXTVAL INTO :new.ID from dual;  exception when integrity_error then raise_application_error(errno, errmsg); end;
/

