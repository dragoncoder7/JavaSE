create package body CUX_FACTORY_PKG is

  function get_factory(p_employee_num varchar2) return varchar2 is
    l_department_id number;
    l_company_id    number;
  
    l_factory varchar2(200);
  
    cursor c_dept is
      select level, a.departmentname, a.id, a.supdepid
        from hrmdepartment a
       start with a.id = l_department_id
      connect by a.id = prior a.supdepid;
  begin
    select A.SUBCOMPANYID1, A.DEPARTMENTID
      into l_company_id, l_department_id
      from hrmresource a
     where a.workcode = p_employee_num -- 'F1184188'
    ;
  
    --深圳长盈
    if l_company_id = 21 -- 深圳市长盈精密技术股份有限公司
     then
      for r in c_dept loop
        if r.departmentname = '冲压厂' then
          l_factory := '101'; --'冲压分厂';
        end if;
        if r.departmentname in ('连接器厂', '连接器事业二部') then
          l_factory := '102'; --'连接器分厂';
        end if;
        if r.departmentname in ('模具厂') then
          l_factory := '104'; -- '深圳模具分厂';
        end if;
        if r.departmentname in
           ('新能源事业本部', '新能源市场部', '氢能事业部') then
          l_factory := '114'; --'新能源事业本部';
        end if;
      
      end loop;
    
      l_factory := nvl(l_factory, '100' /*'深圳职能'*/);
    
      return l_factory;
    
    end if;
  
    --东莞市新美洋
    if l_company_id = 527 then
      l_factory := '101'; --'冲压分厂';
      return l_factory;
    end if;
  
    --深圳梦启
    if l_company_id = 13521 then
    
      l_factory := '103'; --'深圳梦启';
      return l_factory;
    end if;
  
    --广东长盈精密技术有限公司
    if l_company_id = 521 then
      for r in c_dept loop
        if r.departmentname = '模具加工中心' then
          l_factory := '105'; --'广东长盈模具分厂';
        end if;
      end loop;
    
      l_factory := nvl(l_factory, '110' /*'广东长盈'*/);
      return l_factory;
    
    end if;
  
    --
    --广东方振新材料精密组件有限公司
    if l_company_id = 526 then
      l_factory := '107'; --'广东方振';
      return l_factory;
    end if;
  
    --杨涌压铸厂
    if l_company_id = 2024 then
      l_factory := '108'; -- '压铸分厂';
      return l_factory;
    end if;
  
    --东莞市阿尔法电子有限公司 
    --安徽晶梦新材料技术有限公司 13522
    if l_company_id in (528, 13522) then
      l_factory := '109'; -- '东莞阿尔法';
      return l_factory;
    end if;
  
    --东莞长盈精密技术有限公司
    -- 东莞溪河精密技术有限公司 10021
    if l_company_id in (522, 10021) then
      l_factory := '110'; -- '广东长盈';
      return l_factory;
    end if;
  
    --东莞智昊光电科技有限公司
    --东莞智灏表面处理有限公司 9021
    if l_company_id in (523, 9021) then
      l_factory := '111'; --'东莞智昊';
      return l_factory;
    end if;
  
    --昆山哈勃电波电子科技有限公司
    if l_company_id in (533) then
      l_factory := '112'; --'昆山哈勃电波';
      return l_factory;
    end if;
  
    --昆山惠禾新能源有限公司
    if l_company_id in (530) then
      l_factory := '113'; --'昆山惠禾';
      return l_factory;
    end if;
  
    --宁德长盈新能源技术有限公司
    if l_company_id in (8021) then
      l_factory := '119'; --'新能源-电芯事业部';
      return l_factory;
    end if;
  
    --宜宾长盈精密技术有限公司
    if l_company_id in (12021) then
      for r in c_dept loop
        if r.departmentname in ('电芯宜宾分厂') then
          l_factory := '119'; --'新能源-电芯事业部';
        end if;
      
        if r.departmentname in ('PACK宜宾分厂') then
          l_factory := '120'; --'新能源-Pack事业部';
        end if;
      end loop;
    
      l_factory := nvl(l_factory, '114' /* '新能源事业本部'*/);
      return l_factory;
    end if;
  
    --自贡长盈精密技术有限公司
    if l_company_id in (14521) then
      l_factory := '114'; --'新能源事业本部';
      return l_factory;
    end if;
  
    --常州长盈精密技术有限公司
    if l_company_id in (10521) then
      for r in c_dept loop
        if r.departmentname in ('电芯结构件分厂') then
          l_factory := '119'; -- '新能源-电芯事业部';
        end if;
      
        if r.departmentname in ('PACK结构件分厂') then
          l_factory := '120'; --'新能源-Pack事业部';
        end if;
      end loop;
    
      return l_factory;
    
    end if;
  
    --昆山长盈精密技术有限公司
    if l_company_id in (529) then
      for r in c_dept loop
        if r.departmentname in ('汽车电子部') then
          l_factory := '115'; --'汽车电子';
        end if;
      
      end loop;
    
      l_factory := nvl(l_factory, '116' /*'华东IT产品事业部'*/);
    
      return l_factory;
    
    end if;
  
    --昆山杰顺通精密组件有限公司
    --昆山雷匠通信科技有限公司
    if l_company_id in (531, 532) then
      l_factory := '116'; --'华东IT产品事业部';
    
      return l_factory;
    end if;
  
    --上海临港长盈新能源科技有限公司
    if l_company_id in (536) then
      l_factory := '117'; --'临港长盈';
    
      return l_factory;
    end if;
  
    --西普拉斯技术有限公司
    if l_company_id in (535) then
      l_factory := '118'; --'CYPLUS';
    
      return l_factory;
    end if;
    
    --苏州科伦特电源科技有限公司
    if l_company_id in (534) then
      l_factory := '122'; --'苏州科伦特';
    
      return l_factory;
    end if;
    
    --科伦特电源（越南）科技有限公司
    if l_company_id in (12521) then
      l_factory := '121'; --'越南科伦特';
    
      return l_factory;
    end if;
    
    
    --苏州科伦特电气有限公司
    if l_company_id in (13021) then
      l_factory := '123'; --'科伦特电气';
    
      return l_factory;
    end if;
    
    
  end;
end CUX_FACTORY_PKG;
/

