create PROCEDURE Bill_Discuss_Insert ( billid_1 integer, requestid_1  integer, resourceid_1 integer, accepterid_1 varchar2, subject_1    varchar2, isend_1      integer, projectid_1  integer, crmid_1      integer, relatedrequestid_1   integer, status_1     char, flag out integer  , msg  out varchar2, thecursor IN OUT cursor_define.weavercursor ) as begin insert into bill_Discuss (billid,requestid,resourceid,accepterid,subject,isend,projectid,crmid,relatedrequestid,status) values(billid_1,requestid_1,resourceid_1,accepterid_1,subject_1,isend_1,projectid_1,crmid_1,relatedrequestid_1,status_1); open thecursor for select max(id) from bill_Discuss; end;


/

