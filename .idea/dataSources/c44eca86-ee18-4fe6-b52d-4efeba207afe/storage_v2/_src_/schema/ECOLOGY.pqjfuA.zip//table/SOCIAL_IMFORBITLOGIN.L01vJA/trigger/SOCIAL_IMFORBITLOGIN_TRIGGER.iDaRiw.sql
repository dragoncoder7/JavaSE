create trigger SOCIAL_IMFORBITLOGIN_TRIGGER
    before insert
    on SOCIAL_IMFORBITLOGIN
    for each row
begin select social_imForbitLogin_seq.nextval into:new.id from dual; end;
/

