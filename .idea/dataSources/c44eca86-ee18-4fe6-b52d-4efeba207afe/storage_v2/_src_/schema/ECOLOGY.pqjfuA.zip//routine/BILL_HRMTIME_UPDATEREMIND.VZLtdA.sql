create PROCEDURE bill_HrmTime_UpdateRemind ( id1	integer, isremind1        integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin Update bill_hrmtime set isremind=isremind1 where id=id1; end;


/

