create PROCEDURE CrmShareDetail_SByResourceId (resourceid_1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin open thecursor for select crmid , sharelevel from CrmShareDetail where (userid = resourceid_1) and (usertype = '1'); end;


/

