create trigger EXP_DBMAINTABLESETTING_TRI
    before insert
    on EXP_DBMAINTABLESETTING
    for each row
begin select exp_dbmaintablesetting_id.nextval into :new.id from dual; end;
/

