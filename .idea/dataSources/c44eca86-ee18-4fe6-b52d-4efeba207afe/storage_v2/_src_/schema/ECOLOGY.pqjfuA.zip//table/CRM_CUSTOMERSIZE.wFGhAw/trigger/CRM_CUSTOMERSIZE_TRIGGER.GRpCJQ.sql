create trigger CRM_CUSTOMERSIZE_TRIGGER
    before insert
    on CRM_CUSTOMERSIZE
    for each row
begin select CRM_CustomerSize_id.nextval into :new.id from dual; end;
/

