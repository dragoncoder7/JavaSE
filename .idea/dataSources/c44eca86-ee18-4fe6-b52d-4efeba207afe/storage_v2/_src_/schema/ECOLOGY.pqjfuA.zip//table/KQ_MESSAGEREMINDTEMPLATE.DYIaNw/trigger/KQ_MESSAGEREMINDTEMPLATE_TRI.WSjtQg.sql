create trigger KQ_MESSAGEREMINDTEMPLATE_TRI
    before insert
    on KQ_MESSAGEREMINDTEMPLATE
    for each row
begin select kq_messageRemindTemplate_id.nextval INTO :new.id from dual; end;
/

