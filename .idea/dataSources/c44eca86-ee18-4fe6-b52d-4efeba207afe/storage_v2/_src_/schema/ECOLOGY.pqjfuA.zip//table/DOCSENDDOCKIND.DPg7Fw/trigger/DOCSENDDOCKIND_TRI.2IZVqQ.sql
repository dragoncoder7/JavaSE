create trigger DOCSENDDOCKIND_TRI
    before insert
    on DOCSENDDOCKIND
    for each row
begin select DocSendDocKind_id.nextval into :new.id from dual; end;
/

