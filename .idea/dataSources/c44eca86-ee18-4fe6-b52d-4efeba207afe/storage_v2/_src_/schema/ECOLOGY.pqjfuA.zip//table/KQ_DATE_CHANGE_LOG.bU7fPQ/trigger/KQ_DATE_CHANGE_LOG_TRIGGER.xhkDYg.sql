create trigger KQ_DATE_CHANGE_LOG_TRIGGER
    before insert
    on KQ_DATE_CHANGE_LOG
    for each row
begin select kq_date_change_log_ID.nextval into :new.id from dual; end;
/

