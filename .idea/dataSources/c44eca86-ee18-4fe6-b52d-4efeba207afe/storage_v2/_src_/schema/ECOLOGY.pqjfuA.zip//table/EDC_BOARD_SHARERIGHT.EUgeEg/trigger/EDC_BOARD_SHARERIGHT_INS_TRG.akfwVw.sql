create trigger EDC_BOARD_SHARERIGHT_INS_TRG
    before insert
    on EDC_BOARD_SHARERIGHT
    for each row
    when (NEW.id IS NULL)
BEGIN SELECT edc_board_shareRight_id_SEQ.NEXTVAL INTO :NEW.id FROM DUAL; END;
/

