create trigger KQ_REPORTSHARE_TRI
    before insert
    on KQ_REPORTSHARE
    for each row
begin select kq_ReportShare_id.nextval INTO :new.id from dual; end;
/

