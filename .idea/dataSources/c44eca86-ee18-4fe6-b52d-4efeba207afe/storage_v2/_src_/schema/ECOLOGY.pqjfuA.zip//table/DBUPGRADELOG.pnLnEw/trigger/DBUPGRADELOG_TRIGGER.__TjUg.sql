create trigger DBUPGRADELOG_TRIGGER
    before insert
    on DBUPGRADELOG
    for each row
begin select DBUpgradeLog_id.nextval into :new.id from dual; end;
/

