create trigger HRMOTHERINFOTYPE_TRIGGER
    before insert
    on HRMOTHERINFOTYPE
    for each row
begin select HrmOtherInfoType_id.nextval into :new.id from dual; end;
/

