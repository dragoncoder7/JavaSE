create trigger KQ_FORMAT_POOL_TRI
    before insert
    on KQ_FORMAT_POOL
    for each row
begin select kq_format_pool_id.nextval into :new.id from dual; end;
/

