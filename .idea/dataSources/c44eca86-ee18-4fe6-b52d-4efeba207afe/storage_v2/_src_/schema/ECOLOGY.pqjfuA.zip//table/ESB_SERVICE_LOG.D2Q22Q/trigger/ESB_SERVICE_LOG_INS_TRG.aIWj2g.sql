create trigger ESB_SERVICE_LOG_INS_TRG
    before insert
    on ESB_SERVICE_LOG
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT ESB_SERVICE_LOG_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

