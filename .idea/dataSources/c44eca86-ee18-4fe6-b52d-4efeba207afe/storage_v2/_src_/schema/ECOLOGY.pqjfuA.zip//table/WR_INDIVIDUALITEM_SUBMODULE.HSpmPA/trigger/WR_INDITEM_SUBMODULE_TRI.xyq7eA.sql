create trigger WR_INDITEM_SUBMODULE_TRI
    before insert
    on WR_INDIVIDUALITEM_SUBMODULE
    for each row
begin select WR_indItem_Submodule_SEQ.nextval into :new.id from dual; end;
/

