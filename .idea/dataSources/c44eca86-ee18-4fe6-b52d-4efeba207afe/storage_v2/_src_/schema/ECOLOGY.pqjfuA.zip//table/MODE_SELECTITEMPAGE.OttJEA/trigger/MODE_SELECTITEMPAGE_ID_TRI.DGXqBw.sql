create trigger MODE_SELECTITEMPAGE_ID_TRI
    before insert
    on MODE_SELECTITEMPAGE
    for each row
begin select mode_selectitempage_id.nextval into :new.id from dual; end;
/

