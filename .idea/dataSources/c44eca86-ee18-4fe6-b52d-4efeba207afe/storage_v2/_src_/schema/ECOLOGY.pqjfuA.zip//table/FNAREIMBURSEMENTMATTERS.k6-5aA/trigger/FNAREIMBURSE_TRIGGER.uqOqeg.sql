create trigger FNAREIMBURSE_TRIGGER
    before insert
    on FNAREIMBURSEMENTMATTERS
    for each row
begin select seq_FnaReimburse_id.nextval into :new.id from dual; end;
/

