create PROCEDURE createIndexForEcology(indexname varchar, tablename varchar, tab_cols  varchar) as indexsql varchar(4000); begin indexsql := 'create index ' || indexname || ' on ' || tablename || '(' || tab_cols || ')'; EXECUTE IMMEDIATE (indexsql); DBMS_OUTPUT.put_line('创建索引成功 : ' || indexsql); exception when others then DBMS_OUTPUT.put_line('创建索引失败 : ' || indexsql); end;


/

