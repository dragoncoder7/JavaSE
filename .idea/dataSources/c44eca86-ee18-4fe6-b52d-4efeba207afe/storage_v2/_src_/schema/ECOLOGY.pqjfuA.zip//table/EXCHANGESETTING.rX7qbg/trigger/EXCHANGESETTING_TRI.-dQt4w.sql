create trigger EXCHANGESETTING_TRI
    before insert
    on EXCHANGESETTING
    for each row
begin select exchangesetting_seq.nextval into :new.id from dual; end ;
/

