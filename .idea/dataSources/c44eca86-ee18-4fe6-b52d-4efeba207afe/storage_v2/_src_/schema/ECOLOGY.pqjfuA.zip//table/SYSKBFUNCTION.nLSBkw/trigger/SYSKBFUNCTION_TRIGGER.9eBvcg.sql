create trigger SYSKBFUNCTION_TRIGGER
    before insert
    on SYSKBFUNCTION
    for each row
begin select SysKbFunction_SEQ.nextval into :new.id from dual; end ;
/

