create trigger WORKFLOW_FLOWERROR_LOG_TRI
    before insert
    on WORKFLOW_FLOWERROR_LOG
    for each row
begin select workflow_flowerror_log_seq.nextval into :new.id from DUAL; END;
/

