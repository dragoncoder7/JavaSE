create trigger FORMTABLE_MAIN_3499_ID_TR
    before insert
    on FORMTABLE_MAIN_3499
    for each row
begin select formtable_main_3499_Id.nextval into :new.id from dual;  end;
/

