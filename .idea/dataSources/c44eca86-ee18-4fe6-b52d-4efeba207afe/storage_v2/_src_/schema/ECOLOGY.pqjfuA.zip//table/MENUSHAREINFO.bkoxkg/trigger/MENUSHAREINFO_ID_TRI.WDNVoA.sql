create trigger MENUSHAREINFO_ID_TRI
    before insert
    on MENUSHAREINFO
    for each row
begin select menushareinfo_id.nextval into :new.id from dual; end;
/

