create trigger HRMSALARYWELFARERATE_TRI
    before insert
    on HRMSALARYWELFARERATE
    for each row
begin select HrmSalaryWelfarerate_id.nextval into :new.id from dual; end;
/

