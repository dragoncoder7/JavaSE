create trigger HRSYNCSETPARAM_TRI
    before insert
    on HRSYNCSETPARAM
    for each row
begin select hrsyncsetparam_seq.nextval into :new.id from dual; end;
/

