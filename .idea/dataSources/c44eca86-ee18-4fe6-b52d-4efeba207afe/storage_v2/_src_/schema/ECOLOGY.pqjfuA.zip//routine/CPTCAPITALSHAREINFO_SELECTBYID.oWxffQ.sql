create PROCEDURE CptCapitalShareInfo_SelectbyID (id1 integer , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from CptCapitalShareInfo where (id = id1 ); end;


/

