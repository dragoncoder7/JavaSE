create trigger TRG_AUTO_INCREMENT_UF_A01
    before insert
    on UF_A01
    for each row
BEGIN
    SELECT uf_A01_seq_id.NEXTVAL INTO :NEW.id FROM dual;
END;
/

