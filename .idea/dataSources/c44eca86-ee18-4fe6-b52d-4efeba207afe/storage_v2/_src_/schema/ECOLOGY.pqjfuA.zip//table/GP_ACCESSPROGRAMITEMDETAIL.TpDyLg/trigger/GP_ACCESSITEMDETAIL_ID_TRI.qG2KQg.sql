create trigger GP_ACCESSITEMDETAIL_ID_TRI
    before insert
    on GP_ACCESSPROGRAMITEMDETAIL
    for each row
begin select GP_AccessItemDetail_SEQ.nextval into :new.id from dual; end;
/

