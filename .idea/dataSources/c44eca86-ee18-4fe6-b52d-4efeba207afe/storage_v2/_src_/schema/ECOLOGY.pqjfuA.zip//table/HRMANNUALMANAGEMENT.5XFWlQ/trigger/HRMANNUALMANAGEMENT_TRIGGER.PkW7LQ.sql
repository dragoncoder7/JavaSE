create trigger HRMANNUALMANAGEMENT_TRIGGER
    before insert
    on HRMANNUALMANAGEMENT
    for each row
begin select HrmAnnualManagement_id.nextval into :new.id from dual; end;
/

