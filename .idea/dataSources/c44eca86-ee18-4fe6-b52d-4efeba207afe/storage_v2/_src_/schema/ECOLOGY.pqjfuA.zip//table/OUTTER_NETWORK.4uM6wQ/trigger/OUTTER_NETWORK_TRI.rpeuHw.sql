create trigger OUTTER_NETWORK_TRI
    before insert
    on OUTTER_NETWORK
    for each row
begin select outter_network_seq.nextval into :new.id from dual; end;
/

