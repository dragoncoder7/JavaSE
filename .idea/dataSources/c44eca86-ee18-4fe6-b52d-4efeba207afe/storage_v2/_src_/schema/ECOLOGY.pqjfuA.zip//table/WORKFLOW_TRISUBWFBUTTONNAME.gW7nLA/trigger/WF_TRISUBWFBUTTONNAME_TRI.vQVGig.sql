create trigger WF_TRISUBWFBUTTONNAME_TRI
    before insert
    on WORKFLOW_TRISUBWFBUTTONNAME
    for each row
begin select Wf_TriSubwfButtonName_id.nextval into :new.id from dual; end;
/

