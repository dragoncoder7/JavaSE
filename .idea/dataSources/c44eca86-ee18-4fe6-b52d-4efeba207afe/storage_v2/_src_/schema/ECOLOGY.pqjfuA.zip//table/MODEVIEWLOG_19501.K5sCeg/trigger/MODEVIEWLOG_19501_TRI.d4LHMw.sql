create trigger MODEVIEWLOG_19501_TRI
    before insert
    on MODEVIEWLOG_19501
    for each row
begin   select ModeViewLog_19501_id.nextval into :new.id from dual;   end;
/

