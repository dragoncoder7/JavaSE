create trigger BILL_MEETING_ID_TR
    before insert
    on BILL_MEETING
    for each row
begin select Bill_Meeting_Id.nextval into :new.id from dual;  end;
/

