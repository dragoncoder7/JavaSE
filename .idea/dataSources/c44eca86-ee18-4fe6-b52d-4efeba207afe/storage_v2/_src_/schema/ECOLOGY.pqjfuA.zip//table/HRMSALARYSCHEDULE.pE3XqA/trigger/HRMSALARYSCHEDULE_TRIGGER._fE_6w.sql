create trigger HRMSALARYSCHEDULE_TRIGGER
    before insert
    on HRMSALARYSCHEDULE
    for each row
begin select HrmSalarySchedule_id.nextval into :new.id from dual; end;
/

