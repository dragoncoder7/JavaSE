create trigger HRMGROUP_TRI
    before insert
    on HRMGROUP
    for each row
begin select HrmGroup_id.nextval into :new.id from dual; end;
/

