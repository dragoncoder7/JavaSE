create trigger SOCIAL_IM_MSGINITRECORD_ID_TRI
    before insert
    on IM_MSGINITRECORD
    for each row
begin select Social_im_MsgInitRecord_id.nextval into :new.id from dual; end;
/

