create trigger KT_THEMEKNOWLEDGE_ID_TRIGGER
    before insert
    on KT_THEMEKNOWLEDGE
    for each row
begin select KT_ThemeKnowledge_id.nextval into :new.id from dual; end;
/

