create trigger MEETINGSHARESET_TRI
    before insert
    on MEETINGSHARESET
    for each row
begin select MeetingShareSet_id.nextval into :new.id from dual; end;
/

