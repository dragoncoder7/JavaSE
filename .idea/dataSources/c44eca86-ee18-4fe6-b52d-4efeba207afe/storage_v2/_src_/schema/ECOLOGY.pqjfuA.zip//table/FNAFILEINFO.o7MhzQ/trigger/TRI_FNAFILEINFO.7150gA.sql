create trigger TRI_FNAFILEINFO
    before insert
    on FNAFILEINFO
    for each row
begin select seq_FnaFileInfo_id.nextval into :new.id from dual; end;
/

