create PROCEDURE cowork_types_update (id_1 	integer, typename_2 	varchar2, departmentid_3 integer, managerid_4 	varchar2, members_5 	varchar2, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin UPDATE cowork_types SET  typename = typename_2, departmentid = departmentid_3, managerid = managerid_4, members = members_5 WHERE ( id = id_1); end;


/

