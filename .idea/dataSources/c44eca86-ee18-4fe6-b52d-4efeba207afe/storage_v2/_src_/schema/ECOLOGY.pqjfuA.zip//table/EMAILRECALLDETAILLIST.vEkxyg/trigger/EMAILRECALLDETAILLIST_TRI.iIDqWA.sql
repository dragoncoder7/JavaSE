create trigger EMAILRECALLDETAILLIST_TRI
    before insert
    on EMAILRECALLDETAILLIST
    for each row
begin select emailrecalldetaillist_seq.nextval INTO :new.id from sys.dual; end;
/

