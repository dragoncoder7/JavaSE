create PROCEDURE CRM_SectorRpSum (parentid_1	varchar, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS tempstr_1 varchar2(4000); tempid_1 integer; begin tempstr_1 :='%,'|| parentid_1 ||',%' ; tempid_1 := cast(parentid_1 as integer); open thecursor for select count(id)  from crm_customerinfo where sector in(select id from crm_sectorinfo where id=tempid_1 or sectors like tempstr_1); end;


/

