create trigger ODOC_CUSTOMTAB_TRIGGER
    before insert
    on ODOC_CUSTOMTAB
    for each row
begin select odoc_customtab_seq.nextval into :new.customtabid from dual; end;
/

