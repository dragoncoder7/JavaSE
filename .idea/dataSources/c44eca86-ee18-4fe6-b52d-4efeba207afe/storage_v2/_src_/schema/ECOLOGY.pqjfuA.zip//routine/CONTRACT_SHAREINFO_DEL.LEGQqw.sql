create PROCEDURE Contract_ShareInfo_Del (id_1 integer, flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin DELETE from Contract_ShareInfo  WHERE ( id = id_1); end;


/

