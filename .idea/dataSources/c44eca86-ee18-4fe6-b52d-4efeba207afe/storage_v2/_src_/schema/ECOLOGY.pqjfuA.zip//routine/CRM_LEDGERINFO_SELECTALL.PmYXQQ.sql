create PROCEDURE CRM_LedgerInfo_SelectAll ( customerid1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for select * from crm_ledgerinfo where customerid=customerid1; end;


/

