create trigger WORKFLOW_SELECTNEXTFLOW_TRI
    before insert
    on WORKFLOW_REQUESTSELECTNEXTFLOW
    for each row
begin select workflow_selectnextflow_seq.nextval into :new.keyid from DUAL; END;
/

