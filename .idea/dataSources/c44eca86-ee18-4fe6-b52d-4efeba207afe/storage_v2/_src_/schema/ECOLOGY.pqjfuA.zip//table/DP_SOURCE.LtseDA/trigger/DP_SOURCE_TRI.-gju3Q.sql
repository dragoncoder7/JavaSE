create trigger DP_SOURCE_TRI
    before insert
    on DP_SOURCE
    for each row
BEGIN SELECT DP_Source_id.NEXTVAL INTO :NEW.id FROM dual; END;
/

