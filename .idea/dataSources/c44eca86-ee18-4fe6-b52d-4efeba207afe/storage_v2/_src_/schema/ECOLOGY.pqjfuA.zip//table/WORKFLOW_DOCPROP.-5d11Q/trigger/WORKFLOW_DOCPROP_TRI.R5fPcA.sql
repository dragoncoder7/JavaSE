create trigger WORKFLOW_DOCPROP_TRI
    before insert
    on WORKFLOW_DOCPROP
    for each row
begin select Workflow_DocProp_id.nextval into :new.id from dual; end;
/

