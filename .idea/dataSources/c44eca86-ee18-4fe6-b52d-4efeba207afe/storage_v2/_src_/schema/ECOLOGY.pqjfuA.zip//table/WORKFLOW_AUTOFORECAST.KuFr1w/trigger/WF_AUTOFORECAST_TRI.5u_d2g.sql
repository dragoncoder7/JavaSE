create trigger WF_AUTOFORECAST_TRI
    before insert
    on WORKFLOW_AUTOFORECAST
    for each row
begin select wf_autoForecast_seq.nextval into :new.id from dual; end;
/

