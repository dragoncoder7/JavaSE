create trigger MOBILE_USER_SETTING_ID_TRI
    before insert
    on MOBILEUSERDOCSETTING
    for each row
    when (new.id is null)
begin select mobile_user_setting_id.nextval into :new.id from dual; end;
/

