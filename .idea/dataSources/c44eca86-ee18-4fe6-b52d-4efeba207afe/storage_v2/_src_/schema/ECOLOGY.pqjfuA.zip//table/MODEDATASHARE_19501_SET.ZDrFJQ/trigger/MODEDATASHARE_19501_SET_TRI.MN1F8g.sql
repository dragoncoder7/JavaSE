create trigger MODEDATASHARE_19501_SET_TRI
    before insert
    on MODEDATASHARE_19501_SET
    for each row
begin   select modeDataShare_19501_set_id.nextval into :new.id from dual;   end;
/

