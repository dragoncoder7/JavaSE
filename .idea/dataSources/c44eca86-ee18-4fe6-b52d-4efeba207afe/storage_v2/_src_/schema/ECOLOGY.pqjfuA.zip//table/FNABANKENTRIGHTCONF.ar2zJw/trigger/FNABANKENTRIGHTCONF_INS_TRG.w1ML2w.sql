create trigger FNABANKENTRIGHTCONF_INS_TRG
    before insert
    on FNABANKENTRIGHTCONF
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT fnaBankEntRightConf_id_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

