create PROCEDURE CRM_Modify_Insert (customerid_1 	integer, tabledesc_1 	char, type_1 		integer, addresstype_1 	integer, fieldname_1 	varchar2, modifydate_1 	varchar2, modifytime_1 	varchar2, original_1 	varchar2, modified_1 	varchar2, modifier_1 	integer, submitertype_1  smallint, clientip_1 	char, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor) AS begin INSERT INTO CRM_Modify ( customerid, tabledesc, type, addresstype, fieldname, modifydate, modifytime, original, modified, modifier, submitertype, clientip) VALUES ( customerid_1, tabledesc_1, type_1, addresstype_1, fieldname_1, modifydate_1, modifytime_1, original_1, modified_1, modifier_1, submitertype_1, clientip_1); end;


/

