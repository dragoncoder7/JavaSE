create trigger FORMTABLE_MAIN_15_ID_TR
    before insert
    on FORMTABLE_MAIN_15
    for each row
begin select formtable_main_15_Id.nextval into :new.id from dual;  end;
/

