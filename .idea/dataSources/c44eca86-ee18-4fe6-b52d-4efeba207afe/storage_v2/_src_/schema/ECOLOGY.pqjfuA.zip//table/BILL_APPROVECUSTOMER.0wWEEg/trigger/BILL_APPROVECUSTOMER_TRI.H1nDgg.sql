create trigger BILL_APPROVECUSTOMER_TRI
    before insert
    on BILL_APPROVECUSTOMER
    for each row
begin select bill_ApproveCustomer_id.nextval into :new.id from dual; end;
/

