create PROCEDURE CRM_ContactLog_InsertID (flag out	integer, msg out	varchar2,  thecursor IN OUT cursor_define.weavercursor) as begin open thecursor for SELECT id FROM (select id from CRM_ContactLog ORDER BY id DESC) where rownum=1; end;


/

