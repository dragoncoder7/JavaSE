create trigger CARUSEAPPROVE_TRIGGER
    before insert
    on CARUSEAPPROVE
    for each row
begin select CarUseApprove_id.nextval into :new.id from dual; end ;
/

