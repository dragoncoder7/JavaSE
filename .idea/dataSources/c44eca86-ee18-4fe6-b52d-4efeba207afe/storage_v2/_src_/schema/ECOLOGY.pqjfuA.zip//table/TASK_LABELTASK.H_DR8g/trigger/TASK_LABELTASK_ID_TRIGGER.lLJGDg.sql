create trigger TASK_LABELTASK_ID_TRIGGER
    before insert
    on TASK_LABELTASK
    for each row
begin select Task_labelTask_id.nextval into :new.id from dual; end;
/

