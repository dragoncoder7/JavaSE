create trigger PRJ_TASK_NEEDDOC_TRIGGER
    before insert
    on PRJ_TASK_NEEDDOC
    for each row
begin select Prj_task_needdoc_id.nextval into :new.id from dual; end;
/

