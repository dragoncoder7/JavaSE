create trigger SMSCOMMONTEMPLATEFIELDS_TRI
    before insert
    on SMSCOMMONTEMPLATEFIELDS
    for each row
begin select smsCommontemplateFields_seq.nextval into :new.id from dual; end;
/

