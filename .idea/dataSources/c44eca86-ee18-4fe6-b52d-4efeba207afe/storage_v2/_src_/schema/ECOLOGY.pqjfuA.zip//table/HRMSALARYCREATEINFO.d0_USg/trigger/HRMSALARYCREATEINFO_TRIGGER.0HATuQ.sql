create trigger HRMSALARYCREATEINFO_TRIGGER
    before insert
    on HRMSALARYCREATEINFO
    for each row
begin select HrmSalaryCreateInfo_id.nextval into :new.id from dual; end;
/

