create PROCEDURE CRM_Evaluation_L_SelectById (id_1 	int , flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin open thecursor for SELECT * FROM CRM_Evaluation_Level  where id = id_1; end;


/

