create trigger BLOG_ECME_ID_TRI
    before insert
    on BLOG_DISCUSS_ECME
    for each row
BEGIN SELECT BLOGECME_ID.nextval INTO :new.id FROM DUAL; END;
/

