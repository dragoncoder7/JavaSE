create trigger INFO_JOURNALCOLUMN_INS_TRG
    before insert
    on INFO_JOURNALCOLUMN
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT info_journalcolumn_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

