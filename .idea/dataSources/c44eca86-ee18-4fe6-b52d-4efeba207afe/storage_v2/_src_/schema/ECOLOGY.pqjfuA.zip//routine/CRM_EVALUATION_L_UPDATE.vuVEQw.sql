create PROCEDURE CRM_Evaluation_L_Update (id_1 	integer , name_1 	varchar2, levelvalue_1	integer, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor)  AS begin UPDATE CRM_Evaluation_Level SET name = name_1, levelvalue = levelvalue_1 where id = id_1; end;


/

