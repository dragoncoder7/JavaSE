create trigger BILL_DISCUSS_TRIGGER
    before insert
    on BILL_DISCUSS
    for each row
begin select bill_Discuss_id.nextval INTO :new.id from dual; end;
/

