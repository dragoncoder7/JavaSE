create trigger FNAINVOICELEDGER_TRIGGER
    before insert
    on FNAINVOICELEDGER
    for each row
begin select fnaInvoiceLedger_ID.nextval INTO :new.id from dual; end;
/

