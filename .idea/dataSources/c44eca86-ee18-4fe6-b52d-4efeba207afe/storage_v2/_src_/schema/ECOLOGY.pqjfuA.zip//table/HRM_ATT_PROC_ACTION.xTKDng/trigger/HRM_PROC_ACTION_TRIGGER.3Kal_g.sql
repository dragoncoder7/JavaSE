create trigger HRM_PROC_ACTION_TRIGGER
    before insert
    on HRM_ATT_PROC_ACTION
    for each row
begin select hrm_att_proc_action_id.nextval into :new.id from dual; end;
/

