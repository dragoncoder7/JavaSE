create trigger TR_INT_DATAINTER
    before insert
    on INT_DATAINTER
    for each row
begin select sq_int_dataInter.nextval into :new.id from dual; end;
/

