create trigger SENDDOCINFO_INNER_TRI
    before insert
    on EXCHANGE_SENDDOCINFO_INNER
    for each row
begin if (:new.id is null) then select senddocinfo_inner_seq.nextval into :new.id from dual; end if; end;
/

