create trigger OUTREPORTSHARE_ID_TRIGGER
    before insert
    on T_OUTREPORTSHARE
    for each row
begin select outReportShare_Id.nextval into :new.outrepshareid from dual; end;
/

