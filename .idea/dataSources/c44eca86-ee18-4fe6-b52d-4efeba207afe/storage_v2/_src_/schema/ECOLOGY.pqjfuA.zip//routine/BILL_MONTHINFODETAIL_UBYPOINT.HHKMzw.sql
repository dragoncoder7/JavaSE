create PROCEDURE bill_monthinfodetail_UByPoint ( id1		integer, point1	varchar2, flag out integer , msg out varchar2, thecursor IN OUT cursor_define.weavercursor )as begin update bill_monthinfodetail set point=point1 where id=id1; end;


/

