create trigger EDC_NODE_V_INS_TRG
    before insert
    on EDC_NODE_V
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_node_v_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

