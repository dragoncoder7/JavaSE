create trigger MODE_CUSTOMSEARCH_TRI
    before insert
    on MODE_CUSTOMSEARCH
    for each row
begin select mode_customsearch_id.nextval into :new.id from dual; end;
/

