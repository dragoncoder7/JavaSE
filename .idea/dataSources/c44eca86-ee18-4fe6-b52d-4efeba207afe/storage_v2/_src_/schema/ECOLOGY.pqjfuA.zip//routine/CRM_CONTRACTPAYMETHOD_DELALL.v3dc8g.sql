create PROCEDURE CRM_ContractPayMethod_DelAll (contractId_1 	integer , IdStr_1 	varchar2 , flag out integer, msg out varchar2, thecursor IN OUT cursor_define.weavercursor ) AS begin DELETE CRM_ContractPayMethod WHERE ( contractId	 = contractId_1 and id not in(IdStr_1)); end;


/

