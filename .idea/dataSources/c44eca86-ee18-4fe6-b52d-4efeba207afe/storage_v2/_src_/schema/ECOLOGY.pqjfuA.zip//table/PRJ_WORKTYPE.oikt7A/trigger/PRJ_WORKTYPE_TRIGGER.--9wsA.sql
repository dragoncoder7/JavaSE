create trigger PRJ_WORKTYPE_TRIGGER
    before insert
    on PRJ_WORKTYPE
    for each row
begin select Prj_WorkType_id.nextval into :new.id from dual; end;
/

