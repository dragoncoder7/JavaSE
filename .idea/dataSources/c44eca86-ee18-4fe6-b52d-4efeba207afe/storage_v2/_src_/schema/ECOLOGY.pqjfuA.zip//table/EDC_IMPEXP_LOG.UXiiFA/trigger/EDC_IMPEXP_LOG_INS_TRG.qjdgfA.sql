create trigger EDC_IMPEXP_LOG_INS_TRG
    before insert
    on EDC_IMPEXP_LOG
    for each row
    when (NEW.ID IS NULL)
BEGIN SELECT edc_impexp_log_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL; END;
/

