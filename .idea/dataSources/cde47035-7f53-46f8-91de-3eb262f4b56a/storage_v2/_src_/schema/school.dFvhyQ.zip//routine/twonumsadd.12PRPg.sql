create
    definer = root@localhost procedure twonumsadd(IN a int, IN b int, OUT c int)
begin
	set c = a + b;
end;

