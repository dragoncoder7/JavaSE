create
    definer = root@localhost procedure updateStudent()
begin
	update student set sex = 0 where studentno = 1000;
end;

